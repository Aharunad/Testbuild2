# ATLAS Planet Finder — integration checkpoint

Date: 2026-10-27

## Changes in this checkpoint
- Replaced the short galaxy dropdown with all 256 galaxy names from the original engine's own catalogue.
- Galaxy option values are now the engine's internal indices (0–255), so selecting `Euclid` passes `0` instead of the string `Euclid`.
- Added a first-pass bridge mapping for controls with direct equivalents in the original core.
- Multiple selected terrain families now run as separate OR passes for the same batch; returned records are merged and deduplicated by the existing bridge.
- Results polling now uses the existing planet telemetry card renderer when available.

## Tests actually run
- `python -m py_compile app/src/main/python/atlas_bridge.py` — PASS.
- Loaded original core catalogue — PASS: 256 records, first `Euclid`, last `Odyalutai`.
- One-system real engine smoke test with portal `14091FF27DD9`, galaxy index 0 — PASS: engine completed, tested 1 system / 4 planets, returned 4 matches, no engine error (re-run during v0.2 packaging).
- One-system two-terrain test (`Mountain Ravines` OR `Desert`) — PASS: engine completed, tested 1 system / 8 planet evaluations across the two passes, returned 1 deduplicated match, no engine error.
- One-system constrained filter test (Lush, Small, Non-extreme) — PASS: engine completed, tested 1 system / 4 planets, no engine error, 0 matches (valid no-match outcome).
- Inline JavaScript syntax check using `node --check` — PASS.

## Not yet verified
- Android APK compilation/install/runtime. This environment does not have a Gradle executable or Android SDK, and the project has no usable Gradle wrapper JAR.
- Full mapping of every visible control. Some controls (notably moon count/relationship, leaf colour, tree height/type, several plant/terrain flags, some colour channels, max distance and checkpoint resume) still need individual core-field mapping and tests. This checkpoint is not feature-complete.
- Device-level performance, pause/resume/stop responsiveness, and long-range scan behavior.

No claim is made that an APK has been built or that all app features are now working.

## Version 0.2 packaging changes
- Android `versionCode` set to 2 and `versionName` set to `0.2`.
- GitHub Actions artifact label changed to `ATLAS-Futurica-v0.2-debug-APK`.
- These packaging edits do not constitute an Android build; run the workflow to produce the installable APK.
