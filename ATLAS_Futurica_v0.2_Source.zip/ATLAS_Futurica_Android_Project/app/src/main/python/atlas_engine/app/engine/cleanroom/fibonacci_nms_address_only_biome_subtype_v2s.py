#!/usr/bin/env python3
"""
FIBONACCI NMS ADDRESS-ONLY BIOME + SUBTYPE PREDICTOR V2S

Merged offline predictor for the standard No Man's Sky 6.45 route:

12-glyph portal address
  -> resolved TkSeed
  -> body counts and StarType
  -> PlanetSize and parent structure
  -> exact planet seeds
  -> direct-RNG biome entry offset
  -> final Class assignment
  -> final Biome
  -> final BiomeSubType

Controlled validation:
* 2/2 systems
* 6/6 planet seeds
* 6/6 final Classes
* 6/6 final Biomes
* 6/6 final BiomeSubTypes

Deliberately unclaimed:
* StarType 4's dedicated special-system branch.
* The rare runtime-global class-mode-3 override at RVA 0x16C0F75.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import fibonacci_nms_address_only_predictor_v2m as v2m
import fibonacci_nms_exact_biome_subtype_solver_v2q as v2q
import fibonacci_nms_direct_rng_budget_v2r as v2r

VERSION = "2S.0.0"
NORMAL_STAR_TYPES = {0, 1, 2, 3}

KNOWN_SEEDS = {
    "000000000000": [
        "0xDCC172DD5D0F4040",
        "0xCEA738EFFC0C59B4",
        "0x03AA60869F4BEE7E",
        "0x03DF5F544CFF3071",
    ],
    "11680850FB82": [
        "0xB84C1E4368085A60",
        "0x62F0E99D93E7DAFC",
    ],
}


def load_assets(base: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    tables = v2q.normalise_biome_tables(
        v2q.load_json(base / "biome_tables_v2n_compact.json")
    )
    catalogs = v2q.normalise_catalogs(
        v2q.load_json(base / "biome_special_catalog_compact_v2p.json")
    )
    vectors = v2q.load_json(base / "known_biome_vectors_v2q.json")
    return tables, catalogs, vectors


def derive_normal_class_mode(system: dict[str, Any]) -> dict[str, Any]:
    system_index = int(system["system_index"])
    star_type = int(system["star_type_raw"])
    class_one_position = int(system["internal_class_limit"])
    inner_region_flag = system_index < v2m.BASE_SYSTEM_INDEX_CUTOFF
    special_range_flag = bool(
        system["first_special_range"] or system["second_special_range"]
    )

    if inner_region_flag:
        mode = 1
        reason = "temp_plus_14_inner_region_flag"
    elif star_type == 0 and class_one_position > 0:
        mode = 1
        reason = "star_type_zero_and_temp_plus_20_positive"
    elif special_range_flag:
        mode = 2
        reason = "temp_plus_18_special_range_flag"
    else:
        mode = 0
        reason = "normal_default"

    return {
        "mode": mode,
        "reason": reason,
        "class_one_position_1_based": class_one_position,
        "inner_region_flag": inner_region_flag,
        "special_range_flag": special_range_flag,
        "mode3_runtime_override_status": "NOT_CLAIMED",
    }


def derive_final_classes(
    system: dict[str, Any],
    class_mode: dict[str, Any],
) -> list[int]:
    mode = int(class_mode["mode"])
    k = int(class_mode["class_one_position_1_based"])
    primary = int(system["primary_count"])
    secondary = int(system["secondary_count"])

    classes: list[int] = []
    for slot in range(primary):
        if mode in (1, 3) and slot == k - 1:
            value = 1
        elif mode == 3:
            value = 2
        else:
            value = 0
        classes.append(value)

    classes.extend([2 if mode == 3 else 0] * secondary)
    return classes


def find_known_vector(
    vectors: dict[str, Any],
    portal: str,
    resolved: str,
) -> dict[str, Any] | None:
    for vector in vectors["vectors"]:
        if vector["portal"] == portal or vector["resolved"] == resolved:
            return vector
    return None


def predict(
    portal: str,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors: dict[str, Any],
    galaxy_index: int = 0,
) -> dict[str, Any]:
    decoded = v2m.decode_portal(portal, galaxy_index)
    system = v2m.predict_system(decoded)
    structure = v2r.replay_primary_structure(decoded, system)
    budget = v2r.calculate_entry_budget(system, structure)
    seed_data = v2m.predict_planet_seeds(decoded, system)
    class_mode = derive_normal_class_mode(system)
    classes = derive_final_classes(system, class_mode)

    supported = (
        int(system["star_type_raw"]) in NORMAL_STAR_TYPES
        and int(class_mode["mode"]) != 3
        and bool(budget["supported_for_final_prediction"])
    )

    simulation = None
    if supported:
        vector = {
            "portal": decoded.input_portal,
            "resolved": decoded.resolved_system_portal,
            "tkseed": f"0x{decoded.tkseed:016X}",
            "star_type": int(system["star_type_raw"]),
            "primary_count": int(system["primary_count"]),
            "secondary_count": int(system["secondary_count"]),
            "final_classes": classes,
            "planet_sizes": structure["planet_sizes"],
            "galaxy_index": int(galaxy_index),
        }
        simulation = v2q.simulate_schedule(
            vector,
            tables,
            catalogs,
            int(budget["entry_offset"]),
        )

    known = find_known_vector(
        vectors,
        decoded.input_portal,
        decoded.resolved_system_portal,
    )
    labels = []
    if known is not None:
        labels = [
            str(value)
            for value in known.get("visible_labels", [])
        ]

    biome_rows = {}
    if simulation is not None:
        biome_rows = {
            int(row["slot"]): row
            for row in simulation["bodies"]
        }

    bodies = []
    for seed_row in sorted(
        seed_data["bodies"],
        key=lambda row: int(row["slot"]),
    ):
        slot = int(seed_row["slot"])
        biome_row = biome_rows.get(slot)
        bodies.append(
            {
                "slot": slot,
                "kind": seed_row["kind"],
                "planet_seed": seed_row["seed_hex"],
                "planet_size": int(structure["planet_sizes"][slot]),
                "final_class": int(classes[slot]),
                "biome": (
                    int(biome_row["biome"])
                    if biome_row is not None
                    else None
                ),
                "biome_subtype": (
                    int(biome_row["final_subtype"])
                    if biome_row is not None
                    else None
                ),
                "known_visible_label": (
                    labels[slot] if slot < len(labels) else "UNKNOWN"
                ),
            }
        )

    warnings: list[str] = []
    if decoded.normal_portal_range_warning:
        warnings.append(decoded.normal_portal_range_warning)
    if int(system["star_type_raw"]) == 4:
        warnings.append(
            "StarType 4 uses a dedicated special-system route that V2S "
            "does not claim."
        )
    warnings.append(
        "The rare runtime-global class-mode-3 override is not purely "
        "address-derived and remains deliberately unclaimed."
    )

    return {
        "version": VERSION,
        "mode": "OFFLINE_NO_NMS_PROCESS",
        "address": {
            "input_portal": decoded.input_portal,
            "resolved_system_portal": decoded.resolved_system_portal,
            "tkseed": f"0x{decoded.tkseed:016X}",
            "galaxy_index": int(decoded.galaxy_index),
            "reality_class": v2q.reality_class_for_galaxy(decoded.galaxy_index),
            "ssi": int(decoded.supplied_ssi),
            "voxel_x": int(decoded.voxel_x),
            "voxel_y": int(decoded.voxel_y),
            "voxel_z": int(decoded.voxel_z),
            "all_zero_correction": bool(
                decoded.used_observed_all_zero_correction
            ),
        },
        "system": {
            "primary_count": int(system["primary_count"]),
            "secondary_count": int(system["secondary_count"]),
            "final_count": int(system["final_count"]),
            "star_type_raw": int(system["star_type_raw"]),
            "star_colour_confirmed": system["star_colour_confirmed"],
            "system_index": int(system["system_index"]),
            "radial_star_cutoff": int(
                system["coordinate_config"]["radial_star_cutoff"]
            ),
        },
        "class_mode": class_mode,
        "final_classes": classes,
        "planet_structure": {
            "planet_sizes": [
                int(value) for value in structure["planet_sizes"]
            ],
            "primary_parent_indices": [
                int(value)
                for value in structure["primary_parent_indices"]
            ],
        },
        "direct_rng_budget": {
            "biome_entry_offset": int(budget["entry_offset"]),
            "root_count": int(budget["root_count"]),
            "moon_parent_buckets": [
                int(value) for value in budget["moon_parent_buckets"]
            ],
        },
        "prediction_supported": supported,
        "bodies": bodies,
        "warnings": warnings,
        "controlled_validation_match": known is not None,
    }


def self_test(
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    vectors: dict[str, Any],
) -> list[str]:
    expected_classes = {
        "000000000000": [0, 1, 0, 0],
        "11680850FB82": [1, 0],
    }
    expected_offsets = {
        "000000000000": 11,
        "11680850FB82": 5,
    }

    lines: list[str] = []
    total = 0

    for vector in vectors["vectors"]:
        portal = str(vector["portal"])
        result = predict(portal, tables, catalogs, vectors)

        if not result["prediction_supported"]:
            raise AssertionError(f"Known vector unsupported: {portal}")

        got_classes = [int(value) for value in result["final_classes"]]
        if got_classes != expected_classes[portal]:
            raise AssertionError(
                f"Class mismatch for {portal}: "
                f"{got_classes} != {expected_classes[portal]}"
            )

        offset = int(
            result["direct_rng_budget"]["biome_entry_offset"]
        )
        if offset != expected_offsets[portal]:
            raise AssertionError(
                f"Offset mismatch for {portal}: "
                f"{offset} != {expected_offsets[portal]}"
            )

        got_biomes = [int(row["biome"]) for row in result["bodies"]]
        got_subtypes = [
            int(row["biome_subtype"]) for row in result["bodies"]
        ]
        expected_biomes = [
            int(value) for value in vector["final_biomes"]
        ]
        expected_subtypes = [
            int(value) for value in vector["final_subtypes"]
        ]
        if got_biomes != expected_biomes:
            raise AssertionError(
                f"Biome mismatch for {portal}: "
                f"{got_biomes} != {expected_biomes}"
            )
        if got_subtypes != expected_subtypes:
            raise AssertionError(
                f"Subtype mismatch for {portal}: "
                f"{got_subtypes} != {expected_subtypes}"
            )

        got_seeds = [
            str(row["planet_seed"]).upper()
            for row in result["bodies"]
        ]
        expected_seeds = [
            value.upper() for value in KNOWN_SEEDS[portal]
        ]
        if got_seeds != expected_seeds:
            raise AssertionError(
                f"Seed mismatch for {portal}: "
                f"{got_seeds} != {expected_seeds}"
            )

        count = len(expected_biomes)
        total += count
        lines.append(
            f"SYSTEM={portal} STATUS=PASS "
            f"CLASSES={count}/{count} "
            f"BIOMES={count}/{count} "
            f"FINAL_SUBTYPES={count}/{count} "
            f"SEEDS={count}/{count} "
            f"ENTRY_OFFSET={offset} "
            f"CLASS_MODE={result['class_mode']['mode']} "
            f"CLASS_ONE_POSITION="
            f"{result['class_mode']['class_one_position_1_based']}"
        )

    lines.extend(
        [
            "KNOWN_SYSTEMS_MATCHED=2/2",
            f"FINAL_CLASSES_MATCHED={total}/{total}",
            f"FINAL_BIOMES_MATCHED={total}/{total}",
            f"FINAL_BIOME_SUBTYPES_MATCHED={total}/{total}",
            f"PLANET_SEEDS_MATCHED={total}/{total}",
            "ADDRESS_ONLY_PIPELINE_COMPLETE_FOR_CONTROLLED_STANDARD_BRANCH=True",
            "STARTYPE4_SPECIAL_BRANCH_SUPPORTED=False",
            "RUNTIME_GLOBAL_CLASS_MODE3_OVERRIDE_SUPPORTED=False",
        ]
    )
    return lines


def format_report(result: dict[str, Any]) -> str:
    address = result["address"]
    system = result["system"]
    class_mode = result["class_mode"]
    structure = result["planet_structure"]
    budget = result["direct_rng_budget"]

    lines = [
        "FIBONACCI NMS ADDRESS-ONLY BIOME + SUBTYPE PREDICTOR V2S",
        f"Version={VERSION}",
        "Mode=OFFLINE_NO_NMS_PROCESS",
        "",
        "ADDRESS",
        "-------",
        f"input_portal={address['input_portal']}",
        f"resolved_system_portal={address['resolved_system_portal']}",
        f"tkseed={address['tkseed']}",
        f"ssi=0x{address['ssi']:03X}",
        f"voxel_x={address['voxel_x']}",
        f"voxel_y={address['voxel_y']}",
        f"voxel_z={address['voxel_z']}",
        "",
        "ADDRESS-DERIVED SYSTEM",
        "----------------------",
        f"primary_count={system['primary_count']}",
        f"secondary_count={system['secondary_count']}",
        f"final_count={system['final_count']}",
        f"star_type_raw={system['star_type_raw']}",
        f"star_colour_confirmed={system['star_colour_confirmed']}",
        f"system_index={system['system_index']}",
        f"radial_star_cutoff={system['radial_star_cutoff']}",
        "",
        "FINAL CLASS ASSIGNMENT",
        "----------------------",
        f"class_mode={class_mode['mode']}",
        f"class_mode_reason={class_mode['reason']}",
        "class_one_position_1_based="
        f"{class_mode['class_one_position_1_based']}",
        f"final_classes={result['final_classes']}",
        "",
        "PLANET STRUCTURE + RNG BUDGET",
        "-----------------------------",
        f"planet_sizes={structure['planet_sizes']}",
        "primary_parent_indices="
        f"{structure['primary_parent_indices']}",
        f"biome_entry_offset={budget['biome_entry_offset']}",
        f"root_count={budget['root_count']}",
        f"moon_parent_buckets={budget['moon_parent_buckets']}",
        "",
        "PREDICTED PLANETS",
        "-----------------",
    ]

    for body in result["bodies"]:
        biome = (
            str(body["biome"])
            if body["biome"] is not None
            else "NOT_SUPPORTED"
        )
        subtype = (
            str(body["biome_subtype"])
            if body["biome_subtype"] is not None
            else "NOT_SUPPORTED"
        )
        lines.append(
            f"slot={body['slot']} "
            f"kind={body['kind']} "
            f"seed={body['planet_seed']} "
            f"PlanetSize={body['planet_size']} "
            f"Class={body['final_class']} "
            f"Biome={biome} "
            f"BiomeSubType={subtype} "
            f"known_label={body['known_visible_label']}"
        )

    lines.extend(
        [
            "",
            "VALIDITY",
            "--------",
            f"prediction_supported={result['prediction_supported']}",
            "controlled_validation_match="
            f"{result['controlled_validation_match']}",
        ]
    )
    for warning in result["warnings"]:
        lines.append(f"WARNING={warning}")

    lines.extend(
        [
            "",
            "CURRENT STATUS",
            "--------------",
            "address_only_body_counts=IMPLEMENTED",
            "address_only_star_type=IMPLEMENTED",
            "address_only_planet_sizes=IMPLEMENTED",
            "address_only_parent_indices=IMPLEMENTED",
            "address_only_planet_seeds=IMPLEMENTED",
            "address_only_biome_entry_offset=IMPLEMENTED",
            "address_only_final_class_assignment=IMPLEMENTED_STANDARD_BRANCH",
            "address_only_final_biome=IMPLEMENTED_STANDARD_BRANCH",
            "address_only_final_biome_subtype=IMPLEMENTED_STANDARD_BRANCH",
            "next_validation=CAPTURE_UNSEEN_VALID_SYSTEM_AND_COMPARE_ALL_FIELDS",
        ]
    )

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("portal", nargs="?")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    tables, catalogs, vectors = load_assets(base)

    if args.self_test:
        print("ADDRESS_ONLY_BIOME_SUBTYPE_V2S_SELF_TEST=PASS")
        for line in self_test(tables, catalogs, vectors):
            print(line)
        return 0

    portal = args.portal or input(
        "Enter a 12-glyph portal address: "
    ).strip()
    result = predict(portal, tables, catalogs, vectors)

    output = (
        json.dumps(result, indent=2) + "\n"
        if args.json
        else format_report(result)
    )
    print(output, end="")

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(3)
