#!/usr/bin/env python3
"""Professional reliability and user-workflow helpers for APF V19E."""
from __future__ import annotations

import csv
import json
import re
import shutil
import tempfile
import traceback as traceback_module
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

VERSION = "19E.1.0"
SCHEMA_VERSION = 1
PORTAL_PATTERN = re.compile(r"^[0-9A-F]{12}$")
SAFE_STEM_PATTERN = re.compile(r"[^A-Za-z0-9._-]+")


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def safe_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp_{stamp()}")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def validate_portal(value: str, *, label: str = "Portal address") -> str:
    cleaned = "".join(str(value or "").split()).upper()
    if not PORTAL_PATTERN.fullmatch(cleaned):
        raise ValueError(
            f"{label} must contain exactly 12 hexadecimal glyph values (0-9 or A-F)."
        )
    return cleaned


def parse_int_range(
    value: str | int,
    *,
    label: str,
    minimum: int,
    maximum: int,
    allow_blank: bool = False,
) -> int | None:
    text = str(value).strip()
    if allow_blank and not text:
        return None
    try:
        parsed = int(text, 10)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be a whole number.") from exc
    if not minimum <= parsed <= maximum:
        raise ValueError(f"{label} must be between {minimum} and {maximum}.")
    return parsed


def sanitise_stem(value: str, fallback: str = "any_planet_finder_export") -> str:
    stem = SAFE_STEM_PATTERN.sub("_", str(value or "").strip()).strip("._-")
    return stem or fallback


def make_search_profile(
    name: str,
    *,
    scope: dict[str, Any],
    filters: dict[str, Any],
) -> dict[str, Any]:
    clean_name = str(name or "").strip()
    if not clean_name:
        raise ValueError("Search profile name cannot be blank.")
    if len(clean_name) > 80:
        raise ValueError("Search profile name cannot exceed 80 characters.")
    if not isinstance(scope, dict) or not isinstance(filters, dict):
        raise TypeError("Search profile scope and filters must be objects.")
    return {
        "schema_version": SCHEMA_VERSION,
        "name": clean_name,
        "created_at": now_iso(),
        "scope": dict(scope),
        "filters": dict(filters),
    }


def validate_search_profile(profile: Any) -> dict[str, Any]:
    if not isinstance(profile, dict):
        raise ValueError("Search profile must be a JSON object.")
    if int(profile.get("schema_version", -1)) != SCHEMA_VERSION:
        raise ValueError("Unsupported search profile schema version.")
    name = str(profile.get("name", "")).strip()
    if not name or len(name) > 80:
        raise ValueError("Search profile has an invalid name.")
    scope = profile.get("scope")
    filters = profile.get("filters")
    if not isinstance(scope, dict) or not isinstance(filters, dict):
        raise ValueError("Search profile scope and filters must be objects.")
    return {
        "schema_version": SCHEMA_VERSION,
        "name": name,
        "created_at": str(profile.get("created_at") or now_iso()),
        "scope": dict(scope),
        "filters": dict(filters),
    }


def load_profile_store(path: Path) -> dict[str, dict[str, Any]]:
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        if int(payload.get("schema_version", -1)) != SCHEMA_VERSION:
            raise ValueError("Unsupported profile-store schema version.")
        raw_profiles = payload.get("profiles", [])
        if not isinstance(raw_profiles, list):
            raise ValueError("Profile store does not contain a profile list.")
        profiles: dict[str, dict[str, Any]] = {}
        for raw in raw_profiles:
            profile = validate_search_profile(raw)
            profiles[profile["name"]] = profile
        return profiles
    except Exception:
        backup = path.with_name(path.name + f".corrupt_{stamp()}")
        try:
            shutil.copy2(path, backup)
        except Exception:
            pass
        return {}


def save_profile_store(path: Path, profiles: Iterable[dict[str, Any]]) -> None:
    validated: dict[str, dict[str, Any]] = {}
    for raw in profiles:
        profile = validate_search_profile(raw)
        validated[profile["name"]] = profile
    payload = {
        "schema_version": SCHEMA_VERSION,
        "updated_at": now_iso(),
        "profiles": [validated[name] for name in sorted(validated, key=str.casefold)],
    }
    safe_json(path, payload)


def load_app_state(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        if int(payload.get("schema_version", -1)) != SCHEMA_VERSION:
            return {}
        state = payload.get("state", {})
        return dict(state) if isinstance(state, dict) else {}
    except Exception:
        return {}


def save_app_state(path: Path, state: dict[str, Any]) -> None:
    safe_json(
        path,
        {
            "schema_version": SCHEMA_VERSION,
            "updated_at": now_iso(),
            "state": dict(state),
        },
    )


PUBLIC_EXPORT_SCHEMA = "fibonacci.atlas_apf.search_export.v3"
PUBLIC_EXPORT_SCHEMA_VERSION = 3
CSV_AUTHORITATIVE_ROW_FIELD = "__atlas_apf_row_json_v3"
PUBLIC_EXPORT_EXCLUDED_FIELDS = frozenset({
    "system_portal",
    "system_address",
    "system_portal_address",
    "exact_system_portal_address",
    "canonical_system_portal",
    "resolved_system_portal",
    "system_glyphs",
    "system_glyph_address",
    "planet_portal",
    "planet_address",
    "portal",
    "export_planet_address_valid",
})

_EXPORT_LIST_FIELDS = frozenset({
    "description_lookup_key",
    "weather_lookup_key",
    "match_reasons",
    "sentinel_difficulty_names",
    "sentinel_difficulty_enums",
    "sentinel_difficulty_raw_enums",
    "sentinel_pre_generation_words_hex",
    "resource_level_preceding_words",
    "grass_primary_rgba",
    "grass_alt_primary_rgba",
})
_EXPORT_LIST_SUFFIXES = (
    "_categories",
    "_colours",
    "_candidates",
    "_enums",
    "_families",
    "_hex_values",
    "_ids",
    "_indices",
    "_kinds",
    "_labels",
    "_names",
    "_palette_colours",
    "_reasons",
    "_rgba",
    "_scenes",
    "_signals",
    "_tokens",
    "_words",
)
_EXPORT_NUMERIC_BLOCKERS = (
    "address",
    "portal",
    "glyph",
    "hex",
    "seed",
    "code",
    "version",
    "tag",
    "path",
    "file",
    "source",
    "name",
    "display",
    "summary",
    "claim",
    "status",
    "type",
)


def _export_field_is_list(key: str) -> bool:
    lowered = str(key or "").casefold()
    return lowered in _EXPORT_LIST_FIELDS or lowered.endswith(_EXPORT_LIST_SUFFIXES)


def _export_numeric_coercion_allowed(key: str) -> bool:
    lowered = str(key or "").casefold()
    return bool(lowered) and not any(token in lowered for token in _EXPORT_NUMERIC_BLOCKERS)


def _coerce_export_value(value: Any, *, key: str = "") -> Any:
    """Restore values written by current and legacy APF CSV exporters.

    Current CSV exports use JSON for every non-string scalar/collection. Older
    exports flattened list values with `` | ``.  Coercion is deliberately
    key-aware so twelve-glyph portal addresses and hexadecimal identifiers are
    never converted to numbers or stripped of leading zeroes.
    """
    if not isinstance(value, str):
        return value
    text = value.strip()
    if not text:
        return ""
    lowered = text.casefold()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in {"null", "none"}:
        return None
    if (text.startswith("[") and text.endswith("]")) or (
        text.startswith("{") and text.endswith("}")
    ):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    if " | " in text and _export_field_is_list(key):
        restored = []
        for item in text.split(" | "):
            restored.append(_coerce_export_value(item, key=""))
        return restored
    if _export_numeric_coercion_allowed(key):
        if re.fullmatch(r"-?\d+", text):
            try:
                return int(text, 10)
            except ValueError:
                pass
        if re.fullmatch(r"-?(?:\d+\.\d*|\d*\.\d+)(?:[eE][+-]?\d+)?", text):
            try:
                return float(text)
            except ValueError:
                pass
    return text


def normalise_export_row(row: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(row, dict):
        raise TypeError("Export rows must be objects.")
    output = {
        str(key): _coerce_export_value(value, key=str(key))
        for key, value in row.items()
    }
    exact_planet = "".join(str(
        output.get("exact_planet_portal_address")
        or output.get("planet_portal")
        or output.get("planet_address")
        or output.get("portal")
        or ""
    ).split()).upper()
    output["exact_planet_portal_address"] = exact_planet
    output["export_planet_address_valid"] = bool(
        PORTAL_PATTERN.fullmatch(exact_planet)
    )
    if not output.get("gameplay_planet_number"):
        output["gameplay_planet_number"] = output.get("planet_number", "")
    if not output.get("body_type_and_size_display"):
        output["body_type_and_size_display"] = (
            output.get("native_planet_size_class_display")
            or output.get("generated_body_class")
            or output.get("world_type_display")
            or output.get("planet_body_type_display")
            or output.get("world_type")
            or ""
        )
    if not output.get("planet_classification_display"):
        output["planet_classification_display"] = (
            output.get("classification")
            or output.get("planet_type_display")
            or output.get("planet_type")
            or ""
        )
    if not output.get("weather_display"):
        output["weather_display"] = output.get("weather") or ""
    if not output.get("biome_variant_display"):
        output["biome_variant_display"] = (
            output.get("subbiome")
            or output.get("biome_variant")
            or ""
        )
    if not output.get("terrain_family_display"):
        output["terrain_family_display"] = (
            output.get("terrain_type")
            or output.get("terrain")
            or ""
        )
    # v3 public-export migration.  Galaxy indices remain native 0..255 in
    # generation data while the GUI presents the customary 1..256 numbering.
    raw_galaxy = output.get("galaxy_index_internal", output.get("galaxy_index", 0))
    try:
        galaxy_index = int(raw_galaxy)
    except (TypeError, ValueError):
        galaxy_index = 0
    if 0 <= galaxy_index <= 255:
        output.setdefault("galaxy_index_internal", galaxy_index)
        output.setdefault("galaxy_number_user", galaxy_index + 1)
    output.setdefault("galaxy_name", "")
    output.setdefault("documented", False)
    output.setdefault("notes", "")
    return output


def _public_export_row(row: dict[str, Any]) -> dict[str, Any]:
    normalised = normalise_export_row(row)
    return {
        key: value
        for key, value in normalised.items()
        if key not in PUBLIC_EXPORT_EXCLUDED_FIELDS
        and not key.startswith("_")
    }


def _flatten_value(value: Any) -> str:
    """Write CSV values reversibly.

    Strings stay readable. Every collection and non-string scalar is encoded as
    JSON so View export can reconstruct booleans, numbers, lists and dictionaries
    exactly. This supersedes the legacy pipe-delimited list format while the
    loader remains backward compatible with it.
    """
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _export_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    excluded = {"matches", "planet_rows", "rows", "result"}
    return {key: value for key, value in payload.items() if key not in excluded}


def load_search_export(path: Path) -> dict[str, Any]:
    """Load and validate a current or legacy ATLAS APF JSON/CSV export."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Export file was not found: {path}")
    suffix = path.suffix.casefold()
    warnings: list[str] = []
    raw_rows: list[Any]
    metadata: dict[str, Any]

    if suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        rows_payload: Any = None
        metadata_source: dict[str, Any] = {}
        if isinstance(payload, dict):
            metadata_source = payload
            result_payload = payload.get("result")
            candidates = [
                payload.get("matches"),
                payload.get("planet_rows"),
                payload.get("rows"),
                result_payload.get("matches")
                if isinstance(result_payload, dict) else None,
                result_payload.get("planet_rows")
                if isinstance(result_payload, dict) else None,
                result_payload.get("rows")
                if isinstance(result_payload, dict) else None,
            ]
            for candidate in candidates:
                if isinstance(candidate, list):
                    rows_payload = candidate
                    break
            if isinstance(result_payload, dict) and rows_payload is not None:
                metadata_source = {
                    **_export_metadata(payload),
                    **_export_metadata(result_payload),
                }
        elif isinstance(payload, list):
            rows_payload = payload
            metadata_source = {"match_count": len(payload)}
        else:
            raise ValueError("JSON export must contain an object or row list.")
        if not isinstance(rows_payload, list):
            raise ValueError(
                "JSON export contains no matches, planet_rows or rows list."
            )
        raw_rows = rows_payload
        metadata = _export_metadata(metadata_source)
        source_format = "json"
    elif suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            csv_rows = list(reader)
        raw_rows = []
        authoritative_rows = 0
        authoritative_failures = 0
        for csv_row in csv_rows:
            encoded_row = csv_row.get(CSV_AUTHORITATIVE_ROW_FIELD, "")
            if encoded_row:
                try:
                    decoded_row = json.loads(encoded_row)
                except (json.JSONDecodeError, TypeError):
                    authoritative_failures += 1
                else:
                    if isinstance(decoded_row, dict):
                        raw_rows.append(decoded_row)
                        authoritative_rows += 1
                        continue
                    authoritative_failures += 1
            fallback_row = dict(csv_row)
            fallback_row.pop(CSV_AUTHORITATIVE_ROW_FIELD, None)
            raw_rows.append(fallback_row)
        if authoritative_failures:
            warnings.append(
                f"{authoritative_failures} current CSV row(s) had an invalid "
                "authoritative row payload and were restored from readable columns."
            )
        metadata = {
            "match_count": len(raw_rows),
            "csv_authoritative_rows": authoritative_rows,
        }
        source_format = "csv"
    else:
        raise ValueError("Choose a JSON or CSV export.")

    rows: list[dict[str, Any]] = []
    ignored_rows = 0
    for raw in raw_rows:
        if not isinstance(raw, dict):
            ignored_rows += 1
            continue
        row = normalise_export_row(dict(raw))
        row["_export_source_format"] = source_format
        rows.append(row)
    if ignored_rows:
        warnings.append(f"Ignored {ignored_rows} non-object row(s).")

    valid_addresses = [
        row["exact_planet_portal_address"]
        for row in rows
        if row.get("export_planet_address_valid")
    ]
    invalid_address_count = len(rows) - len(valid_addresses)
    if rows and not valid_addresses:
        raise ValueError(
            "The export contains rows but none has a valid 12-glyph planet address."
        )
    if invalid_address_count:
        warnings.append(
            f"{invalid_address_count} row(s) has no valid 12-glyph planet address."
        )
    duplicate_count = len(valid_addresses) - len(set(valid_addresses))
    if duplicate_count:
        warnings.append(
            f"The export contains {duplicate_count} duplicate planet address row(s)."
        )

    metadata = dict(metadata)
    metadata.setdefault("match_count", len(rows))
    return {
        "rows": rows,
        "metadata": metadata,
        "source_format": source_format,
        "source_path": str(path),
        "warnings": warnings,
        "row_count": len(rows),
        "valid_address_count": len(valid_addresses),
        "invalid_address_count": invalid_address_count,
        "duplicate_address_count": duplicate_count,
    }


def build_loaded_export_result(
    rows: Iterable[dict[str, Any]],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Construct a clean search-result payload for re-exporting loaded rows."""
    clean_rows = [_public_export_row(dict(row)) for row in rows]
    result = _export_metadata(dict(metadata or {}))
    result.update({
        "export_schema": PUBLIC_EXPORT_SCHEMA,
        "export_schema_version": PUBLIC_EXPORT_SCHEMA_VERSION,
        "status": result.get("status", "PASS_LOADED_EXPORT_REEXPORTED"),
        "match_count": len(clean_rows),
        "matches": clean_rows,
    })
    return result


def _scan_statistics_tabular_rows(statistics: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for section in ("system_state", "economy_type", "economy_tier", "conflict_level", "dominant_race"):
        for item in statistics.get(section, []) if isinstance(statistics.get(section), list) else []:
            rows.append({
                "section": section,
                "difficulty": "",
                "value": item.get("value", "Unknown"),
                "count": int(item.get("count", 0)),
                "percentage": float(item.get("percentage", 0.0)),
            })
    by_difficulty = statistics.get("sentinel_by_difficulty", {})
    if isinstance(by_difficulty, dict):
        for difficulty, items in by_difficulty.items():
            if not isinstance(items, list):
                continue
            for item in items:
                rows.append({
                    "section": "sentinel_activity",
                    "difficulty": str(difficulty),
                    "value": item.get("value", "Unknown"),
                    "count": int(item.get("count", 0)),
                    "percentage": float(item.get("percentage", 0.0)),
                })
    return rows


def export_scan_statistics_bundle(
    statistics: dict[str, Any],
    destination: Path,
    *,
    stem: str,
) -> dict[str, str]:
    destination.mkdir(parents=True, exist_ok=True)
    safe_stem = sanitise_stem(stem, "scan_statistics")
    json_path = destination / f"{safe_stem}.json"
    csv_path = destination / f"{safe_stem}.csv"
    text_path = destination / f"{safe_stem}.txt"
    payload = dict(statistics or {})
    payload.setdefault("scope", "all systems and planets actually generated before planet-match filters")
    payload["exported_at"] = now_iso()
    payload["schema"] = "fibonacci.atlas_apf.scan_statistics.v1"
    rows = _scan_statistics_tabular_rows(payload)
    safe_json(json_path, payload)
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=("section", "difficulty", "value", "count", "percentage"))
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        "ATLAS APF — SCAN STATISTICS",
        f"Exported={payload['exported_at']}",
        f"Scope={payload.get('scope', '')}",
        f"Systems scanned={payload.get('systems_scanned', 0)}",
        f"Planets scanned={payload.get('planets_scanned', 0)}",
        f"Unavailable system-selector rows={payload.get('unavailable_system_selector_rows', 0)}",
        "",
    ]
    current = None
    for row in rows:
        heading = row["section"] + (f" — {row['difficulty']}" if row["difficulty"] else "")
        if heading != current:
            if current is not None:
                lines.append("")
            lines.append(heading.upper())
            current = heading
        lines.append(f"{row['value']}: {row['count']} ({row['percentage']:.4f}%)")
    text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "csv": str(csv_path), "report": str(text_path)}


def normalize_export_formats(
    formats: Iterable[str] | None,
) -> tuple[str, ...]:
    """Return a stable, validated export-format tuple."""
    if formats is None:
        formats = ("csv", "json")
    selected: list[str] = []
    for value in formats:
        name = str(value or "").strip().casefold()
        if name not in {"csv", "json"}:
            raise ValueError("Export format must be CSV, JSON, or both.")
        if name not in selected:
            selected.append(name)
    if not selected:
        raise ValueError("Select at least one export format.")
    return tuple(selected)


def export_search_bundle(
    result: dict[str, Any],
    destination: Path,
    *,
    stem: str = "planet_search",
    formats: Iterable[str] | None = None,
    include_readable_report: bool = True,
    include_scan_statistics: bool = True,
) -> dict[str, str]:
    if not isinstance(result, dict) or not isinstance(result.get("matches"), list):
        raise ValueError("There is no completed Planet Finder result to export.")
    raw_rows = list(result.get("matches", []))
    if any(not isinstance(row, dict) for row in raw_rows):
        raise ValueError("Every Planet Finder export row must be an object.")
    selected_formats = normalize_export_formats(formats)
    rows = [_public_export_row(dict(row)) for row in raw_rows]
    destination.mkdir(parents=True, exist_ok=True)
    safe_stem = sanitise_stem(stem, "planet_search")
    json_path = destination / f"{safe_stem}.json"
    csv_path = destination / f"{safe_stem}.csv"
    text_path = destination / f"{safe_stem}.txt"

    public_result = _export_metadata(result)
    public_result.update({
        "export_schema": PUBLIC_EXPORT_SCHEMA,
        "export_schema_version": PUBLIC_EXPORT_SCHEMA_VERSION,
        "exported_at": now_iso(),
        "export_formats": list(selected_formats),
        "match_count": len(rows),
        "matches": rows,
    })

    if "json" in selected_formats:
        safe_json(json_path, public_result)

    readable_fieldnames = sorted({key for row in rows for key in row})
    fieldnames = [*readable_fieldnames, CSV_AUTHORITATIVE_ROW_FIELD]
    if "csv" in selected_formats:
        with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                csv_row = {
                    key: _flatten_value(row.get(key))
                    for key in readable_fieldnames
                }
                # CSV requires a common column set, so readable cells alone cannot
                # distinguish a field absent from one row from an explicit null in
                # another. This versioned row payload is authoritative on reload;
                # the ordinary columns remain intact for spreadsheets and humans.
                csv_row[CSV_AUTHORITATIVE_ROW_FIELD] = json.dumps(
                    row,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                writer.writerow(csv_row)

    lines = [
        "ATLAS APF — EXPORTED SEARCH",
        f"Exported={public_result['exported_at']}",
        f"Schema={PUBLIC_EXPORT_SCHEMA}",
        f"Status={public_result.get('status', '')}",
        f"Tested systems={public_result.get('tested_systems', 0)}",
        f"Tested planets={public_result.get('tested_planets', 0)}",
        f"Matches={len(rows)}",
        f"Cancelled={bool(public_result.get('cancelled'))}",
        "",
    ]
    for index, row in enumerate(rows, start=1):
        lines.extend(
            [
                f"[{index}] {row.get('exact_planet_portal_address') or row.get('planet_portal', '')}",
                f"Classification: {row.get('planet_classification_display', '')}",
                f"Weather: {row.get('weather_display', '')}",
                f"Fauna profile: {row.get('fauna_descriptor_primary_display', '')}",
                f"Archetype signals: {row.get('fauna_community_archetype_signal_summary', '')}",
                f"Why matched: {row.get('match_summary', '')}",
                "",
            ]
        )
    statistics = public_result.get("scan_statistics")
    statistics_paths: dict[str, str] = {}
    if isinstance(statistics, dict) and statistics:
        lines.extend([
            "SCAN STATISTICS",
            f"Scope: {statistics.get('scope', '')}",
            f"Systems scanned: {statistics.get('systems_scanned', 0)}",
            f"Planets scanned: {statistics.get('planets_scanned', 0)}",
            f"Unavailable system-selector rows: {statistics.get('unavailable_system_selector_rows', 0)}",
            "",
        ])
        if include_scan_statistics:
            statistics_paths = export_scan_statistics_bundle(
                statistics,
                destination,
                stem=f"{safe_stem}_scan_statistics",
            )
    if include_readable_report:
        text_path.write_text("\n".join(lines), encoding="utf-8")

    # Validate every format that was actually requested. CSV and JSON remain
    # independently reloadable, preserve row order, and carry identical public
    # planet records when both are selected.
    expected_addresses = [row.get("exact_planet_portal_address", "") for row in rows]
    expected_public_rows = [_public_export_row(row) for row in rows]
    loaded_by_format: dict[str, dict[str, Any]] = {}
    if "json" in selected_formats:
        loaded_by_format["json"] = load_search_export(json_path)
    if "csv" in selected_formats:
        loaded_by_format["csv"] = load_search_export(csv_path)
    for name, loaded in loaded_by_format.items():
        if loaded["row_count"] != len(rows):
            raise RuntimeError(f"{name.upper()} export round-trip row count validation failed.")
        if [row.get("exact_planet_portal_address", "") for row in loaded["rows"]] != expected_addresses:
            raise RuntimeError(f"{name.upper()} export planet-address round trip failed.")
        if [_public_export_row(row) for row in loaded["rows"]] != expected_public_rows:
            raise RuntimeError(f"{name.upper()} export full-row round trip failed.")

    exported = {
        "folder": str(destination),
        "row_count": str(len(rows)),
        "schema": PUBLIC_EXPORT_SCHEMA,
        "formats": "|".join(selected_formats),
        "file_count": str(
            len(selected_formats) + (1 if include_readable_report else 0)
        ),
    }
    if "json" in selected_formats:
        exported["json"] = str(json_path)
    if "csv" in selected_formats:
        exported["csv"] = str(csv_path)
    if include_readable_report:
        exported["report"] = str(text_path)
    if statistics_paths:
        exported.update({
            "statistics_json": statistics_paths["json"],
            "statistics_csv": statistics_paths["csv"],
            "statistics_report": statistics_paths["report"],
        })
    return exported


COMPARISON_FIELDS: tuple[tuple[str, str], ...] = (
    ("exact_planet_portal_address", "Portal Address"),
    ("body_type_and_size_display", "World type / generated size"),
    ("rings_display", "Rings"),
    ("planet_classification_display", "Classification"),
    ("weather_display", "Weather"),
    ("resources_display", "Resources"),
    ("fauna_display", "Fauna"),
    ("flora_display", "Flora"),
    ("fauna_descriptor_primary_display", "Fauna profile"),
    ("fauna_community_archetype_signal_summary", "Archetype signals"),
    ("literal_paradise", "Paradise"),
    ("is_weather_extreme", "Extreme weather"),
    ("water_active", "Water"),
    ("infested_planet", "Infested"),
    ("dissonant_planet", "Dissonant"),
    ("sentinel_level", "Legacy Sentinel level"),
    ("sentinel_difficulty_names", "Sentinel D0/D1/D2/D3"),
)


def build_comparison(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not 2 <= len(rows) <= 6:
        raise ValueError("Select between 2 and 6 planets to compare.")
    columns = [str(row.get("exact_planet_portal_address") or row.get("planet_portal") or f"Planet {index + 1}") for index, row in enumerate(rows)]
    comparison_rows = []
    for key, label in COMPARISON_FIELDS:
        comparison_rows.append(
            {
                "field": key,
                "label": label,
                "values": [_flatten_value(row.get(key)) for row in rows],
            }
        )
    return {
        "schema_version": SCHEMA_VERSION,
        "created_at": now_iso(),
        "columns": columns,
        "rows": comparison_rows,
    }


def comparison_text(comparison: dict[str, Any]) -> str:
    columns = list(comparison.get("columns", []))
    lines = ["ATLAS APF — PLANET COMPARISON", ""]
    lines.append("Planets: " + " | ".join(columns))
    lines.append("")
    for row in comparison.get("rows", []):
        lines.append(f"{row.get('label', '')}: " + " | ".join(row.get("values", [])))
    return "\n".join(lines) + "\n"


def write_error_bundle(
    output_root: Path,
    *,
    operation: str,
    exception: BaseException,
    traceback_text: str = "",
) -> dict[str, str]:
    folder = output_root / f"gui_error_{stamp()}"
    folder.mkdir(parents=True, exist_ok=False)
    if not traceback_text:
        traceback_text = "".join(
            traceback_module.format_exception(
                type(exception), exception, exception.__traceback__
            )
        )
    payload = {
        "version": VERSION,
        "schema_version": SCHEMA_VERSION,
        "timestamp": now_iso(),
        "operation": str(operation),
        "exception_type": type(exception).__name__,
        "error": str(exception),
        "traceback": traceback_text,
    }
    json_path = folder / "gui_error_v19e.json"
    report_path = folder / "OPEN_THIS_GUI_ERROR_V19E.txt"
    safe_json(json_path, payload)
    report_path.write_text(
        "\n".join(
            [
                "ATLAS APF — GUI ERROR V19E",
                f"Timestamp={payload['timestamp']}",
                f"Operation={payload['operation']}",
                f"Exception={payload['exception_type']}",
                f"Error={payload['error']}",
                "",
                "TRACEBACK",
                "---------",
                payload["traceback"],
            ]
        ),
        encoding="utf-8",
    )
    return {"folder": str(folder), "json": str(json_path), "report": str(report_path)}


def _metric(correct: int, total: int) -> dict[str, Any]:
    return {"correct": correct, "total": total, "exact": correct == total}


def run_regression() -> dict[str, Any]:
    metrics: dict[str, dict[str, Any]] = {}
    failures: list[str] = []

    portal_cases = [
        ("020b239d7f56", True),
        (" 020B239D7F56 ", True),
        ("020B239D7F5", False),
        ("020B239D7F5Z", False),
    ]
    portal_correct = 0
    for value, expected in portal_cases:
        try:
            validate_portal(value)
            actual = True
        except ValueError:
            actual = False
        portal_correct += int(actual == expected)
    metrics["portal_validation"] = _metric(portal_correct, len(portal_cases))

    int_cases = [
        ("0", 0, 255, True),
        ("255", 0, 255, True),
        ("256", 0, 255, False),
        ("-1", 0, 255, False),
        ("abc", 0, 255, False),
        ("", 0, 255, False),
    ]
    int_correct = 0
    for value, minimum, maximum, expected in int_cases:
        try:
            parse_int_range(value, label="Value", minimum=minimum, maximum=maximum)
            actual = True
        except ValueError:
            actual = False
        int_correct += int(actual == expected)
    metrics["integer_validation"] = _metric(int_correct, len(int_cases))

    with tempfile.TemporaryDirectory(prefix="apf_v19e_regression_") as temp_text:
        temp = Path(temp_text)
        store_path = temp / "profiles.json"
        profiles = [
            make_search_profile(
                "My Paradise",
                scope={"anchor": "020B239D7F56", "galaxy": 0},
                filters={"paradise": "Must include"},
            ),
            make_search_profile(
                "Dissonant",
                scope={"anchor": "020B239D7F56", "galaxy": 0},
                filters={"dissonant": "Must include"},
            ),
        ]
        save_profile_store(store_path, profiles)
        loaded = load_profile_store(store_path)
        checks = [
            store_path.is_file(),
            sorted(loaded) == ["Dissonant", "My Paradise"],
            loaded["My Paradise"]["filters"]["paradise"] == "Must include",
            loaded["Dissonant"]["scope"]["galaxy"] == 0,
            json.loads(store_path.read_text(encoding="utf-8"))["schema_version"] == 1,
        ]
        metrics["profile_roundtrip"] = _metric(sum(checks), len(checks))

        corrupt_path = temp / "corrupt_profiles.json"
        corrupt_path.write_text("{not valid json", encoding="utf-8")
        recovered = load_profile_store(corrupt_path)
        corrupt_backups = list(temp.glob("corrupt_profiles.json.corrupt_*"))
        metrics["profile_corruption_recovery"] = _metric(
            int(recovered == {}) + int(len(corrupt_backups) == 1), 2
        )

        state_path = temp / "state.json"
        save_app_state(state_path, {"geometry": "1200x800", "portal": "020B239D7F56"})
        loaded_state = load_app_state(state_path)
        metrics["state_roundtrip"] = _metric(
            int(loaded_state.get("geometry") == "1200x800")
            + int(loaded_state.get("portal") == "020B239D7F56"),
            2,
        )

        sample_result = {
            "status": "PASS_CORE_V1_REGION_SEARCH",
            "tested_systems": 2,
            "tested_planets": 6,
            "match_count": 2,
            "cancelled": False,
            "matches": [
                {
                    "planet_portal": "100000000001",
                    "system_portal": "000000000001",
                    "planet_classification_display": "Paradise Planet",
                    "weather_display": "Mild Rain",
                    "match_summary": "Paradise",
                    "match_reasons": ["Paradise", "No storms"],
                    "sentinel_difficulty_names": ["Rare", "Default", "Default", "Default"],
                    "sentinel_activity_by_on_foot_combat": {"Standard": "Low"},
                    "moon_count": 2,
                    "water_active": True,
                    "biome_subtype": 27,
                    "source_system_kind": 1,
                    "resource_level_random_f32": 0.8555606603622437,
                    "present_none": None,
                    "present_empty_string": "",
                },
                {
                    "planet_portal": "200000000002",
                    "system_portal": "000000000002",
                    "planet_classification_display": "Frozen Planet",
                    "weather_display": "Icy Tempests",
                    "match_summary": "Extreme weather",
                    "match_reasons": ["Extreme weather"],
                    "sentinel_difficulty_names": ["Rare", "Rare", "Aggressive", "Aggressive"],
                    "sentinel_activity_by_on_foot_combat": {"Standard": "High"},
                    "moon_count": 0,
                    "water_active": False,
                },
            ],
        }
        export = export_search_bundle(sample_result, temp / "export", stem="Test Export")
        json_payload = json.loads(Path(export["json"]).read_text(encoding="utf-8"))
        with Path(export["csv"]).open("r", encoding="utf-8-sig", newline="") as handle:
            csv_rows_raw = list(csv.DictReader(handle))
        loaded_json = load_search_export(Path(export["json"]))
        loaded_csv = load_search_export(Path(export["csv"]))

        legacy_csv = temp / "legacy_export.csv"
        legacy_csv.write_text(
            "planet_portal,classification,weather,sentinel_difficulty_names,match_reasons\n"
            '300000000003,Paradise Planet,Clear,"Rare | Default | Default | Default","Paradise | No storms"\n',
            encoding="utf-8-sig",
        )
        loaded_legacy = load_search_export(legacy_csv)

        nested_json = temp / "nested_export.json"
        safe_json(nested_json, {
            "wrapper": "legacy",
            "result": {
                "tested_systems": 4,
                "tested_planets": 20,
                "matches": [{
                    "planet_address": "400000000004",
                    "classification": "Toxic Planet",
                    "weather": "Stinging Puddles",
                }],
            },
        })
        loaded_nested = load_search_export(nested_json)

        empty_export = export_search_bundle(
            {"status": "PASS_EMPTY", "matches": []},
            temp / "empty_export",
            stem="Empty Export",
        )
        loaded_empty_csv = load_search_export(Path(empty_export["csv"]))

        expected_public_rows = [
            _public_export_row(row) for row in sample_result["matches"]
        ]
        public_row_keys = set(json_payload["matches"][0])
        export_checks = [
            Path(export["json"]).is_file(),
            Path(export["csv"]).is_file(),
            Path(export["report"]).is_file(),
            json_payload["match_count"] == 2,
            json_payload["export_schema"] == PUBLIC_EXPORT_SCHEMA,
            "Paradise Planet" in Path(export["csv"]).read_text(encoding="utf-8-sig"),
            "Frozen Planet" in Path(export["report"]).read_text(encoding="utf-8"),
            "system_portal" not in public_row_keys,
            "planet_portal" not in public_row_keys,
            "exact_planet_portal_address" in public_row_keys,
            loaded_json["row_count"] == 2,
            loaded_csv["row_count"] == 2,
            loaded_json["rows"][0]["exact_planet_portal_address"] == "100000000001",
            loaded_csv["rows"][0]["exact_planet_portal_address"] == "100000000001",
            loaded_json["rows"][0]["match_reasons"] == ["Paradise", "No storms"],
            loaded_csv["rows"][0]["match_reasons"] == ["Paradise", "No storms"],
            loaded_csv["rows"][0]["sentinel_activity_by_on_foot_combat"] == {"Standard": "Low"},
            loaded_csv["rows"][0]["moon_count"] == 2,
            loaded_csv["rows"][0]["water_active"] is True,
            len(csv_rows_raw) == 2,
            loaded_legacy["rows"][0]["sentinel_difficulty_names"] == ["Rare", "Default", "Default", "Default"],
            loaded_legacy["rows"][0]["match_reasons"] == ["Paradise", "No storms"],
            loaded_legacy["rows"][0]["planet_classification_display"] == "Paradise Planet",
            loaded_nested["metadata"].get("tested_systems") == 4,
            loaded_nested["rows"][0]["exact_planet_portal_address"] == "400000000004",
            loaded_nested["rows"][0]["planet_classification_display"] == "Toxic Planet",
            CSV_AUTHORITATIVE_ROW_FIELD in csv_rows_raw[0],
            loaded_csv["metadata"].get("csv_authoritative_rows") == 2,
            [_public_export_row(row) for row in loaded_json["rows"]] == expected_public_rows,
            [_public_export_row(row) for row in loaded_csv["rows"]] == expected_public_rows,
            loaded_csv["rows"][0]["biome_subtype"] == 27,
            isinstance(loaded_csv["rows"][0]["biome_subtype"], int),
            loaded_csv["rows"][0]["source_system_kind"] == 1,
            loaded_csv["rows"][0]["resource_level_random_f32"] == 0.8555606603622437,
            "present_none" in loaded_csv["rows"][0]
            and loaded_csv["rows"][0]["present_none"] is None,
            loaded_csv["rows"][0]["present_empty_string"] == "",
            loaded_empty_csv["row_count"] == 0,
            CSV_AUTHORITATIVE_ROW_FIELD
            in Path(empty_export["csv"]).read_text(encoding="utf-8-sig"),
        ]
        metrics["export_bundle"] = _metric(sum(export_checks), len(export_checks))

        comparison = build_comparison(sample_result["matches"])
        comparison_checks = [
            len(comparison["columns"]) == 2,
            len(comparison["rows"]) == len(COMPARISON_FIELDS),
            comparison["columns"][0] == "100000000001",
            "Paradise Planet" in comparison_text(comparison),
        ]
        metrics["comparison"] = _metric(sum(comparison_checks), len(comparison_checks))

        error = ValueError("intentional regression error")
        error_paths = write_error_bundle(
            temp,
            operation="Regression",
            exception=error,
            traceback_text="intentional traceback",
        )
        error_payload = json.loads(Path(error_paths["json"]).read_text(encoding="utf-8"))
        error_checks = [
            Path(error_paths["report"]).is_file(),
            error_payload["operation"] == "Regression",
            "intentional traceback" in Path(error_paths["report"]).read_text(encoding="utf-8"),
        ]
        metrics["error_bundle"] = _metric(sum(error_checks), len(error_checks))

    exact = all(metric["exact"] for metric in metrics.values())
    for name, metric in metrics.items():
        if not metric["exact"]:
            failures.append(name)
    return {
        "version": VERSION,
        "status": (
            "PASS_PROFESSIONAL_HARDENING_REGRESSION_V19E_EXACT"
            if exact
            else "ERROR_PROFESSIONAL_HARDENING_REGRESSION_V19E"
        ),
        "exact": exact,
        "metrics": metrics,
        "failures": failures,
        "claim_boundary": {
            "persistent_user_state": True,
            "custom_search_profiles": True,
            "search_cancellation_core_contract": True,
            "manual_export_bundle": True,
            "planet_comparison": True,
            "structured_gui_error_reports": True,
            "prediction_logic_changed": False,
        },
    }


if __name__ == "__main__":
    print(json.dumps(run_regression(), indent=2))
