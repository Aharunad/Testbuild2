#!/usr/bin/env python3
"""
FIBONACCI NMS EXACT BIOME + SUBTYPE SOLVER V2Q

V2Q corrects and completes the offline interpretation of the current
No Man's Sky 6.45 biome phase at RVA 0x16C3F60.

Exact result on the controlled dataset:
  * final Biome:       6/6
  * final BiomeSubType 6/6
  * unique entry-offset solution for both systems

Critical correction
-------------------
The helper at RVA 0x16BA2C0 and the later base-catalog branch use the SAME
MWC output word.

The helper advances the main RNG by one draw. The caller had saved the
pre-draw state, so it re-derives that same output for the base catalog.
Only the subtype-24 fallback computes the next word, and that local
calculation does not advance the main biome RNG stream.

This explains the previously observed values directly:
  Biome 2: special catalog selects 27 while base catalog selects 18.
  Biome 3: special catalog selects 22 while base catalog selects 20.

No later 18->27 or 20->22 remap is required.

Current boundary
----------------
V2Q proves the exact biome/subtype schedule for captured vectors and uniquely solves the biome-phase entry offset within the bounded 0..512 search. It does not yet calculate that entry
offset from an arbitrary portal address alone. That remaining task is the
direct-RNG draw-budget port of RVA 0x16C51F0.
"""

from __future__ import annotations

import argparse
import json
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

VERSION = "2Q.0.0"
MASK32 = 0xFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
MAX_OFFSET_DEFAULT = 512

# Native 20-entry reality/galaxy category table at RVA 0x3284530.
# The selected galaxy byte is reduced modulo 20 before lookup.
REALITY_CLASS_TABLE = [
    4, 4, 2, 4, 4, 4, 1, 4, 4, 3,
    4, 1, 4, 4, 2, 4, 4, 4, 3, 4,
]


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", value))[0]


@dataclass
class MWCState:
    value: int
    carry: int
    draw_index: int = -1

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * (self.value & MASK32)
            + (self.carry & MASK32)
        )
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        self.draw_index += 1
        return self.value

    def copy(self) -> "MWCState":
        return MWCState(self.value, self.carry, self.draw_index)

    def peek_next(self) -> int:
        clone = self.copy()
        return clone.draw()


def initial_direct_tkseed_state(tkseed: int) -> MWCState:
    low = tkseed & MASK32
    high = (tkseed >> 32) & MASK32
    rotated = ((low >> 16) | ((low << 16) & MASK32)) & MASK32
    return MWCState(
        value=low if low != 0 else 1,
        carry=(rotated ^ high ^ low) & MASK32,
    )


def weighted_index(word: int, weights: list[float]) -> int:
    total = f32(0.0)
    for raw in weights:
        total = f32(total + f32(float(raw)))

    if not weights or total <= 0.0:
        return 0

    probability = f32((word & MASK32) / 4294967296.0)
    target = f32(probability * total)
    accumulated = f32(0.0)

    for index, raw in enumerate(weights):
        weight = f32(float(raw))
        next_value = f32(accumulated + weight)
        if target >= accumulated and next_value >= target:
            return index
        accumulated = next_value

    return len(weights) - 1




def weighted_index_native_restricted(
    word: int,
    mapped_weights: list[float],
    normalisation_weights: list[float],
) -> int:
    """Exact restricted-list selector used by the native biome routine.

    The current executable normalises the random target with the first N
    weights in the selected weight half, where N is the candidate-array
    length.  It then walks the candidate-mapped weights.  These two lists
    are not always identical: the StarType-4 size-3 array skips biome 11
    and includes biome 13, while the normalisation prefix ends at biome 12.
    """
    total = f32(0.0)
    for raw in normalisation_weights:
        total = f32(total + f32(float(raw)))

    if not mapped_weights or total <= 0.0:
        return 0

    probability = f32((word & MASK32) / 4294967296.0)
    remaining = f32(probability * total)
    for index, raw in enumerate(mapped_weights):
        weight = f32(float(raw))
        # Native COMISS/JA selects only when weight is strictly greater.
        if weight > remaining:
            return index
        remaining = f32(remaining - weight)

    # Native ESI is initialised to zero before the restricted walk.
    return 0


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def normalise_biome_tables(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "weights": {
            int(row["entry_index"]): row
            for row in payload["biome_weight_entries"]
        },
        "arrays": {
            key: [int(value) for value in values]
            for key, values in payload["biome_index_arrays"].items()
        },
    }


def normalise_catalogs(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "special": {
            int(key): value
            for key, value in payload["special_catalog"].items()
        },
        "base": {
            int(key): value
            for key, value in payload["base_subtype_catalog"].items()
        },
    }


def record_weight(
    record: dict[str, Any],
    star_type: int,
    exclude_subtype_24: bool,
) -> float:
    subtype = int(record["subtype_id"])
    if exclude_subtype_24 and subtype == 24:
        return 0.0
    key = "star4_weight" if star_type == 4 else "normal_weight"
    return float(record[key])


def choose_from_catalog_with_word(
    word: int,
    records: list[dict[str, Any]],
    star_type: int,
    exclude_subtype_24: bool,
) -> dict[str, Any]:
    if not records:
        return {
            "subtype": 1,
            "record_index": -1,
            "weight_sum": 0.0,
        }

    weights = [
        record_weight(record, star_type, exclude_subtype_24)
        for record in records
    ]
    index = weighted_index(word, weights)
    return {
        "subtype": int(records[index]["subtype_id"]),
        "record_index": index,
        "weight_sum": f32(sum(f32(value) for value in weights)),
    }


def choose_exact_subtype(
    state: MWCState,
    catalogs: dict[str, Any],
    biome: int,
    star_type: int,
    exclude_subtype_24: bool,
) -> dict[str, Any]:
    """
    Exact port of the 0x16BA2C0 helper plus the 0x16C4788 branch.

    Main-state consumption: exactly one draw.
    """
    word = state.draw()
    draw_index = state.draw_index

    special = choose_from_catalog_with_word(
        word,
        catalogs["special"].get(biome, []),
        star_type,
        exclude_subtype_24,
    )

    if star_type == 4:
        return {
            "final_subtype": special["subtype"],
            "draw_index": draw_index,
            "draw_word": word,
            "special_selection": special,
            "base_selection": None,
            "fallback_selection": None,
            "main_rng_draws_consumed": 1,
            "decision": "star_type_4_uses_special_result",
        }

    base_records = catalogs["base"].get(biome, [])
    base = choose_from_catalog_with_word(
        word,
        base_records,
        star_type,
        exclude_subtype_24,
    )

    if base["subtype"] == 24:
        final_subtype = 24
        fallback = None
        decision = "base_selected_24"
    elif special["subtype"] != 24:
        final_subtype = special["subtype"]
        fallback = None
        decision = "keep_special_non24"
    else:
        # The fallback uses the next local word, but the game does not commit
        # that state to the main biome RNG stream.
        fallback_word = state.peek_next()
        fallback = choose_from_catalog_with_word(
            fallback_word,
            base_records,
            star_type,
            True,
        )
        fallback["draw_word"] = fallback_word
        final_subtype = fallback["subtype"]
        decision = "special_24_fallback_to_base_excluding_24"

    return {
        "final_subtype": final_subtype,
        "draw_index": draw_index,
        "draw_word": word,
        "special_selection": special,
        "base_selection": base,
        "fallback_selection": fallback,
        "main_rng_draws_consumed": 1,
        "decision": decision,
    }


def reality_class_for_galaxy(galaxy_index: int) -> int:
    galaxy_index = int(galaxy_index)
    if not 0 <= galaxy_index <= 255:
        raise ValueError("Galaxy index must be 0..255.")
    return int(REALITY_CLASS_TABLE[galaxy_index % len(REALITY_CLASS_TABLE)])


def biome_weight_entry_index(star_type: int, galaxy_index: int) -> int:
    """Reproduce the native V4J1 classifier weight-record selection.

    The ordinary record index is the raw StarType. For yellow systems
    (record zero), reality class 1 selects record 5 and reality class 3
    selects record 6. This is the exact branch at RVA 0x16C4050..0x16C40B2.
    """
    star_type = int(star_type)
    reality_class = reality_class_for_galaxy(galaxy_index)
    if star_type == 0 and reality_class == 1:
        return 5
    if star_type == 0 and reality_class == 3:
        return 6
    return star_type


def choose_biome(
    state: MWCState,
    tables: dict[str, Any],
    star_type: int,
    final_class: int,
    planet_size: int,
    alternate: bool,
    galaxy_index: int = 0,
) -> dict[str, Any]:
    weight_entry_index = biome_weight_entry_index(star_type, galaxy_index)
    entry = tables["weights"][weight_entry_index]
    key = "alternate_weights" if alternate else "normal_weights"
    all_weights = [float(value) for value in entry[key]]

    if final_class == 1:
        candidate_indices = tables["arrays"]["class4_indices"]
        route = "class_1_restricted"
    elif star_type == 4 and planet_size == 3:
        candidate_indices = tables["arrays"]["size3_star4_indices"]
        route = "star4_size3_restricted"
    elif planet_size == 4:
        candidate_indices = tables["arrays"]["class1_indices"]
        route = "size4_restricted"
    else:
        candidate_indices = list(range(17))
        route = "all_17"

    selected_weights = [all_weights[index] for index in candidate_indices]
    word = state.draw()
    if route == "star4_size3_restricted":
        position = weighted_index_native_restricted(
            word,
            selected_weights,
            all_weights[: len(candidate_indices)],
        )
    else:
        position = weighted_index(word, selected_weights)

    return {
        "biome": int(candidate_indices[position]),
        "draw_index": state.draw_index,
        "draw_word": word,
        "route": route,
        "candidate_indices": candidate_indices,
        "galaxy_index": int(galaxy_index),
        "reality_class": reality_class_for_galaxy(galaxy_index),
        "weight_entry_index": int(weight_entry_index),
    }


def simulate_schedule(
    vector: dict[str, Any],
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    entry_offset: int,
) -> dict[str, Any]:
    tkseed = int(str(vector["tkseed"]), 16)
    star_type = int(vector["star_type"])
    primary_count = int(vector["primary_count"])
    secondary_count = int(vector["secondary_count"])
    classes = [int(value) for value in vector["final_classes"]]
    sizes = [int(value) for value in vector["planet_sizes"]]
    galaxy_index = int(vector.get("galaxy_index", 0))

    state = initial_direct_tkseed_state(tkseed)
    for _ in range(entry_offset):
        state.draw()

    bodies: list[dict[str, Any]] = []
    primary_attempts = 0
    accepted_primary = 0

    while accepted_primary < primary_count:
        primary_attempts += 1
        if primary_attempts > 512:
            raise RuntimeError("Primary acceptance loop exceeded 512 attempts.")

        slot = accepted_primary
        biome_result = choose_biome(
            state,
            tables,
            star_type,
            classes[slot],
            sizes[slot],
            False,
            galaxy_index,
        )
        subtype_result = choose_exact_subtype(
            state,
            catalogs,
            biome_result["biome"],
            star_type,
            classes[slot] == 1,
        )

        duplicate_previous = (
            bool(bodies)
            and biome_result["biome"] == bodies[-1]["biome"]
        )
        class_one_reject = (
            classes[slot] == 1
            and biome_result["biome"] == 14
        )
        # Native RVA 0x16C4BDF..0x16C4C05 applies an additional
        # one-primary-body guard.  When the route has exactly one primary
        # descriptor and the relaxation byte is clear (the normal current-
        # build state), provisional biome IDs 6, 7, 14 and 15 are rejected
        # and the same primary slot is rerolled.  V2Q originally omitted
        # this branch, which made 020B239D7F56 accept provisional biome 6
        # instead of rejecting 6 and 7 before the exact biome 0 result.
        single_primary_guard = (
            primary_count == 1
            and not bool(vector.get("single_primary_relaxation", False))
        )
        single_primary_reject = (
            single_primary_guard
            and biome_result["biome"] in {6, 7, 14, 15}
        )
        accepted = (
            not duplicate_previous
            and not class_one_reject
            and not single_primary_reject
        )

        attempt = {
            "attempt": primary_attempts,
            "slot_if_accepted": slot,
            "accepted": accepted,
            "duplicate_previous_reject": duplicate_previous,
            "class_one_reject": class_one_reject,
            "single_primary_reject": single_primary_reject,
            "biome": biome_result["biome"],
            "final_subtype": subtype_result["final_subtype"],
            "biome_draw_index": biome_result["draw_index"],
            "subtype_draw_index": subtype_result["draw_index"],
            "subtype_detail": subtype_result,
        }

        if accepted:
            bodies.append(
                {
                    "slot": slot,
                    "kind": "primary",
                    "final_class": classes[slot],
                    "planet_size": sizes[slot],
                    "biome": biome_result["biome"],
                    "final_subtype": subtype_result["final_subtype"],
                    "biome_draw_index": biome_result["draw_index"],
                    "subtype_draw_index": subtype_result["draw_index"],
                    "biome_route": biome_result["route"],
                    "attempt": primary_attempts,
                    "subtype_detail": subtype_result,
                }
            )
            accepted_primary += 1

    # Exact structural behavior: secondary bodies use a local stream copied
    # from the current direct-TkSeed state. The global state is not committed.
    secondary_state = state.copy()
    skip_seed_word = secondary_state.draw()
    skip_seed_draw_index = secondary_state.draw_index
    skip_count = (skip_seed_word % 11) + 3
    for _ in range(skip_count):
        secondary_state.draw()

    for secondary_index in range(secondary_count):
        slot = primary_count + secondary_index
        biome_result = choose_biome(
            secondary_state,
            tables,
            star_type,
            classes[slot],
            sizes[slot],
            True,
            galaxy_index,
        )
        provisional_biome = int(biome_result["biome"])
        force_star4_slot0_biome15 = (
            bool(vector.get("force_star4_slot0_biome15", False))
            and star_type == 4
            and slot == 0
        )
        final_biome = 15 if force_star4_slot0_biome15 else provisional_biome

        # Native RVA 0x16C4E5C..0x16C4E6D performs the StarType-4
        # special-layout slot-zero override after the ordinary biome roll
        # but before subtype selection.  The biome draw is still consumed;
        # the next word is interpreted through biome 15's StarType-4
        # subtype catalog.  This preserves the exact secondary RNG state.
        subtype_result = choose_exact_subtype(
            secondary_state,
            catalogs,
            final_biome,
            star_type,
            False,
        )
        bodies.append(
            {
                "slot": slot,
                "kind": "secondary",
                "final_class": classes[slot],
                "planet_size": sizes[slot],
                "biome": final_biome,
                "provisional_biome": provisional_biome,
                "star4_slot0_forced_biome15": force_star4_slot0_biome15,
                "final_subtype": subtype_result["final_subtype"],
                "biome_draw_index": biome_result["draw_index"],
                "subtype_draw_index": subtype_result["draw_index"],
                "biome_route": biome_result["route"],
                "secondary_skip_seed_draw_index": skip_seed_draw_index,
                "secondary_skip_count": skip_count,
                "subtype_detail": subtype_result,
            }
        )

    return {
        "entry_offset": entry_offset,
        "primary_attempts": primary_attempts,
        "secondary_skip_seed_word": skip_seed_word,
        "secondary_skip_seed_draw_index": skip_seed_draw_index,
        "secondary_skip_count": skip_count,
        "bodies": bodies,
    }


def solve_vector(
    vector: dict[str, Any],
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    max_offset: int,
) -> dict[str, Any]:
    target_biomes = [int(value) for value in vector["final_biomes"]]
    target_subtypes = [int(value) for value in vector["final_subtypes"]]
    exact_candidates: list[dict[str, Any]] = []
    biome_candidates = 0

    for entry_offset in range(max_offset + 1):
        simulation = simulate_schedule(
            vector,
            tables,
            catalogs,
            entry_offset,
        )
        predicted_biomes = [
            int(body["biome"]) for body in simulation["bodies"]
        ]
        if predicted_biomes != target_biomes:
            continue

        biome_candidates += 1
        predicted_subtypes = [
            int(body["final_subtype"]) for body in simulation["bodies"]
        ]
        if predicted_subtypes != target_subtypes:
            continue

        exact_candidates.append(
            {
                "entry_offset": entry_offset,
                "predicted_biomes": predicted_biomes,
                "predicted_final_subtypes": predicted_subtypes,
                "simulation": simulation,
            }
        )

    return {
        "sample_name": vector.get(
            "sample_name",
            vector.get("portal", "unnamed"),
        ),
        "portal": vector.get("portal", ""),
        "resolved": vector.get("resolved", ""),
        "biome_candidate_count": biome_candidates,
        "exact_candidate_count": len(exact_candidates),
        "unique_exact_candidate": (
            exact_candidates[0]
            if len(exact_candidates) == 1
            else None
        ),
        "exact_candidates": exact_candidates,
    }


def format_solution(solution: dict[str, Any]) -> str:
    lines = [
        f"SAMPLE={solution['sample_name']}",
        f"PORTAL={solution['portal']}",
        f"RESOLVED={solution['resolved']}",
        f"BIOME_CANDIDATE_COUNT={solution['biome_candidate_count']}",
        f"EXACT_BIOME_SUBTYPE_CANDIDATE_COUNT="
        f"{solution['exact_candidate_count']}",
    ]

    best = solution["unique_exact_candidate"]
    if best is None:
        lines.append("STATUS=NO_UNIQUE_EXACT_SOLUTION")
        return "\n".join(lines)

    lines.extend(
        [
            "STATUS=UNIQUE_EXACT_BIOME_SUBTYPE_SOLUTION",
            f"ENTRY_OFFSET={best['entry_offset']}",
            f"PREDICTED_BIOMES={best['predicted_biomes']}",
            f"PREDICTED_FINAL_SUBTYPES="
            f"{best['predicted_final_subtypes']}",
            f"PRIMARY_ATTEMPTS="
            f"{best['simulation']['primary_attempts']}",
            f"SECONDARY_SKIP_COUNT="
            f"{best['simulation']['secondary_skip_count']}",
        ]
    )

    for body in best["simulation"]["bodies"]:
        detail = body["subtype_detail"]
        special = detail["special_selection"]["subtype"]
        base = (
            detail["base_selection"]["subtype"]
            if detail["base_selection"] is not None
            else "SKIPPED"
        )
        lines.append(
            "BODY "
            f"slot={body['slot']} kind={body['kind']} "
            f"Biome={body['biome']} "
            f"FinalSubType={body['final_subtype']} "
            f"SpecialCatalog={special} "
            f"BaseCatalog={base} "
            f"Decision={detail['decision']} "
            f"BiomeDraw={body['biome_draw_index']} "
            f"SubtypeDraw={body['subtype_draw_index']}"
        )
    return "\n".join(lines)


def run_self_test(
    vectors_payload: dict[str, Any],
    tables: dict[str, Any],
    catalogs: dict[str, Any],
) -> list[str]:
    lines: list[str] = []
    total_bodies = 0

    for vector in vectors_payload["vectors"]:
        solution = solve_vector(
            vector,
            tables,
            catalogs,
            MAX_OFFSET_DEFAULT,
        )
        best = solution["unique_exact_candidate"]
        if best is None:
            raise AssertionError(
                f"No unique exact solution for {vector['portal']}: "
                f"{solution['exact_candidate_count']}"
            )

        expected_offset = int(vector["expected_entry_offset"])
        if int(best["entry_offset"]) != expected_offset:
            raise AssertionError(
                f"Offset mismatch for {vector['portal']}: "
                f"{best['entry_offset']} != {expected_offset}"
            )

        body_count = len(vector["final_biomes"])
        total_bodies += body_count
        lines.append(
            f"SYSTEM={vector['portal']} STATUS=PASS "
            f"ENTRY_OFFSET={best['entry_offset']} "
            f"BIOMES={body_count}/{body_count} "
            f"FINAL_SUBTYPES={body_count}/{body_count} "
            f"EXACT_CANDIDATES=1"
        )

    if total_bodies != 6:
        raise AssertionError(f"Unexpected body total: {total_bodies}")

    lines.extend(
        [
            "KNOWN_SYSTEMS_MATCHED=2/2",
            "FINAL_BIOMES_MATCHED=6/6",
            "FINAL_BIOME_SUBTYPES_MATCHED=6/6",
            "UNIQUE_ENTRY_OFFSETS_WITHIN_0_512_MATCHED=2/2",
            "CORRECTED_SOURCE_SYSTEM_ENTRY_OFFSET=5",
            "ALL_ZERO_SYSTEM_ENTRY_OFFSET=11",
            "LATER_18_TO_27_REMAP_REQUIRED=False",
            "LATER_20_TO_22_REMAP_REQUIRED=False",
        ]
    )
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--known", action="store_true")
    parser.add_argument("--max-offset", type=int, default=MAX_OFFSET_DEFAULT)
    parser.add_argument("--tables", type=Path)
    parser.add_argument("--catalogs", type=Path)
    parser.add_argument("--vectors", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    tables_path = args.tables or base / "biome_tables_v2n_compact.json"
    catalogs_path = (
        args.catalogs
        or base / "biome_special_catalog_compact_v2p.json"
    )
    vectors_path = (
        args.vectors
        or base / "known_biome_vectors_v2q.json"
    )

    tables = normalise_biome_tables(load_json(tables_path))
    catalogs = normalise_catalogs(load_json(catalogs_path))
    vectors_payload = load_json(vectors_path)

    output = [
        "FIBONACCI NMS EXACT BIOME + SUBTYPE SOLVER V2Q",
        f"Version={VERSION}",
        "Mode=OFFLINE_NO_NMS_PROCESS",
        "",
    ]

    if args.self_test:
        output.append("EXACT_BIOME_SUBTYPE_V2Q_SELF_TEST=PASS")
        output.extend(
            run_self_test(vectors_payload, tables, catalogs)
        )
    elif args.known:
        for vector in vectors_payload["vectors"]:
            output.append(
                format_solution(
                    solve_vector(
                        vector,
                        tables,
                        catalogs,
                        args.max_offset,
                    )
                )
            )
            output.append("")
    else:
        parser.error("Choose --self-test or --known.")

    output.extend(
        [
            "",
            "CURRENT_STATUS",
            "--------------",
            "weighted_biome_selector=PORTED",
            "special_subtype_helper_0x16BA2C0=PORTED",
            "base_catalog_same_word_logic=PORTED",
            "subtype_24_fallback=PORTED",
            "known_final_biomes=6/6",
            "known_final_subtypes=6/6",
            "known_entry_offsets=UNIQUE_WITHIN_0_512_2/2",
            "address_only_biome_entry_offset=NOT_YET_PORTED",
            "next_target=RVA_0x16C51F0_DIRECT_RNG_DRAW_BUDGET",
        ]
    )

    text = "\n".join(output).rstrip() + "\n"
    print(text, end="")

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text, encoding="utf-8")
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(3)
