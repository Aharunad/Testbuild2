#!/usr/bin/env python3
from __future__ import annotations

import colorsys
import json
from pathlib import Path
from typing import Any

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997
DUPLICATE_DISTANCE_THRESHOLD = 2.3283064365386963e-10


def rotate_right_32(value: int, count: int) -> int:
    count &= 31
    if count == 0:
        return value & MASK32
    return (
        ((value >> count) | (value << (32 - count)))
        & MASK32
    )


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


class MWCState:
    def __init__(self, low: int, carry: int):
        self.low = low & MASK32
        self.carry = carry & MASK32
        self.draw_count = 0

    @classmethod
    def from_seed(cls, seed: int) -> "MWCState":
        low = seed & MASK32
        if low == 0:
            low = 1
        high_word = (seed >> 32) & MASK32
        carry = (
            rotate_right_32(low, 16)
            ^ high_word
            ^ low
        ) & MASK32
        return cls(low, carry)

    def copy(self) -> "MWCState":
        other = MWCState(self.low, self.carry)
        other.draw_count = self.draw_count
        return other

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * self.low + self.carry
        ) & MASK64
        self.low = total & MASK32
        self.carry = (total >> 32) & MASK32
        self.draw_count += 1
        return self.low


def generate_child_seeds(root_seed: int, count: int = 26) -> list[int]:
    state = MWCState.from_seed(root_seed)
    children = []
    for _ in range(count):
        first = state.draw()
        second = state.draw()
        children.append(
            avalanche_mix_64(
                ((second & MASK32) << 32) | (first & MASK32)
            )
        )
    return children


def selector_local_seed(source_seed: int) -> int:
    state = MWCState.from_seed(source_seed)
    first = state.draw()
    second = state.draw()
    return avalanche_mix_64(
        ((second & MASK32) << 32) | (first & MASK32)
    )


def planet_palette_writer_seed(root_seed: int) -> int:
    child_3 = generate_child_seeds(root_seed, 3)[2]
    return selector_local_seed(child_3)


def initial_source_index(
    state: MWCState,
    num_colours_enum: int,
) -> int:
    first = state.draw()
    second = state.draw()
    first_top = first >> 29
    second_top = second >> 29

    if num_colours_enum == 1:
        return 0
    if num_colours_enum == 2:
        return (
            (second_top >> 2) + (first_top >> 2) * 8
        ) * 4
    if num_colours_enum == 3:
        return second_top
    if num_colours_enum == 4:
        return (
            (second_top >> 1) + (first_top >> 1) * 8
        ) * 2
    return second_top + first_top * 8


def squared_distance(
    left: list[float],
    right: list[float],
) -> float:
    return sum(
        (float(left[index]) - float(right[index])) ** 2
        for index in range(4)
    )


def write_one_palette(
    state: MWCState,
    palette: dict[str, Any],
) -> dict[str, Any]:
    indices = []
    colours = []

    for _output_slot in range(5):
        source_index = initial_source_index(
            state,
            int(palette["num_colours_enum"]),
        )
        colour = palette["colours"][source_index]

        retries = 0
        while retries < 64:
            duplicate = any(
                DUPLICATE_DISTANCE_THRESHOLD
                > squared_distance(colour, previous)
                for previous in colours
            )
            if not duplicate:
                break
            source_index = (source_index + 1) % 64
            colour = palette["colours"][source_index]
            retries += 1

        indices.append(int(source_index))
        colours.append([float(value) for value in colour])

    return {
        "source_indices": indices,
        "colours": colours,
        "draw_count_after": state.draw_count,
    }


def derive_seed_pair(state: MWCState) -> tuple[int, int]:
    draw_1 = state.draw()
    draw_2 = state.draw()
    draw_3 = state.draw()
    draw_4 = state.draw()
    seed_a = avalanche_mix_64((draw_2 << 32) | draw_1)
    seed_b = avalanche_mix_64((draw_4 << 32) | draw_3)
    return seed_a, seed_b


def derive_one_seed(state: MWCState) -> int:
    """Derive one native child seed from two consecutive MWC words."""
    draw_1 = state.draw()
    draw_2 = state.draw()
    return avalanche_mix_64((draw_2 << 32) | draw_1)


def rgba_hex(colour: list[float]) -> str:
    rgb = [
        max(0, min(255, round(float(value) * 255.0)))
        for value in colour[:3]
    ]
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def colour_family(colour: list[float]) -> str:
    r = min(max(float(colour[0]), 0.0), 1.0)
    g = min(max(float(colour[1]), 0.0), 1.0)
    b = min(max(float(colour[2]), 0.0), 1.0)
    hue, saturation, value = colorsys.rgb_to_hsv(r, g, b)
    degrees = hue * 360.0

    if value < 0.12:
        return "Black / very dark"
    if saturation < 0.10 and value > 0.85:
        return "White / pale neutral"
    if saturation < 0.15:
        return "Grey / neutral"
    if degrees < 15 or degrees >= 345:
        return "Red"
    if degrees < 40:
        return "Orange"
    if degrees < 70:
        return "Yellow"
    if degrees < 165:
        return "Green"
    if degrees < 195:
        return "Cyan"
    if degrees < 255:
        return "Blue"
    if degrees < 290:
        return "Purple"
    return "Pink / magenta"


class GrassColourRule:
    def __init__(self, rule_data_path: Path):
        self.data = json.loads(
            rule_data_path.read_text(encoding="utf-8-sig")
        )
        self.base_path = self.data["base_palette_path"]
        self.base_palettes = self.data["palette_lists"][
            self.base_path
        ]

    def merged_palette_list(
        self,
        biome_source_file: str,
    ) -> tuple[str, list[dict[str, Any]]]:
        source = biome_source_file.replace("\\", "/").strip().upper()
        palette_path = self.data["biome_source_to_palette"][source]
        source_palettes = self.data["palette_lists"][palette_path]

        merged = []
        for base, selected in zip(
            self.base_palettes,
            source_palettes,
        ):
            merged.append(
                base
                if int(selected["num_colours_enum"]) == 0
                else selected
            )
        return palette_path, merged

    def predict(
        self,
        *,
        planet_root_seed: int,
        biome_source_file: str,
    ) -> dict[str, Any]:
        palette_path, palettes = self.merged_palette_list(
            biome_source_file
        )
        writer_seed = planet_palette_writer_seed(
            planet_root_seed
        )

        main_state = MWCState.from_seed(writer_seed)
        saved_palette_56_state = None
        water = None

        # Native initial loop is 0..51 inclusive. The generated Water channel
        # is palette 15. Palette 56 later reuses the state saved immediately
        # before initial palette 10 rather than advancing the final-loop state.
        for palette_index in range(52):
            if palette_index == 10:
                saved_palette_56_state = main_state.copy()
            raw = write_one_palette(
                main_state,
                palettes[palette_index],
            )
            if palette_index == 15:
                water = raw

        _seed_a, grass_seed = derive_seed_pair(main_state)

        # Native code resets the same seed independently for Grass and
        # GrassAlt. After GrassAlt is written, two further words from that
        # post-write state form the seed used by final palettes 52..63.
        grass = write_one_palette(
            MWCState.from_seed(grass_seed),
            palettes[0],
        )
        grass_alt_state = MWCState.from_seed(grass_seed)
        grass_alt = write_one_palette(
            grass_alt_state,
            palettes[51],
        )
        final_palette_seed = derive_one_seed(grass_alt_state)
        final_state = MWCState.from_seed(final_palette_seed)
        deep_water_biolum = None
        for palette_index in range(52, 64):
            state = (
                saved_palette_56_state
                if palette_index == 56
                else final_state
            )
            raw = write_one_palette(state, palettes[palette_index])
            if palette_index == 63:
                deep_water_biolum = raw

        if water is None or deep_water_biolum is None:
            raise RuntimeError("Native Water palette replay did not produce both channels.")

        def channel_result(
            name: str,
            palette_index: int,
            raw: dict[str, Any],
        ) -> dict[str, Any]:
            colour_rows = []
            for slot, (source_index, colour) in enumerate(
                zip(raw["source_indices"], raw["colours"])
            ):
                colour_rows.append({
                    "slot": slot,
                    "source_index": source_index,
                    "rgba": colour,
                    "hex": rgba_hex(colour),
                    "colour_family": colour_family(colour),
                })
            return {
                "channel": name,
                "palette_index": palette_index,
                "num_colours_name": palettes[palette_index][
                    "num_colours_name"
                ],
                "source_indices": raw["source_indices"],
                "colours": colour_rows,
                "primary": colour_rows[0],
            }

        return {
            "planet_root_seed_hex": (
                f"0x{planet_root_seed & MASK64:016X}"
            ),
            "palette_writer_seed_hex": f"0x{writer_seed:016X}",
            "palette_writer_seed_rule": (
                "selector_local(orchestrator_child_3(planet_root_seed))"
            ),
            "biome_source_file": (
                biome_source_file.replace("\\", "/").strip().upper()
            ),
            "colour_palette_file": palette_path,
            "inactive_fallback_file": self.base_path,
            "grass": channel_result("Grass", 0, grass),
            "grass_alt": channel_result(
                "GrassAlt", 51, grass_alt
            ),
            "water": channel_result("Water", 15, water),
            "deep_water_biolum": channel_result(
                "DeepWaterBioLum", 63, deep_water_biolum
            ),
            "final_palette_seed_hex": f"0x{final_palette_seed:016X}",
            "claim": (
                "Exact generated Grass, GrassAlt, Water and DeepWaterBioLum "
                "palette sequences. Selected WATERCOLOURS style, final visible "
                "model channel and renderer colour grading remain separate."
            ),
        }
