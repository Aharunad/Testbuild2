#!/usr/bin/env python3
"""Exact address-only special-system state replay for Core V1.0.8."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

VERSION = "16C.0.0"

EXPECTED_MAPPING = {
    "in_abandoned_system": "abandoned_flag_250",
    "in_empty_system": "source_system_kind_equals_7",
    "in_gas_giant_system": "weather_suppression_raw2d",
    "in_pirate_system": "historical_flag_253_raw25",
}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def predict_system_state(
    life_engine,
    portal: str,
    galaxy_index: int = 0,
) -> dict[str, Any]:
    """Normalize the proven V16C mapping into product-facing fields."""
    source = life_engine.predict_system_state(portal, galaxy_index)
    return {
        **source,
        "in_abandoned_system": bool(source["in_abandoned_system"]),
        "in_empty_system": bool(source["in_empty_system"]),
        "in_gas_giant_system": bool(
            source.get(
                "in_gas_giant_system",
                source.get("in_gas_giant_system_candidate", False),
            )
        ),
        "in_pirate_system": bool(
            source.get(
                "in_pirate_system",
                source.get("in_pirate_system_candidate", False),
            )
        ),
        "raw2c_auxiliary_flag": bool(
            source.get("unmapped_system_flag_252", False)
        ),
        "special_system_mapping": dict(EXPECTED_MAPPING),
        "system_state_status": (
            "PASS_ADDRESS_ONLY_SPECIAL_SYSTEM_REPLAY_V16C_EXACT"
        ),
    }


def verify_static(regression_path: Path) -> dict[str, Any]:
    model = load_json(regression_path)
    metrics = model.get("metrics", {})
    checks = {
        "model_version": (
            model.get("version") == "special-system-regression-v2"
        ),
        "mapping_exact": model.get("mapping") == EXPECTED_MAPPING,
        "controls_9_of_9": (
            int(metrics.get("controls_correct", -1)) == 9
            and int(metrics.get("controls_total", -1)) == 9
        ),
        "fields_36_of_36": (
            int(metrics.get("fields_correct", -1)) == 36
            and int(metrics.get("fields_total", -1)) == 36
        ),
        "model_exact": bool(metrics.get("exact")),
        "all_control_rows_exact": all(
            bool(row.get("exact")) for row in model.get("controls", [])
        ),
    }
    return {
        "version": VERSION,
        "checks": checks,
        "exact": all(checks.values()),
    }


def run_regression(
    life_engine,
    regression_path: Path,
) -> dict[str, Any]:
    model = load_json(regression_path)
    static = verify_static(regression_path)
    fields = (
        "in_abandoned_system",
        "in_empty_system",
        "in_gas_giant_system",
        "in_pirate_system",
    )
    rows = []
    correct_controls = 0
    correct_fields = 0
    total_fields = 0

    for control in model.get("controls", []):
        predicted = predict_system_state(
            life_engine,
            str(control["portal"]),
        )
        actual = control["actual"]
        checks = {
            field: bool(predicted[field]) == bool(actual[field])
            for field in fields
        }
        exact = all(checks.values())
        correct_controls += int(exact)
        correct_fields += sum(int(value) for value in checks.values())
        total_fields += len(checks)
        rows.append({
            "portal": control["portal"],
            "source": control.get("source", ""),
            "actual": actual,
            "predicted": {
                field: predicted[field] for field in fields
            },
            "checks": checks,
            "exact": exact,
        })

    total_controls = len(rows)
    exact = bool(
        static["exact"]
        and total_controls == 9
        and correct_controls == 9
        and total_fields == 36
        and correct_fields == 36
    )
    return {
        "version": VERSION,
        "status": (
            "PASS_ADDRESS_ONLY_SPECIAL_SYSTEM_REPLAY_V16C_EXACT"
            if exact
            else "ERROR_ADDRESS_ONLY_SPECIAL_SYSTEM_REPLAY_V16C"
        ),
        "static": static,
        "metrics": {
            "controls": {
                "correct": correct_controls,
                "total": total_controls,
                "exact": correct_controls == total_controls == 9,
            },
            "fields": {
                "correct": correct_fields,
                "total": total_fields,
                "exact": correct_fields == total_fields == 36,
            },
        },
        "rows": rows,
        "exact": exact,
    }
