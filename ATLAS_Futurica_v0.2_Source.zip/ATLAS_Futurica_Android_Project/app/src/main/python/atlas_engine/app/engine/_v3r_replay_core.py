#!/usr/bin/env python3
"""
FIBONACCI NMS VARIABLE SCHEDULE REPLAY V3R

Read-only offline validation stage for the Any Planet Finder project.

This program combines:
- V3M's ten-system, 45-planet, 917-row resolved source corpus;
- V3P's selector-local RNG seed derivation;
- V3Q's attempted-entry order and variable draw schedule.

It reconstructs every attempted direct row and optional group, replays the
known selector-local draw schedule, and tests the six previously controlled
planet-seed MWC factories across a configurable shared-stream offset range.

It does NOT modify the game, saves, mods, process memory, or source reports.
It does NOT claim a complete address-only planet predictor.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import multiprocessing as mp
import os
import sys
import traceback
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

VERSION = "3R.0.0"
TAG = "variable_schedule_replay_v3r"
MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997
DEFAULT_MAX_OFFSET = 8192
DEFAULT_TOP_N = 50

# Event opcodes used by the compact replay plan.
DIRECT_REJECTED = 0
DIRECT_ACCEPTED_UNINFORMATIVE = 1
DIRECT_ACCEPTED_INFORMATIVE = 2
OPTIONAL_INACTIVE = 3
OPTIONAL_ACTIVE = 4


@dataclass
class MWCState:
    value: int
    carry: int

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * (self.value & MASK32)
            + (self.carry & MASK32)
        )
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        return self.value

    def copy(self) -> "MWCState":
        return MWCState(self.value, self.carry)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def rotate_right_32(value: int, count: int) -> int:
    count &= 31
    return (
        ((value >> count) | (value << (32 - count)))
        & MASK32
    )


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


def state_direct_64(seed: int) -> MWCState:
    low = seed & MASK32
    high = (seed >> 32) & MASK32
    low = low if low != 0 else 1
    return MWCState(
        low,
        (rotate_right_32(low, 16) ^ high ^ low) & MASK32,
    )


def state_avalanche_64(seed: int) -> MWCState:
    return state_direct_64(avalanche_mix_64(seed))


def state_from_word(word: int) -> MWCState:
    value = word & MASK32
    value = value if value != 0 else 1
    return MWCState(
        value,
        (rotate_right_32(value, 16) ^ value) & MASK32,
    )


def state_low_word(seed: int) -> MWCState:
    return state_from_word(seed & MASK32)


def state_high_word(seed: int) -> MWCState:
    return state_from_word((seed >> 32) & MASK32)


def state_xor_word(seed: int) -> MWCState:
    return state_from_word(
        ((seed & MASK32) ^ ((seed >> 32) & MASK32)) & MASK32
    )


def state_add_word(seed: int) -> MWCState:
    return state_from_word(
        ((seed & MASK32) + ((seed >> 32) & MASK32)) & MASK32
    )


STATE_FACTORIES: dict[str, Callable[[int], MWCState]] = {
    "direct_seed64": state_direct_64,
    "avalanche_seed64": state_avalanche_64,
    "low32_word": state_low_word,
    "high32_word": state_high_word,
    "xor32_word": state_xor_word,
    "add32_word": state_add_word,
}


def select_mulhi(word: int, count: int) -> int:
    if count <= 1:
        return 0
    return ((word & MASK32) * count) >> 32


def normalize_path(value: Any) -> str:
    return str(value or "").replace("\\", "/").upper()


def parse_seed(value: Any) -> int:
    if isinstance(value, int):
        return value & MASK64
    return int(str(value), 0) & MASK64


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def latest_matching(root: Path, pattern: str) -> Path:
    matches = [p for p in root.glob(pattern) if p.is_dir()]
    if not matches:
        raise FileNotFoundError(f"No folder matching {pattern!r} under {root}")
    return max(matches, key=lambda p: p.stat().st_mtime)


def find_default_inputs() -> tuple[Path, Path, Path]:
    runtime_root = HERE.parent / "data" / "runtime_maps"
    v3m_dir = latest_matching(
        runtime_root, "multi_system_source_rng_discriminator_v3m_*"
    )
    v3p_dir = latest_matching(
        runtime_root, "selector_rng_provenance_draw_map_v3p_*"
    )
    v3q_dir = latest_matching(
        runtime_root, "input_order_gate_semantics_v3q_*"
    )
    return (
        v3m_dir / "multi_system_source_rng_discriminator_v3m.json",
        v3p_dir / "selector_rng_provenance_draw_map_v3p.json",
        v3q_dir / "input_order_gate_semantics_v3q.json",
    )


def source_identity(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        row.get("source_scope"),
        normalize_path(row.get("source_file")),
        row.get("name"),
        tuple(normalize_path(x) for x in (row.get("options") or [])),
        row.get("optional_group_id"),
    )


def parse_source_material(
    v3m_json_path: Path,
    source_core,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]], dict[str, Path]]:
    v3m_dir = v3m_json_path.parent
    catalogue_xml = (
        v3m_dir
        / "workspace_catalogue"
        / "extracted"
        / "METADATA"
        / "SIMULATION"
        / "SOLARSYSTEM"
        / "BIOMES"
        / "BIOMEFILENAMES.MXML"
    )
    biome_root = v3m_dir / "workspace_biomes" / "extracted"
    if not catalogue_xml.is_file():
        raise FileNotFoundError(f"Catalogue MXML missing: {catalogue_xml}")
    if not biome_root.is_dir():
        raise FileNotFoundError(f"Biome workspace missing: {biome_root}")

    catalogue = source_core.parse_biome_filenames(catalogue_xml)
    parsed_biomes: dict[str, dict[str, Any]] = {}
    source_paths: dict[str, Path] = {}
    for xml_path in biome_root.rglob("*.MXML"):
        if xml_path.name.upper() == "BIOMEFILENAMES.MXML":
            continue
        relative = xml_path.relative_to(biome_root).as_posix()
        source_mbin = relative[:-5] + ".MBIN"
        key = normalize_path(source_mbin)
        parsed_biomes[key] = source_core.parse_biome_data(
            xml_path, source_mbin
        )
        source_paths[key] = xml_path
    return catalogue, parsed_biomes, source_paths


def build_plans(
    v3m: dict[str, Any],
    catalogue: dict[str, Any],
    parsed_biomes: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    plans: list[dict[str, Any]] = []
    schedule_rows: list[dict[str, Any]] = []
    order_exact = 0
    order_mismatch: list[dict[str, Any]] = []
    source_mapping_leftovers: list[dict[str, Any]] = []
    optional_count_anomalies: list[dict[str, Any]] = []

    for planet_key, observation in sorted(
        v3m["planet_observations"].items()
    ):
        selected = (
            observation.get("biome_source_selection", {})
            .get("selected", {})
        )
        source_mbin = normalize_path(selected.get("source_mbin"))
        biome_data = parsed_biomes.get(source_mbin)
        if biome_data is None:
            raise KeyError(
                f"Parsed biome source not found for {planet_key}: {source_mbin}"
            )

        direct_rows = [
            dict(row) for row in biome_data.get("external_rows", [])
        ] + [dict(row) for row in catalogue.get("common_rows", [])]

        accepted_direct: dict[tuple[Any, ...], list[dict[str, Any]]] = (
            defaultdict(list)
        )
        accepted_optional_by_group: dict[str, list[dict[str, Any]]] = (
            defaultdict(list)
        )
        observed_tags: list[str] = []
        for runtime_row in observation.get("rows", []):
            scope = runtime_row.get("source_scope")
            if scope in {"biome", "common"}:
                accepted_direct[source_identity(runtime_row)].append(
                    runtime_row
                )
                observed_tags.append(
                    "D:" + "|".join(map(str, source_identity(runtime_row)))
                )
            elif scope == "optional":
                group_id = str(runtime_row.get("optional_group_id"))
                accepted_optional_by_group[group_id].append(runtime_row)
                observed_tags.append(f"G:{group_id}")

        entries: list[dict[str, Any]] = []
        insertion = 0
        for row in direct_rows:
            identity = source_identity(row)
            matches = accepted_direct.get(identity) or []
            accepted = matches.pop(0) if matches else None
            entries.append(
                {
                    "entry_type": "direct",
                    "sort_key": int(row.get("order") or 0),
                    "insertion_index": insertion,
                    "row": row,
                    "accepted": accepted,
                }
            )
            insertion += 1

        for group in catalogue.get("optional_groups", []):
            nested_orders = [
                int(row.get("order") or 0)
                for row in group.get("rows", [])
            ]
            entries.append(
                {
                    "entry_type": "optional_group",
                    "sort_key": max(nested_orders or [0]),
                    "insertion_index": insertion,
                    "group": group,
                    "accepted_rows": list(
                        accepted_optional_by_group.get(
                            str(group.get("id")), []
                        )
                    ),
                }
            )
            insertion += 1

        # V3Q identifies ascending Order. Python's stable tie handling is an
        # explicit audit assumption; mismatches are recorded rather than hidden.
        entries.sort(key=lambda item: item["sort_key"])

        predicted_tags: list[str] = []
        events: list[tuple[Any, ...]] = []
        informative_count = 0
        accepted_direct_count = 0
        accepted_optional_count = 0

        for sequence_index, entry in enumerate(entries):
            if entry["entry_type"] == "direct":
                row = entry["row"]
                accepted = entry["accepted"]
                if accepted is None:
                    events.append((DIRECT_REJECTED,))
                    event_name = "direct_rejected"
                else:
                    accepted_direct_count += 1
                    predicted_tags.append(
                        "D:" + "|".join(map(str, source_identity(accepted)))
                    )
                    probability = float(row.get("probability") or 0.0)
                    option_count = len(row.get("options") or [])
                    if accepted.get("informative"):
                        events.append(
                            (
                                DIRECT_ACCEPTED_INFORMATIVE,
                                probability,
                                option_count,
                                int(accepted.get("selected_index", 0)),
                            )
                        )
                        informative_count += 1
                        event_name = "direct_accepted_informative"
                    else:
                        events.append(
                            (DIRECT_ACCEPTED_UNINFORMATIVE, probability)
                        )
                        event_name = "direct_accepted_uninformative"
                schedule_rows.append(
                    {
                        "planet_key": planet_key,
                        "sequence_index": sequence_index,
                        "sort_key": entry["sort_key"],
                        "insertion_index": entry["insertion_index"],
                        "entry_type": "direct",
                        "event": event_name,
                        "name_or_group": row.get("name"),
                        "source_scope": row.get("source_scope"),
                        "source_file": row.get("source_file"),
                        "probability": row.get("probability"),
                        "min_files": None,
                        "max_files": None,
                        "observed_selected_count": 1 if accepted else 0,
                        "informative": bool(
                            accepted and accepted.get("informative")
                        ),
                    }
                )
            else:
                group = entry["group"]
                group_id = str(group.get("id"))
                accepted_rows = entry["accepted_rows"]
                selected_count = len(accepted_rows)
                accepted_optional_count += selected_count
                predicted_tags.extend(
                    f"G:{group_id}" for _ in range(selected_count)
                )
                rules = group.get("rules") or {}
                minimum = int(rules.get("min_files_to_choose") or 0)
                maximum = int(rules.get("max_files_to_choose") or 0)
                if selected_count > 0:
                    events.append(
                        (OPTIONAL_ACTIVE, minimum, maximum, selected_count)
                    )
                    event_name = "optional_active"
                    if not minimum <= selected_count <= maximum:
                        optional_count_anomalies.append(
                            {
                                "planet_key": planet_key,
                                "group_id": group_id,
                                "observed_selected_count": selected_count,
                                "min_files": minimum,
                                "max_files": maximum,
                            }
                        )
                else:
                    events.append((OPTIONAL_INACTIVE,))
                    event_name = "optional_inactive"
                schedule_rows.append(
                    {
                        "planet_key": planet_key,
                        "sequence_index": sequence_index,
                        "sort_key": entry["sort_key"],
                        "insertion_index": entry["insertion_index"],
                        "entry_type": "optional_group",
                        "event": event_name,
                        "name_or_group": group_id,
                        "source_scope": "optional",
                        "source_file": None,
                        "probability": rules.get(
                            "probability_of_being_active"
                        ),
                        "min_files": minimum,
                        "max_files": maximum,
                        "observed_selected_count": selected_count,
                        "informative": False,
                    }
                )

        leftovers = [
            {
                "identity": list(identity),
                "remaining_count": len(rows),
            }
            for identity, rows in accepted_direct.items()
            if rows
        ]
        if leftovers:
            source_mapping_leftovers.append(
                {"planet_key": planet_key, "leftovers": leftovers}
            )

        if predicted_tags == observed_tags:
            order_exact += 1
        else:
            first_diff = None
            for index in range(max(len(predicted_tags), len(observed_tags))):
                predicted = (
                    predicted_tags[index]
                    if index < len(predicted_tags)
                    else None
                )
                observed = (
                    observed_tags[index]
                    if index < len(observed_tags)
                    else None
                )
                if predicted != observed:
                    first_diff = {
                        "index": index,
                        "predicted": predicted,
                        "observed": observed,
                    }
                    break
            order_mismatch.append(
                {
                    "planet_key": planet_key,
                    "first_difference": first_diff,
                    "predicted_tag_count": len(predicted_tags),
                    "observed_tag_count": len(observed_tags),
                }
            )

        plans.append(
            {
                "planet_key": planet_key,
                "system_key": observation.get("system_key"),
                "portal": observation.get("portal"),
                "slot": int(observation.get("slot", 0)),
                "seed": parse_seed(observation.get("seed_hex")),
                "seed_hex": observation.get("seed_hex"),
                "selected_biome_source": source_mbin,
                "events": events,
                "attempted_entry_count": len(entries),
                "accepted_direct_count": accepted_direct_count,
                "accepted_optional_row_count": accepted_optional_count,
                "informative_count": informative_count,
                "stable_tie_order_matches_runtime": (
                    predicted_tags == observed_tags
                ),
            }
        )

    audit = {
        "planet_count": len(plans),
        "stable_tie_order_exact_planet_count": order_exact,
        "stable_tie_order_mismatch_planet_count": len(order_mismatch),
        "stable_tie_order_mismatches": order_mismatch,
        "source_mapping_leftover_planet_count": len(
            source_mapping_leftovers
        ),
        "source_mapping_leftovers": source_mapping_leftovers,
        "optional_count_anomaly_count": len(optional_count_anomalies),
        "optional_count_anomalies": optional_count_anomalies,
        "schedule_rows": schedule_rows,
    }
    return plans, audit


def derive_selector_local(shared: MWCState) -> MWCState:
    first = shared.draw()
    second = shared.draw()
    combined = ((second & MASK32) << 32) | (first & MASK32)
    mixed = avalanche_mix_64(combined)
    low = mixed & MASK32
    low = low if low != 0 else 1
    high = (mixed >> 32) & MASK32
    carry = (rotate_right_32(low, 16) ^ high ^ low) & MASK32
    return MWCState(low, carry)


def replay_plan(
    selector: MWCState,
    events: list[tuple[Any, ...]],
) -> tuple[int, int, int, int, int, int]:
    index_matches = 0
    index_total = 0
    range_matches = 0
    range_total = 0
    probability_passes = 0
    probability_total = 0

    for event in events:
        opcode = event[0]
        if opcode == DIRECT_REJECTED:
            selector.draw()
        elif opcode == DIRECT_ACCEPTED_UNINFORMATIVE:
            probability = float(event[1])
            probability_word = selector.draw()
            probability_total += 1
            if probability_word / 4294967296.0 <= probability:
                probability_passes += 1
            selector.draw()
        elif opcode == DIRECT_ACCEPTED_INFORMATIVE:
            probability = float(event[1])
            option_count = int(event[2])
            expected_index = int(event[3])
            probability_word = selector.draw()
            probability_total += 1
            if probability_word / 4294967296.0 <= probability:
                probability_passes += 1
            index_word = selector.draw()
            predicted_index = select_mulhi(index_word, option_count)
            index_total += 1
            if predicted_index == expected_index:
                index_matches += 1
        elif opcode == OPTIONAL_INACTIVE:
            selector.draw()
        elif opcode == OPTIONAL_ACTIVE:
            minimum = int(event[1])
            maximum = int(event[2])
            expected_count = int(event[3])
            selector.draw()
            range_word = selector.draw()
            if minimum <= expected_count <= maximum:
                range_total += 1
                predicted_count = minimum + select_mulhi(
                    range_word, maximum - minimum + 1
                )
                if predicted_count == expected_count:
                    range_matches += 1
        else:
            raise RuntimeError(f"Unknown replay opcode: {opcode}")

    return (
        index_matches,
        index_total,
        range_matches,
        range_total,
        probability_passes,
        probability_total,
    )


def worker_search(
    payload: tuple[
        str,
        list[tuple[int, list[tuple[Any, ...]]]],
        int,
        int,
    ]
) -> dict[str, Any]:
    factory_name, compact_plans, max_offset, top_n = payload
    factory = STATE_FACTORIES[factory_name]
    base_states = [factory(seed) for seed, _events in compact_plans]
    top: list[dict[str, Any]] = []

    for offset in range(max_offset + 1):
        totals = [0, 0, 0, 0, 0, 0]
        for base_state, (_seed, events) in zip(base_states, compact_plans):
            selector = derive_selector_local(base_state.copy())
            result = replay_plan(selector, events)
            for index, value in enumerate(result):
                totals[index] += value

        candidate = {
            "state_factory": factory_name,
            "shared_pre_selector_offset": offset,
            "informative_index_matches": totals[0],
            "informative_index_total": totals[1],
            "active_range_matches": totals[2],
            "active_range_total": totals[3],
            "accepted_probability_passes": totals[4],
            "accepted_probability_total": totals[5],
        }
        rank = (
            candidate["informative_index_matches"],
            candidate["active_range_matches"],
            candidate["accepted_probability_passes"],
            -offset,
        )
        candidate["_rank"] = rank
        top.append(candidate)
        top.sort(key=lambda item: item["_rank"], reverse=True)
        if len(top) > top_n:
            top.pop()

        # Advance the base shared state by exactly one draw so the next
        # iteration represents offset+1 without O(offset^2) work.
        for base_state in base_states:
            base_state.draw()

    for candidate in top:
        candidate.pop("_rank", None)
    return {"state_factory": factory_name, "top_candidates": top}


def run_search(
    plans: list[dict[str, Any]],
    max_offset: int,
    workers: int,
    top_n: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    compact = [
        (int(plan["seed"]), list(plan["events"])) for plan in plans
    ]
    payloads = [
        (name, compact, max_offset, top_n)
        for name in STATE_FACTORIES
    ]

    if workers <= 1:
        results = [worker_search(payload) for payload in payloads]
    else:
        context = mp.get_context("spawn")
        with context.Pool(
            processes=min(workers, len(payloads))
        ) as pool:
            results = pool.map(worker_search, payloads)

    candidates = [
        candidate
        for result in results
        for candidate in result["top_candidates"]
    ]
    candidates.sort(
        key=lambda item: (
            item["informative_index_matches"],
            item["active_range_matches"],
            item["accepted_probability_passes"],
            -item["shared_pre_selector_offset"],
        ),
        reverse=True,
    )
    return candidates[:top_n], results


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def make_report(result: dict[str, Any]) -> str:
    totals = result["corpus_totals"]
    audit = result["schedule_audit"]
    analysis = result["analysis"]
    best = analysis["best_candidate"]
    lines = [
        "FIBONACCI NMS VARIABLE SCHEDULE REPLAY V3R",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        "MODE=OFFLINE_READ_ONLY_VARIABLE_SCHEDULE_REPLAY",
        "NMS_PROCESS_REQUIRED=False",
        "PROCESS_MEMORY_WRITES=False",
        "GAME_FILE_WRITES=False",
        "SAVE_WRITES=False",
        "MOD_WRITES=False",
        "ADDRESS_ONLY_PREDICTOR_CLAIMED=False",
        f"V3P_STATUS={result['inputs']['v3p_status']}",
        f"V3Q_STATUS={result['inputs']['v3q_status']}",
        "",
        "CORPUS",
        "------",
        f"SYSTEM_COUNT={totals['system_count']}",
        f"PLANET_COUNT={totals['planet_count']}",
        f"RUNTIME_ROW_COUNT={totals['runtime_row_count']}",
        f"INFORMATIVE_MULTI_OPTION_ROW_COUNT={totals['informative_row_count']}",
        f"ATTEMPTED_ENTRY_COUNT={totals['attempted_entry_count']}",
        f"ACCEPTED_DIRECT_ROW_COUNT={totals['accepted_direct_count']}",
        f"ACCEPTED_OPTIONAL_ROW_COUNT={totals['accepted_optional_row_count']}",
        "",
        "SCHEDULE MATERIALIZATION AUDIT",
        "------------------------------",
        "ORDER_MODEL=ascending Order with stable insertion tie handling",
        f"ORDER_EXACT_PLANETS={audit['stable_tie_order_exact_planet_count']}/{audit['planet_count']}",
        f"ORDER_MISMATCH_PLANETS={audit['stable_tie_order_mismatch_planet_count']}",
        f"SOURCE_MAPPING_LEFTOVER_PLANETS={audit['source_mapping_leftover_planet_count']}",
        f"OPTIONAL_COUNT_ANOMALIES={audit['optional_count_anomaly_count']}",
        "",
        "CONTROLLED MODEL SEARCH",
        "-----------------------",
        f"STATE_FACTORY_COUNT={len(STATE_FACTORIES)}",
        f"OFFSET_RANGE=0..{analysis['max_offset']}",
        f"TOTAL_CANDIDATES_TESTED={analysis['candidate_count']}",
        f"EXACT_CANDIDATE_COUNT={analysis['exact_candidate_count']}",
        f"BEST_STATE_FACTORY={best['state_factory']}",
        f"BEST_SHARED_PRE_SELECTOR_OFFSET={best['shared_pre_selector_offset']}",
        f"BEST_INFORMATIVE_INDEX_SCORE={best['informative_index_matches']}/{best['informative_index_total']}",
        f"BEST_ACTIVE_RANGE_SCORE={best['active_range_matches']}/{best['active_range_total']}",
        f"BEST_ACCEPTED_PROBABILITY_SCORE={best['accepted_probability_passes']}/{best['accepted_probability_total']}",
        "",
        "INTERPRETATION",
        "--------------",
    ]
    if analysis["exact_candidate_count"]:
        lines.extend(
            [
                "At least one controlled planet-seed/shared-offset model reproduced every informative direct selection.",
                "The next phase must independently validate the candidate against unseen systems before using it in an address-only predictor.",
            ]
        )
    else:
        lines.extend(
            [
                "V3P and V3Q correctly explain the selector-local seed transform and variable draw schedule, but no tested planet-seed factory plus fixed shared-stream offset reproduces the corpus.",
                "The best model remains far from exact. Extending the offset range blindly is not justified.",
                "The next target is the provenance and initialization of generator+0xB84/+0xB88 before the selector consumes its two seed draws.",
                "That state may depend on a parent generator seed, prior generation stages, or a constructor path not represented by the six planet-seed factories.",
            ]
        )
    lines.extend(
        [
            "",
            "NEXT PHASE",
            "----------",
            "Map every write/initialization reaching generator+0xB84 and generator+0xB88, then trace the owning generator constructor/caller back to address-derived inputs.",
            "Do not run more portal captures yet; the current ten-system corpus is sufficient for this discrimination stage.",
            "",
            "OUTPUT FILES",
            "------------",
        ]
    )
    for path in result["output_files"]:
        lines.append(path)
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> int:
    if args.self_test:
        # Synthetic test of MWC, selector derivation and mulhi behavior.
        state = state_direct_64(0x123456789ABCDEF0)
        words = [state.draw() for _ in range(4)]
        expected = [0xEBF1CFA4, 0xD8F248B6, 0x32826E5A, 0x590123B4]
        if words != expected:
            raise AssertionError(
                f"MWC self-test mismatch: {words!r} != {expected!r}"
            )
        if select_mulhi(0xFFFFFFFF, 3) != 2:
            raise AssertionError("mulhi self-test failed")
        print("V3R_SELF_TEST=PASS")
        return 0

    if args.v3m_json and args.v3p_json and args.v3q_json:
        v3m_path = Path(args.v3m_json).resolve()
        v3p_path = Path(args.v3p_json).resolve()
        v3q_path = Path(args.v3q_json).resolve()
    elif any([args.v3m_json, args.v3p_json, args.v3q_json]):
        raise ValueError(
            "Provide all of --v3m-json, --v3p-json and --v3q-json, or none."
        )
    else:
        v3m_path, v3p_path, v3q_path = find_default_inputs()

    for path in [v3m_path, v3p_path, v3q_path]:
        if not path.is_file():
            raise FileNotFoundError(path)

    v3m = load_json(v3m_path)
    v3p = load_json(v3p_path)
    v3q = load_json(v3q_path)

    if not str(v3p.get("status", "")).startswith("PASS"):
        raise RuntimeError(f"V3P is not a PASS result: {v3p.get('status')}")
    if not str(v3q.get("status", "")).startswith("PASS"):
        raise RuntimeError(f"V3Q is not a PASS result: {v3q.get('status')}")
    if not v3q.get("all_function_bounds_match"):
        raise RuntimeError("V3Q function-bound verification is not complete.")

    source_core_path = Path(__file__).resolve().parent / "_v3j2_source_core.py"
    source_core = load_module("v3r_source_core", source_core_path)
    catalogue, parsed_biomes, source_paths = parse_source_material(
        v3m_path, source_core
    )
    plans, audit = build_plans(v3m, catalogue, parsed_biomes)

    informative_total = sum(plan["informative_count"] for plan in plans)
    if informative_total != int(
        v3m.get("source_resolution_summary", {}).get(
            "informative_multi_option_row_count", informative_total
        )
    ):
        raise RuntimeError(
            "Materialized informative-row total does not match V3M."
        )

    workers = max(1, int(args.workers))
    top_candidates, per_factory = run_search(
        plans,
        max_offset=int(args.max_offset),
        workers=workers,
        top_n=int(args.top_n),
    )
    if not top_candidates:
        raise RuntimeError("Search returned no candidates.")

    best = top_candidates[0]
    exact_candidates = [
        candidate
        for candidate in top_candidates
        if candidate["informative_index_matches"]
        == candidate["informative_index_total"]
        and candidate["active_range_matches"]
        == candidate["active_range_total"]
        and candidate["accepted_probability_passes"]
        == candidate["accepted_probability_total"]
    ]

    out_root = (
        Path(args.output_root).resolve()
        if args.output_root
        else HERE.parent / "data" / "runtime_maps"
    )
    out_dir = out_root / f"{TAG}_{timestamp()}"
    out_dir.mkdir(parents=True, exist_ok=False)

    schedule_csv = out_dir / "attempted_schedule_audit_v3r.csv"
    top_csv = out_dir / "top_seed_offset_candidates_v3r.csv"
    json_path = out_dir / "variable_schedule_replay_v3r.json"
    next_path = out_dir / "next_target_shared_state_provenance_v3r.txt"
    report_path = out_dir / "ATLAS_APF_RESULT_VARIABLE_SCHEDULE_REPLAY_V3R.txt"

    write_csv(schedule_csv, audit.pop("schedule_rows"))
    write_csv(top_csv, top_candidates)

    corpus_totals = {
        "system_count": len({plan["system_key"] for plan in plans}),
        "planet_count": len(plans),
        "runtime_row_count": int(
            v3m.get("corpus_totals", {}).get("runtime_row_count", 0)
        ),
        "informative_row_count": informative_total,
        "attempted_entry_count": sum(
            plan["attempted_entry_count"] for plan in plans
        ),
        "accepted_direct_count": sum(
            plan["accepted_direct_count"] for plan in plans
        ),
        "accepted_optional_row_count": sum(
            plan["accepted_optional_row_count"] for plan in plans
        ),
    }

    status = (
        "PASS_EXACT_VARIABLE_SCHEDULE_CANDIDATE_FOUND"
        if exact_candidates
        else "PASS_VARIABLE_SCHEDULE_REPLAY_REJECTS_SEED_OFFSET_MODELS"
    )
    output_files = [
        str(report_path),
        str(json_path),
        str(schedule_csv),
        str(top_csv),
        str(next_path),
    ]
    result = {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": status,
        "safety": {
            "offline_only": True,
            "nms_process_access": False,
            "process_memory_writes": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
            "source_report_writes": False,
        },
        "claim_boundary": {
            "address_only_predictor_claimed": False,
            "complete_shared_rng_provenance_claimed": False,
            "selector_local_schedule_replayed": True,
            "tested_model_family": (
                "six V3M planet-seed factories plus fixed shared-stream offsets"
            ),
        },
        "inputs": {
            "v3m_json": str(v3m_path),
            "v3p_json": str(v3p_path),
            "v3q_json": str(v3q_path),
            "v3m_status": v3m.get("status"),
            "v3p_status": v3p.get("status"),
            "v3q_status": v3q.get("status"),
            "parsed_biome_file_count": len(parsed_biomes),
            "source_core": str(source_core_path),
        },
        "corpus_totals": corpus_totals,
        "schedule_audit": audit,
        "planet_plans": [
            {key: value for key, value in plan.items() if key != "events"}
            for plan in plans
        ],
        "analysis": {
            "max_offset": int(args.max_offset),
            "candidate_count": len(STATE_FACTORIES)
            * (int(args.max_offset) + 1),
            "workers": workers,
            "best_candidate": best,
            "exact_candidate_count": len(exact_candidates),
            "exact_candidates": exact_candidates,
            "top_candidates": top_candidates,
            "per_factory_top_candidates": per_factory,
        },
        "next_target": {
            "shared_state_fields": ["generator+0xB84", "generator+0xB88"],
            "required_work": (
                "map all writes/initializers and trace the owning generator "
                "constructor back to address-derived inputs"
            ),
            "more_portal_captures_required_now": False,
        },
        "output_files": output_files,
    }

    next_path.write_text(
        "FIBONACCI NMS V3R NEXT TARGET\n\n"
        "The variable selector schedule is now materialized and replayed.\n"
        "No controlled planet-seed factory plus fixed offset is exact.\n\n"
        "NEXT STATIC TARGET\n"
        "------------------\n"
        "1. Find every write to generator+0xB84 and generator+0xB88.\n"
        "2. Identify the constructor/reset function that creates this MWC state.\n"
        "3. Trace its seed inputs through the generator owner and its callers.\n"
        "4. Determine which inputs are address-derived and which depend on earlier generation stages.\n"
        "5. Only after that, rerun this exact V3R schedule against the recovered shared state.\n\n"
        "Do not expand the fixed-offset range blindly.\n"
        "Do not collect more systems yet.\n",
        encoding="utf-8",
    )
    json_path.write_text(
        json.dumps(result, indent=2, sort_keys=False), encoding="utf-8"
    )
    report_path.write_text(make_report(result), encoding="utf-8")

    print(report_path.read_text(encoding="utf-8"))
    print(f"OUTPUT_DIR={out_dir}")
    return 0


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Replay the V3P/V3Q variable selector schedule against V3M."
    )
    parser.add_argument("--v3m-json")
    parser.add_argument("--v3p-json")
    parser.add_argument("--v3q-json")
    parser.add_argument("--output-root")
    parser.add_argument("--max-offset", type=int, default=DEFAULT_MAX_OFFSET)
    parser.add_argument("--workers", type=int, default=min(6, os.cpu_count() or 1))
    parser.add_argument("--top-n", type=int, default=DEFAULT_TOP_N)
    parser.add_argument("--self-test", action="store_true")
    return parser


if __name__ == "__main__":
    try:
        raise SystemExit(run(make_parser().parse_args()))
    except KeyboardInterrupt:
        print("V3R_STATUS=CANCELLED", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print(f"V3R_STATUS=FAILED: {exc}", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(1)
