#!/usr/bin/env python3
"""Standalone per-region legacy-system occupancy resolver for APF V20G1.

This file deliberately preserves the V20E3 public API used by the existing
V20F3 Core.  Its implementation is now entirely app-owned and does not read
NMS.exe, a loaded-module dump, process memory, a replay cache, or Unicorn.
"""
from __future__ import annotations

import json
import functools
from datetime import datetime
from pathlib import Path
from typing import Any

import fibonacci_nms_standalone_legacy_system_count_v20g1 as standalone

VERSION = "20G1.0.0"
COMPATIBILITY_API = "20E3"


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _controls_lookup(
    controls: dict[str, Any], galaxy_index: int, suffix: str
) -> dict[str, Any] | None:
    for row in controls.get("regions", []):
        if (
            int(row.get("galaxy_index", -1)) == int(galaxy_index)
            and str(row.get("region_suffix", "")).upper() == suffix.upper()
        ):
            return dict(row)
    return None



@functools.lru_cache(maxsize=8192)
def _cached_diagnostics(region_suffix: str, galaxy_index: int) -> dict[str, Any]:
    result = standalone.generated_legacy_system_count(
        region_suffix, galaxy_index, include_diagnostics=True
    )
    return dict(result)

def verify_static(dump_path: Path, controls_path: Path) -> dict[str, Any]:
    """Verify the app-owned implementation against the bundled live controls.

    ``dump_path`` is retained only for API compatibility.  It is never opened,
    hashed, read, or required.
    """
    del dump_path
    controls = _load_json(controls_path)
    rows = list(controls.get("regions", []))
    observed: dict[str, int] = {}
    expected: dict[str, int] = {}
    diagnostics_exact = True

    for row in rows:
        galaxy = int(row["galaxy_index"])
        suffix = standalone.normalize_region_suffix(row["region_suffix"])
        expected_count = int(row["count"])
        result = _cached_diagnostics(suffix, galaxy)
        observed[f"{galaxy}:{suffix}"] = int(
            result["generated_legacy_system_count"]
        )
        expected[f"{galaxy}:{suffix}"] = expected_count
        diagnostics_exact = diagnostics_exact and (
            int(result["generated_legacy_system_count"]) == expected_count
        )

    purple = controls.get("purple", {})
    checks = {
        "standalone_module_version": standalone.VERSION == "20G1.0.0",
        "validated_control_count": len(rows) == 4,
        "validated_control_ranges": all(
            1 <= int(row.get("count", 0)) <= 0x300 for row in rows
        ),
        "validated_live_boundaries": all(
            bool(row.get("live_last_valid_accepted"))
            and bool(row.get("live_first_invalid_rejected"))
            for row in rows
        ),
        "standalone_controls_exact": diagnostics_exact
        and observed == expected,
        "purple_interval": (
            int(purple.get("start", -1)) == 0x3E9
            and int(purple.get("count", -1)) == 64
            and int(purple.get("last", -1)) == 0x428
            and int(purple.get("first_invalid", -1)) == 0x429
        ),
        "nms_exe_required": False,
        "module_dump_required": False,
        "process_access_required": False,
        "admin_required": False,
        "native_replay_required": False,
    }
    # Negative dependency fields are requirements, so false is success.
    exact = all(
        value
        for key, value in checks.items()
        if key
        not in {
            "nms_exe_required",
            "module_dump_required",
            "process_access_required",
            "admin_required",
            "native_replay_required",
        }
    ) and not any(
        checks[key]
        for key in {
            "nms_exe_required",
            "module_dump_required",
            "process_access_required",
            "admin_required",
            "native_replay_required",
        }
    )
    return {
        "version": VERSION,
        "compatibility_api": COMPATIBILITY_API,
        "exact": bool(exact),
        "checks": checks,
        "control_regions": len(rows),
        "expected": expected,
        "observed": observed,
        "implementation": "app_owned_standalone_v20g1",
        "dump_path_ignored": True,
    }


def resolve_native_legacy_system_count(
    *,
    portal: str,
    galaxy_index: int,
    dump_path: Path,
    controls_path: Path,
    cache_path: Path,
    allow_replay: bool = True,
    force_replay: bool = False,
) -> dict[str, Any]:
    """Return the exact per-region legacy count using only app-owned code.

    The three path/replay parameters are retained to avoid changing any V20F3
    caller.  They are intentionally ignored and no files are read from them.
    """
    del dump_path, cache_path, allow_replay, force_replay
    suffix = standalone.region_suffix_from_portal(portal)
    galaxy = int(galaxy_index)
    if not 0 <= galaxy <= 255:
        raise ValueError("Galaxy index must be between 0 and 255.")

    controls = _load_json(controls_path)
    control = _controls_lookup(controls, galaxy, suffix)
    cache_before = _cached_diagnostics.cache_info().hits
    diagnostics = dict(_cached_diagnostics(suffix, galaxy))
    cache_hit = _cached_diagnostics.cache_info().hits > cache_before
    count = int(diagnostics["generated_legacy_system_count"])
    if count < 0 or count > 0x300:
        raise RuntimeError(
            f"Standalone legacy-system count is outside 0..768: {count}"
        )

    voxel_key = standalone.pack_voxel_key(suffix, galaxy)
    control_hash = "" if control is None else str(
        control.get("output_first_512_sha256", "")
    )
    result = {
        "resolved": True,
        "source": (
            "app_owned_standalone_live_control_v20g1"
            if control is not None
            else "app_owned_standalone_v20g1"
        ),
        "galaxy_index": galaxy,
        "region_suffix": suffix,
        "voxel_key": voxel_key,
        "voxel_key_hex": f"0x{voxel_key:010X}",
        "generated_legacy_system_count": count,
        "generated_legacy_system_count_hex": f"0x{count:03X}",
        "last_valid_legacy_ssi": count - 1 if count else -1,
        "last_valid_legacy_ssi_hex": (
            f"0x{count - 1:03X}" if count else "NONE"
        ),
        "first_invalid_legacy_ssi": count,
        "first_invalid_legacy_ssi_hex": f"0x{count:03X}",
        "output_first_512_sha256": control_hash,
        "replayed_now": False,
        "live_boundary_validated": control is not None,
        "timestamp": _now(),
        "implementation_version": standalone.VERSION,
        "prefix_path_a_count": diagnostics.get("prefix_path_a_count"),
        "prefix_path_b_count": diagnostics.get("prefix_path_b_count"),
        "density_metric": diagnostics.get("density_metric"),
        "density_threshold": diagnostics.get("threshold"),
        "accepted_grid_count": diagnostics.get("accepted_grid_count"),
        "origin_special_case": bool(
            diagnostics.get("origin_special_case", False)
        ),
        "nms_exe_required": False,
        "module_dump_required": False,
        "process_access": False,
        "admin_required": False,
        "cache_used": cache_hit,
    }
    return result
