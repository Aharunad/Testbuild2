#!/usr/bin/env python3
"""
ATLAS APF — CORE V1

Offline, current-build No Man's Sky planet predictor and regional finder.

Validated scope:
- address -> system planet count and star colour;
- per-planet root seed, biome, subtype, class and size;
- generated water, sea level, exact one-of-19 water style, murkiness and emission mode;
- complete base weather state;
- SentinelLevel / MaxActiveDrones;
- BuildingLevel / HasScrap;
- actual extreme, CLEAR-family, EXTREME-family and literal Paradise branches;
- description/weather family and exact internal token where the bundled
  family catalog has complete suffix coverage;
- exact ResourceLevel, resource abundance family and resource token;
- exact common, uncommon and rare planetary substance IDs;
- exact address-only empty, abandoned, gas-giant and pirate system state;
- exact Life / CreatureLife abundance and four creature descriptors;
- validated fauna and flora abundance token selector schedules;
- exact Infested predicate from BiomeSubType 24;
- exact legacy direct Corrupt branch for purple systems at PlanetIndex 1;
- portal-safe Dissonance from the native reference-difficulty Corrupt enum;
- exact native Sentinel category for difficulty indices 0 through 3;
- exact rendered planetary-ring assignment for standard systems, with current-build
  purple-system no-ring behavior;
- exact default procedural English planet names from planet root seeds;
- exact default procedural English system names from portal addresses;
- exact address-only primary-surface grass and broad emissive asset capability;
- exact live-confirmed bioluminescent Bubble-Grass carpet variant and large
  glowing mushroom-tree variant;
- exact generated Grass and GrassAlt source indices, RGBA values, hexadecimal
  colours, detailed descriptive names and exact GUI swatches;
- exact generated Cloud, Sky, SkyHorizon, SkyFog, SkyHeightFog, SkySunset and
  SkyNight palette sequences plus exact native Day/Dusk/Night sky-table selection.

No NMS process is required. No game, save, MODS, settings, EXE or DLL writes.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
import re
import sys
import time
import struct
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

VERSION = "1.0.61"
TAG = "atlas_apf_v1_0_61"
BUILD_LABEL = "Galaxy-aware generation, simplified exports and corrected weather display names"

HERE = Path(__file__).resolve().parent
if getattr(sys, "frozen", False) or os.environ.get("ATLAS_APF_PORTABLE_RUNTIME") == "1":
    PACKAGE_ROOT = Path(sys.executable).resolve().parent
    _local_app_data = os.environ.get("LOCALAPPDATA")
    USER_DATA_ROOT = (
        Path(_local_app_data) / "ATLAS APF"
        if _local_app_data
        else Path.home() / "AppData" / "Local" / "ATLAS APF"
    )
else:
    # Source execution from a portable layout lives at
    # <package>/_runtime/app. Resolve the actual package root so the
    # integrity manifest can use one stable root-relative path scheme.
    PACKAGE_ROOT = (
        HERE.parent.parent
        if HERE.parent.name.lower() == "_runtime"
        else HERE.parent
    )
    USER_DATA_ROOT = PACKAGE_ROOT
ENGINE_DIR = HERE / "engine"
VENDOR_DIR = ENGINE_DIR / "vendor"
CLEANROOM_DIR = ENGINE_DIR / "cleanroom"
DATA_DIR = HERE / "data"
MODEL_DIR = DATA_DIR / "models"
OUTPUT_ROOT = USER_DATA_ROOT / "outputs"

MODEL_PATH = MODEL_DIR / "branch_models_v5i.json"
FAMILY_CATALOG_PATH = MODEL_DIR / "family_catalog_core_v1.json"
V5J_PLAN_PATH = MODEL_DIR / "final_independent_validation_plan_v5j.json"
NEGATIVE_Y_REGRESSION_PATH = MODEL_DIR / "negative_y_independent_validation_minimal_v5.json"
RESOURCE_LEVEL_REGRESSION_PATH = MODEL_DIR / "resource_level_regression_v1.json"
SUBSTANCE_REGRESSION_PATH = MODEL_DIR / "substance_ids_regression_v1.json"
INTEGRITY_PATH = DATA_DIR / "BUNDLED_DATA_MANIFEST.json"
V4Y_PATH = ENGINE_DIR / "fibonacci_nms_first_controlled_planet_match_predictor_v4y.py"
COMPLETE_WEATHER_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_complete_address_only_weather_replay_v4l.py"
LIFE_CREATURE_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_address_only_life_creature_replay_v15.py"
LIFE_REGRESSION_PATH = MODEL_DIR / "life_fauna_flora_regression_v1.json"
CREATURE_DESCRIPTOR_REGRESSION_PATH = MODEL_DIR / "creature_descriptor_regression_v1.json"
SYSTEM_STATE_REGRESSION_PATH = MODEL_DIR / "system_state_regression_v1.json"
SPECIAL_SYSTEM_REGRESSION_PATH = MODEL_DIR / "special_system_state_regression_v2.json"
SPECIAL_PLANET_REGRESSION_PATH = MODEL_DIR / "special_planet_state_regression_v17g.json"
SPECIAL_PLANET_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_address_only_special_planet_replay_v17h.py"
SENTINEL_DIFFICULTY_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_address_only_sentinel_difficulty_replay_v18b.py"
SENTINEL_DIFFICULTY_REGRESSION_PATH = MODEL_DIR / "planet_selector_corpus_v5i_hidden_state.json"
TERMINOLOGY_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_exact_terminology_presentation_v19b.py"
TERMINOLOGY_CATALOG_PATH = DATA_DIR / "terminology" / "exact_terminology_presentation_v19b.json"
FAUNA_TAXONOMY_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_professional_fauna_taxonomy_v19c1.py"
FAUNA_TAXONOMY_CATALOG_PATH = DATA_DIR / "taxonomy" / "professional_fauna_taxonomy_v19c.json"
FAUNA_DESCRIPTOR_CATALOG_PATH = DATA_DIR / "taxonomy" / "native_creature_descriptor_taxonomy_v19c.json"
FAUNA_TAXONOMY_PROVENANCE_PATH = DATA_DIR / "taxonomy" / "fauna_taxonomy_provenance_v19c.json"
PROFESSIONAL_HARDENING_ENGINE_PATH = ENGINE_DIR / "fibonacci_apf_professional_hardening_v19e.py"
SPECIAL_SYSTEM_ENGINE_PATH = ENGINE_DIR / "fibonacci_nms_address_only_special_system_replay_v16c.py"
CREATURE_TABLE_PATH = DATA_DIR / "creature_generation_data_v11.bin"
GRASS_GLOW_DATA_DIR = DATA_DIR / "grass_glow"
SURFACE_OBJECTLIST_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_surface_objectlist_rule_v20a7.py"
)
SURFACE_OBJECTLIST_RULE_DATA_PATH = (
    GRASS_GLOW_DATA_DIR / "SURFACE_OBJECTLIST_RULE_DATA_V20A7.json"
)
OBJECTLIST_CAPABILITIES_PATH = (
    GRASS_GLOW_DATA_DIR / "OBJECTLIST_CAPABILITIES_V20A7.json"
)
GRASS_COLOUR_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_grass_colour_rule_v20a8a.py"
)
GRASS_COLOUR_RULE_DATA_PATH = (
    GRASS_GLOW_DATA_DIR / "GRASS_COLOUR_RULE_DATA_V20A8A.json"
)
ATMOSPHERE_COLOUR_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_atmosphere_colour_rule_v20d2.py"
)
ATMOSPHERE_REGRESSION_PATH = (
    MODEL_DIR / "atmosphere_palette_regression_v20d2.json"
)
NATIVE_SKY_TABLES_PATH = (
    DATA_DIR / "atmosphere" / "native_sky_colour_tables_v20d3r8.json"
)
NATIVE_SKY_INDEX_REGRESSION_PATH = (
    MODEL_DIR / "native_sky_index_regression_v20d3r8.json"
)
SELECTOR_MAPPING_REGRESSION_PATH = (
    MODEL_DIR / "public_readiness_system_selectors_v3.json"
)
NATIVE_LEGACY_COUNT_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_native_legacy_system_count_v20e3.py"
)
REGION_TRAVERSAL_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_apf_region_traversal_v20f1.py"
)
PARALLEL_SYSTEM_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_apf_parallel_system_search_v20f2.py"
)
COLOUR_DISPLAY_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_apf_colour_display_v20f4.py"
)
NATIVE_LEGACY_COUNT_CONTROLS_PATH = (
    DATA_DIR / "portal_occupancy" / "native_legacy_system_count_controls_v20e3.json"
)
NATIVE_LEGACY_COUNT_CACHE_PATH = (
    OUTPUT_ROOT / "_native_legacy_system_count_cache_v20e3.json"
)
GRASS_GLOW_REGRESSION_PATH = (
    MODEL_DIR / "grass_glow_regression_v20a9.json"
)
COMPREHENSIVE_MAPPING_WEATHER_REGRESSION_PATH = (
    DATA_DIR / "regressions" / "COMPREHENSIVE_MAPPING_WEATHER_REGRESSION_V20H23.json"
)
VISUAL_FLORA_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_visual_flora_rule_v20b2.py"
)
VISUAL_FLORA_RULE_DATA_PATH = (
    GRASS_GLOW_DATA_DIR / "VISUAL_FLORA_RULE_DATA_V20B2.json"
)
WHITE_GLOW_MATERIAL_DATA_PATH = (
    GRASS_GLOW_DATA_DIR / "WHITE_GLOW_BUBBLE_GRASS_MATERIAL_V20H4.json"
)
VISUAL_FLORA_REGRESSION_PATH = (
    MODEL_DIR / "visual_flora_regression_v20b2.json"
)
BIOME_VARIANT_PRESENTATION_PATH = (
    DATA_DIR / "biome_variants" / "BIOME_VARIANT_PRESENTATION_V20H14.json"
)
TERRAIN_SETTING_CATALOG_PATH = (
    DATA_DIR / "terrain" / "VOXEL_GENERATOR_TERRAIN_SETTINGS_V20H19.json"
)
TERRAIN_SELECTOR_RULE_PATH = (
    DATA_DIR / "terrain" / "TERRAIN_SELECTOR_RULE_V20H20.json"
)
COLOUR_FAMILY_SWATCH_GUIDE_PATH = (
    DATA_DIR / "colours" / "COLOUR_FAMILY_SWATCH_GUIDE_V20H21.json"
)
GRASS_EXACT_COLOUR_CATALOG_PATH = (
    GRASS_GLOW_DATA_DIR / "GRASS_EXACT_COLOUR_CATALOG_V20F4.json"
)
CURRENT_STATIC_TABLE_REFERENCE_PATH = (
    DATA_DIR / "reference" / "CURRENT_STATIC_TABLE_REFERENCE_V1048R1.json"
)
TECHNICAL_REFERENCE_PATH = (
    DATA_DIR / "reference" / "NMS_PROCEDURAL_GENERATION_SPEC_V1060.json"
)
TECHNICAL_REFERENCE_MARKDOWN_PATH = (
    DATA_DIR / "reference" / "NMS_PROCEDURAL_GENERATION_SPEC_V1060.md"
)
TECHNICAL_REFERENCE_EXPORT_FILES = (
    TECHNICAL_REFERENCE_PATH,
    TECHNICAL_REFERENCE_MARKDOWN_PATH,
    DATA_DIR / "reference" / "NMS_ENTITY_RELATIONSHIP_MODEL_V1060.csv",
    DATA_DIR / "reference" / "NMS_GENERATION_STAGE_CATALOG_V1060.csv",
    DATA_DIR / "reference" / "NMS_GENERATION_RULE_CATALOG_V1060.csv",
    DATA_DIR / "reference" / "NMS_GENERATED_FIELD_DICTIONARY_V1060.csv",
    DATA_DIR / "reference" / "NMS_DEPENDENCY_GRAPH_V1060.csv",
    DATA_DIR / "reference" / "NMS_ENUMERATION_CATALOG_V1060.csv",
    DATA_DIR / "reference" / "NMS_ALGORITHM_CATALOG_V1060.csv",
    DATA_DIR / "reference" / "NMS_WORKED_GENERATION_TRACES_V1060.json",
)
PARENT_STRUCTURE_ENGINE_PATH = (
    CLEANROOM_DIR / "fibonacci_nms_direct_rng_budget_v2r.py"
)
RING_SELECTOR_ENGINE_PATH = (
    ENGINE_DIR / "fibonacci_nms_exact_rendered_rings_v20j.py"
)
RING_SELECTOR_LIVE_CORPUS_PATH = (
    DATA_DIR / "RING_SELECTOR_LIVE_CORPUS_V1058.json"
)
BIOME_TABLE_INTELLIGENCE_PATH = (
    DATA_DIR / "biome_tables" / "BIOME_TABLE_INTELLIGENCE_V1047R3.json"
)

NAMEGEN_ENGINE_DIR = ENGINE_DIR / "namegen_v1"
PLANET_NAME_ENGINE_PATH = NAMEGEN_ENGINE_DIR / "address_only_planet_name_v1.py"
SYSTEM_NAME_ENGINE_PATH = NAMEGEN_ENGINE_DIR / "address_only_system_name_v1.py"
NAMEGEN_DATA_PATH = NAMEGEN_ENGINE_DIR / "namegen_markov_datasets_8_exact.json"
PLANET_NAME_REGRESSION_PATH = DATA_DIR / "names" / "planet_name_regression_25.json"
SYSTEM_NAME_REGRESSION_PATH = DATA_DIR / "names" / "system_name_regression_1000000.json"
MARKOV_NAME_REGRESSION_PATH = DATA_DIR / "names" / "markov_regression_1000000.json"
CLEANUP_NAME_REGRESSION_PATH = DATA_DIR / "names" / "cleanup_regression_33844.json"

WATER_PROFILE_ENGINE_DIR = ENGINE_DIR / "water_profile_v2"
WATER_PROFILE_ENGINE_PATH = WATER_PROFILE_ENGINE_DIR / "address_only_water_profile_v2.py"
WATER_PROFILE_MATRIX_PATH = WATER_PROFILE_ENGINE_DIR / "water_emission_matrix_current_build.json"
WATER_STYLE_RECORDS_PATH = WATER_PROFILE_ENGINE_DIR / "water_style_records_current_build.json"
WATER_PROFILE_REGRESSION_PATH = DATA_DIR / "water_profile" / "water_profile_regression_25.json"
GALAXY_NAMES_PATH = DATA_DIR / "galaxies" / "GALAXY_NAMES_ENGLISH_V1060.json"


MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF

# Exact completion for biome/subtype keys introduced by the current biome
# source tables but absent from the original 45-planet V5I training corpus.
# The family still uses the existing child-22 selector and exact current-game
# British-English localisation pipeline; this is not a guessed display label.
DESCRIPTION_FAMILY_COMPLETION_V20B3 = {
    (0, 20): "LUSH",
    (0, 21): "LUSH",
    (1, 23): "TOXIC",
    (1, 24): "TOXIC",
}

# Current-build family identities exposed by the native writer table. These
# are used only when the older V5I corpus has no exact key.
DESCRIPTION_DEFAULT_FAMILY_BY_BIOME_V20B4 = {
    0: "LUSH",
    1: "TOXIC",
    2: "SCORCHED",
    3: "IRRADIATED",
    4: "FROZEN",
    5: "BARREN",
    6: "DEAD",
    7: "GLITCHBIOME",
    8: "REDBIOME",
    9: "GREENBIOME",
    10: "BLUEBIOME",
    12: "SWAMPBIOME",
    13: "LAVABIOME",
    14: "WATERWORLD",
    15: "GASGIANT",
}

INFESTED_DESCRIPTION_FAMILY_BY_BIOME_V20B4 = {
    0: "INFESTEDLUSH",
    1: "INFESTEDTOX",
    2: "INFESTEDHOT",
    3: "INFESTEDRAD",
    4: "INFESTEDCOLD",
    5: "INFESTEDDUST",
}

WEATHER_NORMAL_FAMILY_BY_BIOME_V20B4 = {
    0: "WEATHER_LUSH",
    1: "WEATHER_TOXIC",
    2: "WEATHER_HEAT",
    3: "WEATHER_RADIO",
    4: "WEATHER_COLD",
    5: "WEATHER_BARREN",
    6: "WEATHER_DEAD",
    7: "WEATHER_GLITCH",
    8: "WEATHER_RED",
    9: "WEATHER_GREEN",
    10: "WEATHER_BLUE",
    12: "WEATHER_SWAMP",
    13: "WEATHER_LAVA",
    14: "WEATHER_WATERWORLD",
    15: "WEATHER_GASGIANT",
}

WEATHER_CLEAR_FAMILY_BY_BIOME_V20B4 = {
    0: "WEATHER_LUSH_CLEAR",
    1: "WEATHER_TOXIC_CLEAR",
    2: "WEATHER_HEAT_CLEAR",
    3: "WEATHER_RADIO_CLEAR",
    4: "WEATHER_COLD_CLEAR",
    5: "WEATHER_BARREN_CLEAR",
    12: "WEATHER_SWAMP_CLEAR",
    13: "WEATHER_LAVA_CLEAR",
}

WEATHER_EXTREME_FAMILY_BY_BIOME_V20B4 = {
    0: "WEATHER_LUSHEXTREME",
    1: "WEATHER_TOXICEXTREME",
    2: "WEATHER_HEATEXTREME",
    3: "WEATHER_RADIOEXTREME",
    4: "WEATHER_COLDEXTREME",
    5: "WEATHER_BARRENEXTREME",
    12: "WEATHER_SWAMP_EXTREME",
    13: "WEATHER_LAVA_EXTREME",
}
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997

NORMAL_WEATHER_BIOMES = {0, 1, 2, 3, 4, 5, 12, 13}
RESOURCE_LEVEL_THRESHOLD = 0.75
RESOURCE_LEVEL_SPECIAL_BIOMES = {6, 14, 15}

ECONOMY_TYPE_DISPLAY = {
    0: "Mining",
    1: "High Tech",
    2: "Mercantile",
    3: "Manufacturing",
    4: "Fusion",
    5: "Scientific",
    6: "Power Generation",
}
CONFLICT_LEVEL_DISPLAY = {0: "Low", 1: "Medium", 2: "High", 3: "Pirate Controlled"}
ECONOMY_TIER_DISPLAY = {0: "Low", 1: "Medium", 2: "High", 3: "Pirate"}
ECONOMY_TIER_ENUM_NAME = {0: "Poor", 1: "Average", 2: "Wealthy", 3: "Pirate"}
# GcAlienRace native enum order for the three ordinary dominant races:
# Traders, Warriors, Explorers. Public in-game names are Gek, Vy'keen, Korvax.
DOMINANT_RACE_DISPLAY = {0: "Gek", 1: "Vy'keen", 2: "Korvax"}
DOMINANT_RACE_ENUM_NAME = {0: "Traders", 1: "Warriors", 2: "Explorers"}

# Current-build portal occupancy. Legacy systems are a region-specific
# contiguous prefix: SSI < GeneratedLegacySystemCount, with a maximum capacity
# of 0x300 candidate slots. Worlds Part II purple systems occupy the separate
# live-validated interval 0x3E9-0x428 inclusive (64 systems). The exact legacy
# count is resolved by the app-owned standalone V20G1 occupancy engine.
LEGACY_SYSTEM_INDEX_MIN = 0x000
LEGACY_SYSTEM_INDEX_MAX = 0x2FF
LEGACY_SYSTEM_COUNT = 0x300
LEGACY_SYSTEM_CAPACITY_MAX = LEGACY_SYSTEM_COUNT
PURPLE_SYSTEM_INDEX_MIN = 0x3E9
PURPLE_SYSTEM_INDEX_MAX = 0x428
PURPLE_SYSTEM_COUNT = PURPLE_SYSTEM_INDEX_MAX - PURPLE_SYSTEM_INDEX_MIN + 1
RAW_SYSTEM_INDEX_MAX = 0xFFF
PORTAL_ADDRESSABLE_SYSTEM_INDEX_MIN = LEGACY_SYSTEM_INDEX_MIN
PORTAL_ADDRESSABLE_SYSTEM_INDEX_MAX = PURPLE_SYSTEM_INDEX_MAX

FINDER_SEARCH_DOMAIN_PORTAL = "portal"
FINDER_SEARCH_DOMAIN_PURPLE = "purple"
FINDER_SEARCH_DOMAIN_LABELS = {
    FINDER_SEARCH_DOMAIN_PORTAL: "Standard portal systems (exact count per region)",
    FINDER_SEARCH_DOMAIN_PURPLE: "Purple portal systems (64 per region)",
}

FINDER_REGION_MODE_SINGLE = "single"
FINDER_REGION_MODE_WINDOW = "window"
FINDER_REGION_MODE_FULL = "full"
FINDER_REGION_MODE_LABELS = {
    FINDER_REGION_MODE_SINGLE: "Anchor region only",
    FINDER_REGION_MODE_WINDOW: "Multiple regions — same system range",
    FINDER_REGION_MODE_FULL: "Multiple regions — every system",
}
RESOURCE_FAMILY_BY_LEVEL = {0: 'RARITY_MID', 1: 'RARITY_LOW'}
RESOURCE_ABUNDANCE_BY_LEVEL = {0: 'Average (MID)', 1: 'Low'}
RESOURCE_WRITER_RANGE = (0x16F3F07, 0x16F3F56)
RESOURCE_WRITER_SHA256 = (
    '1502BDAAA9FFA6D6A752ED71FBDE565028D2D2EBB733C2CA31735A318056B94D'
)
RESOURCE_STAGE_RANGE = (0x16F3A50, 0x16F406B)
RESOURCE_STAGE_SHA256 = (
    'F9696EAEA35FF4F6FFC15C62F5FE13F6B8D73CD8F131A7F8C7ECAF068F0AADB0'
)
RESOURCE_STORE_RVA = 0x16F3F50
RESOURCE_STORE_HEX = '898760340000'
RESOURCE_THRESHOLD_RVA = 0x31B9F20
RESOURCE_THRESHOLD_HEX = '0000403F'

COMMON_SUBSTANCE_BASE_BY_STAR = {0: "YELLOW2", 1: "GREEN2", 2: "BLUE2", 3: "RED2", 4: "PURPLE2"}
COMMON_SUBSTANCE_ACTIVATED_BY_STAR = {0: "EX_YELLOW", 1: "EX_GREEN", 2: "EX_BLUE", 3: "EX_RED", 4: "EX_PURPLE"}
UNCOMMON_SUBSTANCE_BY_BIOME = {0: "LUSH1", 1: "TOXIC1", 2: "HOT1", 3: "RADIO1", 4: "COLD1", 5: "DUSTY1", 6: "SPACEGUNK3", 7: "ASTEROID2", 8: "HOT1", 9: "TOXIC1", 10: "COLD1", 12: "GAS1", 13: "LAVA1", 14: "WATERWORLD1", 15: "GASGIANT1"}
RARE_SUBSTANCE_TABLE = ["CATALYST1", "LAND3", "CAVE1", "WATER1", "ASTEROID1"]

# Current English resource names for the exact internal substance IDs emitted by
# the recovered writer. Public UI uses these names while exports retain IDs.
SUBSTANCE_LOCALIZED_NAME_BY_ID = {
    "YELLOW2": "Copper",
    "EX_YELLOW": "Activated Copper",
    "GREEN2": "Emeril",
    "EX_GREEN": "Activated Emeril",
    "BLUE2": "Indium",
    "EX_BLUE": "Activated Indium",
    "RED2": "Cadmium",
    "EX_RED": "Activated Cadmium",
    "PURPLE2": "Quartzite",
    "EX_PURPLE": "Activated Quartzite",
    "LUSH1": "Paraffinium",
    "TOXIC1": "Ammonia",
    "HOT1": "Phosphorus",
    "RADIO1": "Uranium",
    "COLD1": "Dioxite",
    "DUSTY1": "Pyrite",
    "SPACEGUNK3": "Rusted Metal",
    "ASTEROID2": "Gold",
    "GAS1": "Sulphurine",
    "LAVA1": "Basalt",
    "WATERWORLD1": "Lithium",
    "GASGIANT1": "Crystallised Helium",
    "CATALYST1": "Sodium",
    "LAND3": "Magnetised Ferrite",
    "CAVE1": "Cobalt",
    "WATER1": "Salt",
    "ASTEROID1": "Silver",
}


def substance_localized_name(value: str | None) -> str:
    substance_id = str(value or "").strip().upper()
    return SUBSTANCE_LOCALIZED_NAME_BY_ID.get(substance_id, substance_id)


def substance_filter_display(value: str | None) -> str:
    substance_id = str(value or "").strip().upper()
    if not substance_id:
        return ""
    name = substance_localized_name(substance_id)
    return f"{name} ({substance_id})"


def substance_filter_values(values: list[str] | tuple[str, ...]) -> tuple[str, ...]:
    return ("", *(substance_filter_display(value) for value in values))


def normalize_substance_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    upper = text.upper()
    if upper in SUBSTANCE_LOCALIZED_NAME_BY_ID:
        return upper
    match = re.search(r"\(([A-Z0-9_]+)\)\s*$", text)
    if match and match.group(1).upper() in SUBSTANCE_LOCALIZED_NAME_BY_ID:
        return match.group(1).upper()
    by_name = {name.casefold(): key for key, name in SUBSTANCE_LOCALIZED_NAME_BY_ID.items()}
    result = by_name.get(text.casefold())
    if result is None:
        raise ValueError(f"Unknown resource name or substance ID: {text}")
    return result

def economy_type_filter_values() -> tuple[str, ...]:
    return tuple(ECONOMY_TYPE_DISPLAY[index] for index in sorted(ECONOMY_TYPE_DISPLAY))


ECONOMY_TIER_AT_LEAST_MEDIUM = "★★ or higher"
CONFLICT_LEVEL_AT_MOST_MEDIUM = "★★ or lower"


def economy_tier_filter_values() -> tuple[str, ...]:
    return (
        *(ECONOMY_TIER_DISPLAY[index] for index in sorted(ECONOMY_TIER_DISPLAY)),
        ECONOMY_TIER_AT_LEAST_MEDIUM,
    )


def conflict_level_filter_values() -> tuple[str, ...]:
    return (
        *(CONFLICT_LEVEL_DISPLAY[index] for index in sorted(CONFLICT_LEVEL_DISPLAY)),
        CONFLICT_LEVEL_AT_MOST_MEDIUM,
    )


def dominant_race_filter_values() -> tuple[str, ...]:
    return tuple(DOMINANT_RACE_DISPLAY[index] for index in sorted(DOMINANT_RACE_DISPLAY))


def three_level_star_display(raw_value: int | None, label: str, *, exact: bool) -> str:
    """Render a native three-level value in the same 1/2/3-star form used by the game."""
    if not exact:
        return str(label or "Unavailable")
    try:
        raw = int(raw_value)
    except (TypeError, ValueError):
        return str(label or "Unavailable")
    if raw == 3:
        return f"☠ {label}"
    if raw not in (0, 1, 2):
        return str(label or "Unavailable")
    return f"{'★' * (raw + 1)} {label}"


def normalize_economy_type_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any economy", "any economy type"}:
        return None
    lookup = {item.casefold(): item for item in economy_type_filter_values()}
    normalized = lookup.get(text.casefold())
    if normalized is None:
        raise ValueError(
            "Economy type must be one of: " + ", ".join(economy_type_filter_values())
        )
    return normalized


def normalize_economy_tier_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {
        "any", "any tier", "any economy tier", "any wealth class"
    }:
        return None
    aliases = {
        "low": "Low", "poor": "Low", "1": "Low", "★": "Low",
        "medium": "Medium", "average": "Medium", "2": "Medium", "★★": "Medium",
        "high": "High", "wealthy": "High", "3": "High", "★★★": "High",
        "pirate": "Pirate", "skull": "Pirate", "☠": "Pirate",
        "2 and above": ECONOMY_TIER_AT_LEAST_MEDIUM,
        "2 or above": ECONOMY_TIER_AT_LEAST_MEDIUM,
        "medium or high": ECONOMY_TIER_AT_LEAST_MEDIUM,
        "★★ or higher": ECONOMY_TIER_AT_LEAST_MEDIUM,
    }
    if text.casefold() in {
        ECONOMY_TIER_AT_LEAST_MEDIUM.casefold(),
        "2 and above",
        "2 or above",
        "medium or high",
    }:
        return ECONOMY_TIER_AT_LEAST_MEDIUM
    cleaned = text.replace("★", "").strip().casefold() if "★" in text else text.casefold()
    if "★" in text:
        star_count = text.count("★")
        return {1: "Low", 2: "Medium", 3: "High"}.get(star_count)
    normalized = aliases.get(cleaned)
    if normalized is None:
        raise ValueError(
            "Economy tier must be one of: " + ", ".join(economy_tier_filter_values())
        )
    return normalized


def normalize_conflict_level_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any conflict", "any conflict level"}:
        return None
    aliases = {
        "2 and below": CONFLICT_LEVEL_AT_MOST_MEDIUM,
        "2 or below": CONFLICT_LEVEL_AT_MOST_MEDIUM,
        "low or medium": CONFLICT_LEVEL_AT_MOST_MEDIUM,
        "★★ or lower": CONFLICT_LEVEL_AT_MOST_MEDIUM,
        "pirate": "Pirate Controlled", "pirate controlled": "Pirate Controlled",
        "skull": "Pirate Controlled", "☠": "Pirate Controlled",
    }
    lookup = {item.casefold(): item for item in conflict_level_filter_values()}
    normalized = lookup.get(text.casefold()) or aliases.get(text.casefold())
    if normalized is None:
        raise ValueError(
            "Conflict level must be one of: " + ", ".join(conflict_level_filter_values())
        )
    return normalized


def normalize_dominant_race_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any race", "any dominant race"}:
        return None
    aliases = {
        "gek": "Gek",
        "traders": "Gek",
        "vy'keen": "Vy'keen",
        "vykeen": "Vy'keen",
        "warriors": "Vy'keen",
        "korvax": "Korvax",
        "explorers": "Korvax",
    }
    normalized = aliases.get(text.casefold())
    if normalized is None:
        raise ValueError(
            "Dominant race must be one of: " + ", ".join(dominant_race_filter_values())
        )
    return normalized


def normalize_dominant_race_list_filter(
    value: str | Iterable[str] | None,
) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raw = [part for part in re.split(r"[|,;]", value) if part.strip()]
    else:
        raw = [str(part) for part in value if str(part).strip()]
    output: list[str] = []
    for part in raw:
        normalized = normalize_dominant_race_filter(part)
        if normalized and normalized not in output:
            output.append(normalized)
    return tuple(output)


def system_state_public_metadata(system_state: dict[str, Any]) -> dict[str, Any]:
    """Return a stable public system-state label from exact native flags."""
    empty = bool(system_state.get("in_empty_system"))
    abandoned = bool(system_state.get("in_abandoned_system"))
    pirate = bool(system_state.get("in_pirate_system"))
    gas_giant = bool(system_state.get("in_gas_giant_system"))
    labels: list[str] = []
    if empty:
        labels.append("Uncharted")
    elif abandoned:
        labels.append("Abandoned")
    elif pirate:
        labels.append("Outlaw / Pirate-controlled")
    else:
        labels.append("Ordinary inhabited")
    if gas_giant:
        labels.append("Gas-giant system")
    return {
        "system_state_primary": labels[0],
        "system_state_display": " • ".join(labels),
        "system_state_labels": labels,
        "system_state_exact": True,
    }


def system_selector_metadata(system_state: dict[str, Any]) -> dict[str, Any]:
    scalars = dict(system_state.get("candidate_scalars", {}))
    economy_raw = int(system_state.get("system_kind", scalars.get("decoded_field_230", -1)))
    economy_tier_raw = int(
        scalars.get("decoded_field_234", system_state.get("decoded_field_234", -1))
    )
    decoded_conflict = int(scalars.get("decoded_field_23C", -1))
    conflict_raw = int(system_state.get("source_field8", decoded_conflict))
    source_race_value = system_state.get(
        "source_field0c",
        scalars.get("source_field0c", system_state.get("source_system_kind", -1)),
    )
    dominant_race_raw = int(source_race_value)
    if dominant_race_raw not in DOMINANT_RACE_DISPLAY:
        dominant_race_raw = -1
    empty = bool(system_state.get("in_empty_system"))
    abandoned = bool(system_state.get("in_abandoned_system"))
    pirate = bool(system_state.get("in_pirate_system"))
    ordinary_visible = not (empty or abandoned)
    economy_label = ECONOMY_TYPE_DISPLAY.get(economy_raw, "Unknown")
    economy_tier_label = ECONOMY_TIER_DISPLAY.get(economy_tier_raw, "Unknown")
    economy_tier_enum = ECONOMY_TIER_ENUM_NAME.get(economy_tier_raw, "Unknown")
    conflict_label = CONFLICT_LEVEL_DISPLAY.get(conflict_raw, "Unknown")
    race_label = DOMINANT_RACE_DISPLAY.get(dominant_race_raw, "Unknown")
    race_enum = DOMINANT_RACE_ENUM_NAME.get(dominant_race_raw, "Unknown")
    if ordinary_visible:
        economy_public = economy_label
        economy_tier_public = economy_tier_label
        conflict_public = conflict_label
        race_public = race_label
    else:
        economy_public = "Data unavailable"
        economy_tier_public = "Data unavailable"
        conflict_public = "Data unavailable"
        race_public = "Data unavailable"
    economy_tier_exact = ordinary_visible and economy_tier_raw in ECONOMY_TIER_DISPLAY
    conflict_exact = ordinary_visible and conflict_raw in CONFLICT_LEVEL_DISPLAY
    race_exact = ordinary_visible and dominant_race_raw in DOMINANT_RACE_DISPLAY
    return {
        **system_state_public_metadata(system_state),
        "economy_type_raw": economy_raw,
        "economy_type_internal": economy_label,
        "economy_type_display": economy_public,
        "economy_type_exact": ordinary_visible and economy_raw in ECONOMY_TYPE_DISPLAY,
        "economy_type_selector_status": (
            "exact_native_system_kind_0_to_6_selector_v1052"
            if ordinary_visible else "native_selector_hidden_by_system_occupancy"
        ),
        "economy_tier_raw": economy_tier_raw,
        "economy_tier_internal": economy_tier_label,
        "economy_tier_enum_name": economy_tier_enum,
        "economy_tier_display": economy_tier_public,
        "economy_tier_star_display": three_level_star_display(
            economy_tier_raw, economy_tier_public, exact=economy_tier_exact
        ),
        "economy_tier_exact": economy_tier_exact,
        "economy_tier_filter_available": True,
        "economy_tier_selector_status": (
            "exact_native_system_secondary_probability_wealthclass_selector_v1055"
            if ordinary_visible else "native_selector_hidden_by_system_occupancy"
        ),
        "conflict_level_raw": conflict_raw,
        "conflict_level_internal": conflict_label,
        "conflict_level_display": conflict_public,
        "conflict_level_star_display": three_level_star_display(
            conflict_raw, conflict_public, exact=conflict_exact
        ),
        "conflict_level_exact": conflict_exact,
        "conflict_level_selector_status": (
            "exact_native_source_field8_0_to_2_selector_v1052"
            if ordinary_visible else "native_selector_hidden_by_system_occupancy"
        ),
        "dominant_race_raw": dominant_race_raw,
        "dominant_race_internal": race_label,
        "dominant_race_display": race_public,
        "dominant_race_enum_name": race_enum,
        "dominant_race_exact": race_exact,
        "dominant_race_selector_status": (
            "exact_native_source_field0c_0_to_2_live_validated_v1055"
            if ordinary_visible else "native_selector_hidden_by_system_occupancy"
        ),
        "dominant_race_live_validation_pending": False,
        "system_economy_conflict_race_visible": ordinary_visible,
        "system_economy_conflict_visible": ordinary_visible,
        "system_selector_data_unavailable": not ordinary_visible,
        "pirate_system_selector_semantics_exact": bool(pirate),
    }

BIOME_NAMES = {
    0: "Lush",
    1: "Toxic",
    2: "Scorched",
    3: "Radioactive",
    4: "Frozen",
    5: "Barren",
    6: "Dead",
    7: "Weird / Exotic",
    8: "Red",
    9: "Green",
    10: "Blue",
    11: "Test",
    12: "Swamp / Marsh",
    13: "Lava / Volcanic",
    14: "Waterworld",
    15: "Gas Giant",
    16: "All / wildcard",
}

STAR_COLOURS = {
    0: "Yellow",
    1: "Green",
    2: "Blue",
    3: "Red",
    4: "Purple",
}

GRASS_COLOUR_FILTER_VALUES = (
    "Grey / neutral",
    "Red",
    "Orange",
    "Yellow",
    "Green",
    "Cyan",
    "Blue",
    "Purple",
    "Pink / magenta",
)
DAY_ATMOSPHERE_FILTER_VALUES = (
    "Blue",
    "Pink / Magenta",
    "Cyan",
    "Green",
    "Yellow / Gold",
    "Orange / Gold",
    "Purple / Pink",
    "Purple / Blue",
    "Grey / Neutral",
    "Mixed / Neutral",
)
ATMOSPHERE_PALETTE_FILTER_VALUES = (
    "Blue",
    "Cyan",
    "Green",
    "Yellow / Gold",
    "Orange / Red",
    "Purple / Pink",
    "Grey / Neutral",
    "White / Pale",
    "Dark / Unusual",
)
FUNCTIONAL_STORM_FREQUENCY_VALUES = (
    "No storms",
    "Occasional storms",
    "Frequent storms",
    "Extreme storms",
    "Special / unknowable",
)
PASSIVE_HAZARD_VALUES = (
    "None",
    "Any standard hazard",
    "Nightly cold",
    "Heat",
    "Cold",
    "Toxicity",
    "Radiation",
    "Life-support drain",
    "Barren heat / nightly cold unresolved",
    "Variable / special",
)
STANDARD_PASSIVE_HAZARDS = frozenset({"Heat", "Cold", "Toxicity", "Radiation"})
PORTAL_PLANET_NUMBER_MIN = 1
PORTAL_PLANET_NUMBER_MAX = 6

INFESTED_BIOME_SUBTYPE = 24
DIRECT_DISSONANT_STAR_TYPE = 4
DIRECT_DISSONANT_PLANET_INDEX = 1
DIRECT_DISSONANT_SENTINEL_PATTERN = (0, 3, 3, 3)
DIRECT_DISSONANT_RULE = "StarType == 4 AND PlanetIndex == 1"

# Exact live-scanner corrections established by physical portal travel and
# the in-game Analysis Visor. These are narrow evidence-backed presentation
# overrides, not inferred generator rules.
LIVE_PLANET_CLASSIFICATION_OVERRIDES_V20C6 = {
    "03E9FC7FDDC2": {
        "display": "Tidal Planet",
        "resolution": "live_in_game_analysis_visor_control_v20c6",
        "evidence": "live_portal_and_scanner_validation_2026-07-16",
    },
    "3050239D7F57": {
        "display": "Paradise Moon",
        "literal_paradise": True,
        "resolution": "live_in_game_analysis_visor_control_v20h8",
        "evidence": "live_portal_and_scanner_validation_2026-07-19",
    },
    "3056239D7F58": {
        "display": "Paradise Planet",
        "literal_paradise": True,
        "resolution": "live_in_game_planet_info_control_v20h8",
        "evidence": "exact_planet_info_label_capture_v4z_2026-07-19",
    },
}

RUINED_DESCRIPTION_FAMILY_BY_BIOME_V20H23 = {
    0: "RUINEDLUSH",
    1: "RUINEDTOX",
    2: "RUINEDHOT",
    3: "RUINEDRAD",
    4: "RUINEDCOLD",
    5: "RUINEDDUST",
}

DESCRIPTION_FRIENDLY = {
    "UI_PARADISE_PLANET": "Paradise Planet",
    "LUSH": "Lush",
    "TOXIC": "Toxic",
    "SCORCHED": "Scorched",
    "IRRADIATED": "Radioactive",
    "FROZEN": "Frozen",
    "BARREN": "Barren",
    "DEAD": "Dead",
    "SWAMPBIOME": "Swamp / Marsh",
    "LAVABIOME": "Volcanic",
    "WATERWORLD": "Waterworld",
    "GASGIANT": "Gas Giant",
    "REDBIOME": "Red exotic",
    "GREENBIOME": "Green exotic",
    "BLUEBIOME": "Blue exotic",
    "RUINEDLUSH": "Ruined lush",
    "RUINEDTOX": "Ruined toxic",
    "RUINEDHOT": "Ruined scorched",
    "RUINEDRAD": "Ruined radioactive",
    "RUINEDCOLD": "Ruined frozen",
    "RUINEDDUST": "Ruined barren",
    "RUINED": "Ruined world",
    "BEAMSBIOME": "Beam exotic",
    "BUBBLEBIOME": "Bubble exotic",
    "CONTOURBIOME": "Contour exotic",
    "FRACTCUBEBIOME": "Fractured cube exotic",
    "HYDROGARDENBIOME": "Hydro-garden exotic",
    "MSTRUCTBIOME": "Mega-structure exotic",
    "WIRECELLSBIOME": "Wire-cell exotic",
    "INFESTEDRAD": "Infested radioactive",
    "INFESTEDLUSH": "Infested lush",
    "INFESTEDTOX": "Infested toxic",
    "INFESTEDHOT": "Infested scorched",
    "INFESTEDCOLD": "Infested frozen",
    "INFESTEDDUST": "Infested barren",
    "GLITCHBIOME": "Exotic",
}

WEATHER_FRIENDLY = {
    "WEATHER_LUSH": "Normal lush weather",
    "WEATHER_LUSH_CLEAR": "Clear lush weather",
    "WEATHER_LUSHEXTREME": "Extreme lush storms",
    "WEATHER_TOXIC": "Toxic weather",
    "WEATHER_TOXIC_CLEAR": "Clear toxic weather",
    "WEATHER_TOXICEXTREME": "Extreme toxic storms",
    "WEATHER_HEAT": "Hot weather",
    "WEATHER_HEAT_CLEAR": "Clear hot weather",
    "WEATHER_HEATEXTREME": "Extreme heat storms",
    "WEATHER_RADIO": "Radioactive weather",
    "WEATHER_RADIO_CLEAR": "Clear radioactive weather",
    "WEATHER_RADIOEXTREME": "Extreme radioactive storms",
    "WEATHER_COLD": "Cold weather",
    "WEATHER_COLD_CLEAR": "Clear cold weather",
    "WEATHER_COLDEXTREME": "Extreme cold storms",
    "WEATHER_BARREN": "Barren weather",
    "WEATHER_BARREN_CLEAR": "Clear barren weather",
    "WEATHER_BARRENEXTREME": "Extreme barren storms",
    "WEATHER_DEAD": "Airless / dead weather",
    "WEATHER_GLITCH": "Exotic weather",
    "WEATHER_RED": "Red exotic weather",
    "WEATHER_GREEN": "Green exotic weather",
    "WEATHER_BLUE": "Blue exotic weather",
    "WEATHER_LAVA": "Volcanic weather",
    "WEATHER_LAVA_CLEAR": "Clear volcanic weather",
    "WEATHER_LAVA_EXTREME": "Extreme volcanic storms",
    "WEATHER_SWAMP": "Swamp weather",
    "WEATHER_SWAMP_EXTREME": "Extreme swamp storms",
    "WEATHER_SWAMP_CLEAR": "Clear swamp weather",
    "WEATHER_WATERWORLD": "Waterworld weather",
    "WEATHER_GASGIANT": "Gas-giant weather",
}

# Exact discovery-page wording families hardened from current-game localisation
# and the twelve live controls validated on 20 July 2026. The low-Sentinel
# description selector is child 22, draw 6, multiply-high over 12 entries.
SENTINEL_RARE_DISCOVERY_DISPLAY = {
    1: "Low",
    2: "Minimal",
    3: "Low Security",
    4: "Limited",
    5: "Infrequent",
    6: "Sparse",
    7: "Isolated",
    8: "Remote",
    9: "Irregular Patrols",
    10: "Spread Thin",
    11: "Intermittent",
    12: "Few",
}

SWAMP_WEATHER_DISCOVERY_DISPLAY = {
    "WEATHER_SWAMP_CLEAR": (
        "Gentle Mist", "Humid", "Tropical Winds", "Warm Fog",
        "Temperate Murk", "Mild Damp", "Warm Dewdrops", "Tepid Damp",
        "Sweaty Drizzle", "Muggy Haze",
    ),
    "WEATHER_SWAMP": (
        "Tropical Storms", "Occasional Boiling Fog", "Superheated Mists",
        "Painful Mist", "Infrequent Torrents", "Oppressive", "Soggy Danger",
        "Sticky Heat", "Clammy Menace", "Hazardous Moisture",
    ),
    "WEATHER_SWAMP_EXTREME": (
        "Death Fog", "Sultry Disaster", "Cataclysmic Monsoons",
        "Mists of Annihilation", "All-Consuming Fog", "Liquid Hell",
        "Storms of Desolation", "Melting Deluges", "Boiling Catastrophe",
        "Damp Misery",
    ),
}

# Current scanner presentation uses the shorter discovery-page text while
# retaining the exact underlying localisation token for auditability.
WEATHER_DISCOVERY_DISPLAY_OVERRIDES = {
    "WEATHER_RADIOEXTREME8": "Thermonuclear Fog",
}

NUMERIC_VALIDATION_FIELDS = (
    "slot",
    "planet_portal",
    "planet_seed_hex",
    "biome",
    "biome_subtype",
    "planet_class",
    "planet_size",
    "star_type",
    "terrain_record_index",
    "water_active_frequency",
    "high_water_active_frequency",
    "water_active",
    "high_water",
    "sea_level",
    "weather_index",
    "weather_initial_index",
    "weather_active",
    "weather_mode",
    "weather_flag",
    "weather_intensity",
    "special_weather_state",
    "sentinel_level",
    "max_active_drones",
    "ground_combat_field_3440",
    "ground_combat_field_3444",
    "building_level",
    "has_scrap",
)

_V4Y_MODULE = None
_LIFE_CREATURE_MODULE = None
_SPECIAL_SYSTEM_MODULE = None
_SPECIAL_PLANET_MODULE = None
_SENTINEL_DIFFICULTY_MODULE = None
_TERMINOLOGY_MODULE = None
_FAUNA_TAXONOMY_MODULE = None
_PROFESSIONAL_HARDENING_MODULE = None
_SURFACE_OBJECTLIST_MODULE = None
_GRASS_COLOUR_MODULE = None
_ATMOSPHERE_COLOUR_MODULE = None
_VISUAL_FLORA_MODULE = None
_NATIVE_LEGACY_COUNT_MODULE = None
_REGION_TRAVERSAL_MODULE = None
_PARALLEL_SYSTEM_MODULE = None
_COLOUR_DISPLAY_MODULE = None
_PARENT_STRUCTURE_MODULE = None
_RING_SELECTOR_MODULE = None
_PLANET_NAME_MODULE = None
_SYSTEM_NAME_MODULE = None
_WATER_PROFILE_MODULE = None
_COLOUR_FAMILY_GUIDE_CACHE = None
_GRASS_EXACT_COLOUR_CATALOG_CACHE = None
_SURFACE_OBJECTLIST_RULE = None
_GRASS_COLOUR_RULE = None
_ATMOSPHERE_COLOUR_RULE = None
_VISUAL_FLORA_RULE = None
_MODEL_CACHE = None
_FAMILY_CACHE = None
_BIOME_VARIANT_CACHE = None
_TERRAIN_SELECTOR_RULE_CACHE = None
_BIOME_TABLE_INTELLIGENCE_CACHE = None


@dataclass
class MWCState:
    value: int
    carry: int

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * (self.value & MASK32)
            + (self.carry & MASK32)
        )
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        return self.value


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def load_json(path: Path) -> Any:
    if not path.is_file():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8-sig"))


_GALAXY_CATALOG_CACHE: tuple[dict[str, Any], ...] | None = None


def load_galaxy_catalog() -> tuple[dict[str, Any], ...]:
    global _GALAXY_CATALOG_CACHE
    if _GALAXY_CATALOG_CACHE is None:
        payload = load_json(GALAXY_NAMES_PATH)
        rows = tuple(dict(row) for row in payload.get("galaxies", []))
        if len(rows) != 256:
            raise RuntimeError(f"Expected 256 galaxy records, found {len(rows)}.")
        for expected, row in enumerate(rows, 1):
            if int(row.get("galaxy_number_user", -1)) != expected:
                raise RuntimeError("Galaxy catalog user numbering is not contiguous 1-256.")
            if int(row.get("galaxy_index_internal", -1)) != expected - 1:
                raise RuntimeError("Galaxy catalog internal indexing is not contiguous 0-255.")
            if not str(row.get("galaxy_name", "")).strip():
                raise RuntimeError(f"Galaxy {expected} has no English name.")
        _GALAXY_CATALOG_CACHE = rows
    return _GALAXY_CATALOG_CACHE


def normalize_internal_galaxy_index(value: int | str) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Internal galaxy index must be an integer from 0 to 255.") from exc
    if not 0 <= number <= 255:
        raise ValueError("Internal galaxy index must be between 0 and 255.")
    return number


def normalize_user_galaxy_number(value: int | str) -> int:
    text = str(value).strip()
    match = re.match(r"^(\d{1,3})(?:\s*[—–-]\s*.*)?$", text)
    if not match:
        raise ValueError("Galaxy must be a number from 1 to 256, optionally followed by its name.")
    number = int(match.group(1))
    if not 1 <= number <= 256:
        raise ValueError("Galaxy number must be between 1 and 256.")
    return number


def user_number_to_internal_index(value: int | str) -> int:
    return normalize_user_galaxy_number(value) - 1


def internal_index_to_user_number(value: int | str) -> int:
    return normalize_internal_galaxy_index(value) + 1


def galaxy_metadata(value: int | str) -> dict[str, Any]:
    index = normalize_internal_galaxy_index(value)
    return dict(load_galaxy_catalog()[index])


def galaxy_name_from_internal_index(value: int | str) -> str:
    return str(galaxy_metadata(value)["galaxy_name"])


def galaxy_display_values() -> tuple[str, ...]:
    return tuple(
        f"{row['galaxy_number_user']} — {row['galaxy_name']}"
        for row in load_galaxy_catalog()
    )


def load_white_glow_material_data() -> dict[str, Any]:
    payload = load_json(WHITE_GLOW_MATERIAL_DATA_PATH)
    required = {
        "scene",
        "material",
        "material_colour_hex",
        "material_colour_rgba",
        "match_ground_colour",
        "ground_colour_index",
        "validated_route",
        "positive_controls",
        "negative_controls",
    }
    missing = sorted(required.difference(payload))
    if missing:
        raise ValueError(
            "White-glow material data is incomplete: " + ", ".join(missing)
        )
    return payload


def safe_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest().upper()


def parse_portal(value: str) -> tuple[str, int]:
    text = re.sub(r"[\s:\-_/]+", "", str(value).strip().upper())
    if text.startswith("0X"):
        text = text[2:]
    if len(text) != 12 or not re.fullmatch(r"[0-9A-F]{12}", text):
        raise ValueError(
            "Portal address must contain exactly 12 hexadecimal glyph digits."
        )
    portal_planet_number = int(text[0], 16)
    if portal_planet_number > PORTAL_PLANET_NUMBER_MAX:
        raise ValueError(
            "The first portal glyph must be 0 through 6. Zero is the canonical "
            "system address; exact planetary portal targets use 1 through 6."
        )
    return text, portal_planet_number


def internal_slot_to_gameplay_planet_number(slot: int) -> int:
    value = int(slot)
    if not 0 <= value <= 5:
        raise ValueError("Internal generated planet slot must be between 0 and 5.")
    return value + 1


def gameplay_planet_number_to_internal_slot(number: int) -> int | None:
    value = int(number)
    if value == 0:
        return None
    if not PORTAL_PLANET_NUMBER_MIN <= value <= PORTAL_PLANET_NUMBER_MAX:
        raise ValueError("Gameplay planet number must be 1 through 6.")
    return value - 1


def exact_planet_portal_address(system_address: str, internal_slot: int) -> str:
    canonical = normalize_portal(system_address)
    number = internal_slot_to_gameplay_planet_number(internal_slot)
    return f"{number:X}{canonical[1:]}"


def normalize_portal(value: str) -> str:
    text, _planet_index = parse_portal(value)
    return "0" + text[1:]


def portal_with_system_index(anchor: str, system_index: int) -> str:
    """Construct a raw 12-bit system-seed address for internal replay."""
    canonical = normalize_portal(anchor)
    if not 0 <= int(system_index) <= 0xFFF:
        raise ValueError("Solar-system index must be between 0 and 4095.")
    return f"0{int(system_index):03X}{canonical[4:]}"


def portal_system_index(value: str) -> int:
    """Return the three-hex solar-system field from a portal-form address."""
    text, _planet = parse_portal(value)
    return int(text[1:4], 16)


def portal_region_suffix(value: str) -> str:
    return normalize_portal(value)[4:]


def is_legacy_system_index(
    system_index: int,
    native_legacy_count: int | None = None,
) -> bool:
    value = int(system_index)
    maximum = (
        int(native_legacy_count) - 1
        if native_legacy_count is not None
        else LEGACY_SYSTEM_INDEX_MAX
    )
    return LEGACY_SYSTEM_INDEX_MIN <= value <= maximum


def is_purple_system_index(system_index: int) -> bool:
    value = int(system_index)
    return PURPLE_SYSTEM_INDEX_MIN <= value <= PURPLE_SYSTEM_INDEX_MAX


def is_portal_addressable_system_index(
    system_index: int,
    native_legacy_count: int | None = None,
) -> bool:
    return is_legacy_system_index(
        system_index,
        native_legacy_count,
    ) or is_purple_system_index(system_index)


def is_portal_addressable(
    value: str,
    galaxy: int = 0,
    *,
    resolve_native: bool = False,
) -> bool:
    metadata = system_address_domain_metadata(
        value,
        galaxy=galaxy,
        resolve_native=resolve_native,
    )
    return bool(metadata["validated_in_game_system"])


def validate_portal_addressable(
    value: str,
    *,
    label: str = "Portal address",
    galaxy: int = 0,
) -> str:
    text, _planet = parse_portal(value)
    metadata = system_address_domain_metadata(
        text,
        galaxy=galaxy,
        resolve_native=True,
    )
    if not metadata["validated_in_game_system"]:
        raise ValueError(
            f"{label} has solar-system index "
            f"{metadata['system_index_decimal']} "
            f"({metadata['system_index_hex']}). "
            f"{metadata['in_game_existence_status']}"
        )
    return text


def portal_with_addressable_system_index(
    anchor: str,
    system_index: int,
    native_legacy_count: int | None = None,
) -> str:
    if not is_portal_addressable_system_index(
        system_index,
        native_legacy_count,
    ):
        legacy_text = (
            f"0x000–0x{int(native_legacy_count) - 1:03X}"
            if native_legacy_count is not None
            else "the region-resolved native legacy prefix"
        )
        raise ValueError(
            "Planet Finder system index must be in "
            f"{legacy_text} or the Worlds Part II purple band "
            "0x3E9–0x428."
        )
    return portal_with_system_index(anchor, int(system_index))


def finder_search_domain_values() -> tuple[str, ...]:
    return tuple(FINDER_SEARCH_DOMAIN_LABELS.values())


def finder_region_mode_values() -> tuple[str, ...]:
    return tuple(FINDER_REGION_MODE_LABELS.values())


def normalize_finder_region_mode(value: str | None) -> str:
    if value is None:
        return FINDER_REGION_MODE_SINGLE
    text = str(value).strip()
    if not text:
        return FINDER_REGION_MODE_SINGLE
    aliases = {
        "single": FINDER_REGION_MODE_SINGLE,
        "current": FINDER_REGION_MODE_SINGLE,
        "current region": FINDER_REGION_MODE_SINGLE,
        "window": FINDER_REGION_MODE_WINDOW,
        "same window": FINDER_REGION_MODE_WINDOW,
        "multi": FINDER_REGION_MODE_WINDOW,
        "multi-region": FINDER_REGION_MODE_WINDOW,
        "full": FINDER_REGION_MODE_FULL,
        "full domain": FINDER_REGION_MODE_FULL,
        "all systems": FINDER_REGION_MODE_FULL,
    }
    key = aliases.get(text.casefold())
    if key is not None:
        return key
    for mode, label in FINDER_REGION_MODE_LABELS.items():
        if text.casefold() == label.casefold():
            return mode
    raise ValueError(
        f"Unknown Finder region coverage mode: {value!r}."
    )


def finder_region_mode_note(
    region_mode: str | None,
    search_domain: str | None,
) -> str:
    mode = normalize_finder_region_mode(region_mode)
    domain = normalize_finder_search_domain(search_domain)
    if mode == FINDER_REGION_MODE_SINGLE:
        return (
            "Searches only the region encoded by the anchor address. "
            "First system index and Number of systems are used exactly as entered."
        )
    if mode == FINDER_REGION_MODE_WINDOW:
        if domain == FINDER_SEARCH_DOMAIN_PORTAL:
            return (
                "Repeats the chosen system-index range in each nearby region. "
                "ATLAS APF automatically skips indices that do not exist in a region."
            )
        return (
            "Repeats the chosen purple-system range in each nearby region. "
            "Purple regions always contain the same 64 portal-system indices."
        )
    if domain == FINDER_SEARCH_DOMAIN_PORTAL:
        return (
            "Searches every real standard portal system in each selected region. "
            "ATLAS APF calculates each region's exact system count automatically."
        )
    return (
        "Searches all 64 purple portal systems in each selected region. "
        "Purple-system access must be unlocked on the save used for travel."
    )


def normalize_finder_search_domain(value: str | None) -> str:
    if value is None:
        return FINDER_SEARCH_DOMAIN_PORTAL
    text = str(value).strip()
    if not text:
        return FINDER_SEARCH_DOMAIN_PORTAL
    aliases = {
        "portal": FINDER_SEARCH_DOMAIN_PORTAL,
        "legacy": FINDER_SEARCH_DOMAIN_PORTAL,
        "legacy portal": FINDER_SEARCH_DOMAIN_PORTAL,
        "legacy systems": FINDER_SEARCH_DOMAIN_PORTAL,
        "purple": FINDER_SEARCH_DOMAIN_PURPLE,
        "purple portal": FINDER_SEARCH_DOMAIN_PURPLE,
        "purple systems": FINDER_SEARCH_DOMAIN_PURPLE,
        "worlds ii": FINDER_SEARCH_DOMAIN_PURPLE,
        "worlds 2": FINDER_SEARCH_DOMAIN_PURPLE,
    }
    key = aliases.get(text.casefold())
    if key is not None:
        return key
    for domain, label in FINDER_SEARCH_DOMAIN_LABELS.items():
        if text.casefold() == label.casefold():
            return domain
    raise ValueError(
        f"Unknown Finder search domain: {value!r}. Choose Legacy portal "
        "systems or Purple portal systems."
    )


def finder_system_range_metadata(
    search_domain: str | None = None,
    *,
    anchor_portal: str | None = None,
    galaxy: int = 0,
    resolve_native: bool = False,
) -> dict[str, Any]:
    domain = normalize_finder_search_domain(search_domain)
    if domain == FINDER_SEARCH_DOMAIN_PURPLE:
        return {
            "domain": domain,
            "minimum": PURPLE_SYSTEM_INDEX_MIN,
            "maximum": PURPLE_SYSTEM_INDEX_MAX,
            "capacity": PURPLE_SYSTEM_COUNT,
            "exact": True,
            "source": "validated_fixed_purple_interval",
            "region_suffix": portal_region_suffix(anchor_portal) if anchor_portal else "",
            "occupancy": None,
        }

    occupancy = None
    if anchor_portal:
        occupancy = native_legacy_system_count_metadata(
            anchor_portal,
            galaxy,
            allow_replay=resolve_native,
        )
    if occupancy and occupancy.get("resolved"):
        count = int(occupancy["generated_legacy_system_count"])
        return {
            "domain": domain,
            "minimum": LEGACY_SYSTEM_INDEX_MIN,
            "maximum": count - 1,
            "capacity": count,
            "exact": True,
            "source": occupancy.get("source", "native_legacy_count"),
            "region_suffix": occupancy.get("region_suffix", ""),
            "occupancy": occupancy,
        }
    return {
        "domain": domain,
        "minimum": LEGACY_SYSTEM_INDEX_MIN,
        "maximum": LEGACY_SYSTEM_INDEX_MAX,
        "capacity": LEGACY_SYSTEM_CAPACITY_MAX,
        "exact": False,
        "source": "native_count_not_resolved_yet",
        "region_suffix": portal_region_suffix(anchor_portal) if anchor_portal else "",
        "occupancy": occupancy,
    }


def finder_system_range_bounds(
    search_domain: str | None = None,
    *,
    anchor_portal: str | None = None,
    galaxy: int = 0,
    resolve_native: bool = False,
) -> tuple[int, int, int]:
    metadata = finder_system_range_metadata(
        search_domain,
        anchor_portal=anchor_portal,
        galaxy=galaxy,
        resolve_native=resolve_native,
    )
    return (
        int(metadata["minimum"]),
        int(metadata["maximum"]),
        int(metadata["capacity"]),
    )


def finder_search_domain_note(
    search_domain: str | None = None,
    *,
    anchor_portal: str | None = None,
    galaxy: int = 0,
) -> str:
    metadata = finder_system_range_metadata(
        search_domain,
        anchor_portal=anchor_portal,
        galaxy=galaxy,
        resolve_native=False,
    )
    if metadata["domain"] == FINDER_SEARCH_DOMAIN_PURPLE:
        return (
            "Purple systems use a fixed range of 64 portal-accessible systems per region "
            "(indices 1001–1064, or 0x3E9–0x428). Travelling to them requires purple-system "
            "access on the active save. The unused indices between the standard and purple "
            "ranges are skipped automatically."
        )
    if metadata["exact"]:
        return (
            f"This region contains {metadata['capacity']:,} real standard portal systems, "
            f"numbered 0–{metadata['maximum']} (0x000–0x{metadata['maximum']:03X}). "
            "The total varies by region, and ATLAS APF has already calculated the exact limit."
        )
    return (
        "Standard-system totals vary by region. ATLAS APF calculates the exact number "
        "before searching; a region can contain up to 768 standard portal systems."
    )


def finder_system_address_kind(
    system_index: int,
    native_legacy_count: int | None = None,
) -> str:
    value = int(system_index)
    if is_legacy_system_index(value, native_legacy_count):
        return "legacy_portal_system"
    if native_legacy_count is not None and 0 <= value <= LEGACY_SYSTEM_INDEX_MAX:
        return "legacy_unoccupied_system_index"
    if is_purple_system_index(value):
        return "worlds_ii_purple_portal_system"
    if 0x300 <= value <= 0x3E7:
        return "unmapped_system_index_gap"
    return "unsupported_generator_index"


def finder_travel_access(
    system_index: int,
    native_legacy_count: int | None = None,
) -> str:
    value = int(system_index)
    if is_legacy_system_index(value, native_legacy_count):
        return "System glyph portal accessible"
    if is_purple_system_index(value):
        return "System glyph portal accessible — purple-system access required"
    return "Not included in Planet Finder travel results"


def finder_travel_guidance(
    system_index: int,
    native_legacy_count: int | None = None,
) -> str:
    value = int(system_index)
    if is_legacy_system_index(value, native_legacy_count):
        return (
            "Use the exact one-based planet portal address to arrive on the selected "
            "planet, or use the zero-prefixed canonical address for the system only."
        )
    if native_legacy_count is not None and 0 <= value <= LEGACY_SYSTEM_INDEX_MAX:
        return (
            "This SSI is at or above the region's generated legacy-system "
            "count. A glyph portal displays location corrupt and approximates "
            "the destination."
        )
    if is_purple_system_index(value):
        return (
            "Use the exact one-based planet portal address on a save with purple-system "
            "access unlocked, or use the zero-prefixed canonical system address."
        )
    if 0x300 <= value <= 0x3E7:
        return (
            "This index lies in the unmapped gap between legacy and purple "
            "portal bands and is not searched."
        )
    return (
        "This value is outside the current portal-system bands and is not "
        "searched or copied as a destination."
    )


def system_address_domain_metadata(
    value: str,
    galaxy: int = 0,
    *,
    resolve_native: bool = False,
) -> dict[str, Any]:
    text, _planet = parse_portal(value)
    system_index = portal_system_index(text)
    occupancy = None
    native_count = None
    resolution_status = "not_applicable"

    if 0 <= system_index <= LEGACY_SYSTEM_INDEX_MAX:
        occupancy = native_legacy_system_count_metadata(
            text,
            galaxy,
            allow_replay=resolve_native,
        )
        if occupancy.get("resolved"):
            native_count = int(occupancy["generated_legacy_system_count"])
            resolution_status = "resolved"
            portal_accessible = system_index < native_count
            if portal_accessible:
                status = "Native legacy portal system"
                evidence = (
                    f"SSI 0x{system_index:03X} is below generated count "
                    f"0x{native_count:03X}."
                )
            else:
                status = "Unoccupied legacy candidate — portal approximates"
                evidence = (
                    f"SSI 0x{system_index:03X} is not below generated count "
                    f"0x{native_count:03X}."
                )
        else:
            portal_accessible = False
            resolution_status = "native_replay_required"
            status = "Legacy candidate — native occupancy not resolved yet"
            evidence = (
                "The exact generated count is resolved from the bundled native "
                "galaxy-voxel generator when prediction or search begins."
            )
        kind = finder_system_address_kind(system_index, native_count)
    elif is_purple_system_index(system_index):
        portal_accessible = True
        status = "Worlds Part II purple portal system"
        evidence = (
            "Exact live-validated purple interval 0x3E9–0x428; 0x429 rejects."
        )
        kind = "worlds_ii_purple_portal_system"
    elif 0x300 <= system_index <= 0x3E8:
        portal_accessible = False
        status = "Unmapped system-index gap"
        evidence = "Excluded from Finder"
        kind = "unmapped_system_index_gap"
    else:
        portal_accessible = False
        status = "Outside mapped portal-system bands"
        evidence = "Excluded from Finder"
        kind = "unsupported_generator_index"

    return {
        "system_index_decimal": system_index,
        "system_index_hex": f"0x{system_index:03X}",
        "validated_in_game_system": portal_accessible,
        "glyph_portal_accessible": portal_accessible,
        "address_kind": kind,
        "in_game_existence_status": status,
        "domain_evidence": evidence,
        "native_occupancy_resolution_status": resolution_status,
        "native_legacy_system_count": native_count,
        "native_legacy_system_count_hex": (
            f"0x{native_count:03X}" if native_count is not None else ""
        ),
        "region_suffix": portal_region_suffix(text),
        "occupancy_source": occupancy.get("source", "") if occupancy else "",
        "travel_access": finder_travel_access(system_index, native_count),
        "guidance": finder_travel_guidance(system_index, native_count),
    }


def validate_finder_system_range(
    start_system: int,
    system_count: int,
    search_domain: str | None = FINDER_SEARCH_DOMAIN_PORTAL,
    *,
    anchor_portal: str | None = None,
    galaxy: int = 0,
    resolve_native: bool = False,
    native_legacy_count: int | None = None,
) -> tuple[int, int]:
    domain = normalize_finder_search_domain(search_domain)
    if domain == FINDER_SEARCH_DOMAIN_PORTAL and native_legacy_count is not None:
        minimum, maximum, capacity = (
            0,
            int(native_legacy_count) - 1,
            int(native_legacy_count),
        )
    else:
        minimum, maximum, capacity = finder_system_range_bounds(
            domain,
            anchor_portal=anchor_portal,
            galaxy=galaxy,
            resolve_native=resolve_native,
        )
    start = int(start_system)
    count = int(system_count)
    if not minimum <= start <= maximum:
        raise ValueError(
            f"Start system must be between {minimum} and {maximum} "
            f"(0x{minimum:03X}–0x{maximum:03X}) for the selected domain."
        )
    if not 1 <= count <= capacity:
        raise ValueError(
            f"Systems to scan must be between 1 and {capacity} for the "
            "selected domain."
        )
    if start + count - 1 > maximum:
        remaining = maximum - start + 1
        raise ValueError(
            f"The selected domain has only {remaining} system slot(s) "
            f"remaining from {start} (0x{start:03X}). Finder ranges never wrap."
        )
    return start, count


def rotate_right_32(value: int, count: int) -> int:
    count &= 31
    if count == 0:
        return value & MASK32
    return (
        ((value >> count) | (value << (32 - count)))
        & MASK32
    )


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


def state_direct_64(seed: int) -> MWCState:
    low = seed & MASK32
    high = (seed >> 32) & MASK32
    low = low if low != 0 else 1
    carry = (
        rotate_right_32(low, 16)
        ^ high
        ^ low
    ) & MASK32
    return MWCState(low, carry)


def generate_children(root_seed: int) -> list[int]:
    state = state_direct_64(root_seed)
    children: list[int] = []
    for _ in range(26):
        low = state.draw()
        high = state.draw()
        combined = ((high & MASK32) << 32) | (low & MASK32)
        children.append(avalanche_mix_64(combined))
    return children


def stream_words(
    root_seed: int,
    source_index: int,
    draws: int,
) -> list[int]:
    source_seed = (
        root_seed
        if source_index == 0
        else generate_children(root_seed)[source_index - 1]
    )
    state = state_direct_64(source_seed)
    return [state.draw() for _ in range(draws)]


def select_mulhi(word: int, count: int) -> int:
    if count <= 1:
        return 0
    return ((word & MASK32) * int(count)) >> 32


def to_f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def word_to_native_f32(word: int) -> float:
    return to_f32((word & MASK32) * (1.0 / 4294967296.0))


def predict_resource_level(
    root_seed: int,
    *,
    biome: int,
    planet_class: int,
) -> dict[str, Any]:
    children = generate_children(int(root_seed))
    child_1_seed = int(children[0])
    state = state_direct_64(child_1_seed)

    ordinary_weighted = (
        int(planet_class) != 1
        and int(biome) not in RESOURCE_LEVEL_SPECIAL_BIOMES
    )
    preceding_words: list[int] = []
    if ordinary_weighted:
        preceding_words.append(state.draw())
        preceding_words.append(state.draw())

    resource_word = state.draw()
    random_f32 = word_to_native_f32(resource_word)
    resource_level = int(random_f32 > RESOURCE_LEVEL_THRESHOLD)
    family = RESOURCE_FAMILY_BY_LEVEL[resource_level]

    return {
        "resource_level": resource_level,
        "resources_family": family,
        "resource_abundance": RESOURCE_ABUNDANCE_BY_LEVEL[resource_level],
        "resource_level_child_1_seed_hex": f"0x{child_1_seed:016X}",
        "resource_level_preceding_draw_count": len(preceding_words),
        "resource_level_preceding_words": preceding_words,
        "resource_level_draw_number_one_based": len(preceding_words) + 1,
        "resource_level_word": resource_word,
        "resource_level_random_f32": random_f32,
        "resource_level_threshold_f32": RESOURCE_LEVEL_THRESHOLD,
        "resource_level_comparison": "random_f32 > threshold",
        "resource_level_schedule": (
            "ordinary_two_preceding_draws"
            if ordinary_weighted
            else "special_no_preceding_draws"
        ),
    }



def predict_substances(root_seed: int, *, biome: int, star_type: int, weather_active: int) -> dict[str, Any]:
    biome = int(biome)
    star_type = int(star_type)
    weather_active = int(weather_active)
    if star_type not in COMMON_SUBSTANCE_BASE_BY_STAR:
        raise ValueError(f"Unsupported star type: {star_type}")
    if biome not in UNCOMMON_SUBSTANCE_BY_BIOME:
        raise ValueError(f"Unsupported or unmapped biome for uncommon substance: {biome}")
    if weather_active not in (0, 1):
        raise ValueError(f"WeatherActive must be 0 or 1, got {weather_active}")
    common_is_activated = weather_active == 1
    common_substance_id = COMMON_SUBSTANCE_ACTIVATED_BY_STAR[star_type] if common_is_activated else COMMON_SUBSTANCE_BASE_BY_STAR[star_type]
    uncommon_substance_id = UNCOMMON_SUBSTANCE_BY_BIOME[biome]
    rare_word = stream_words(int(root_seed), 20, 1)[0]
    rare_index = select_mulhi(rare_word, len(RARE_SUBSTANCE_TABLE))
    return {
        "common_is_activated": common_is_activated,
        "common_substance_id": common_substance_id,
        "uncommon_substance_id": uncommon_substance_id,
        "rare_substance_id": RARE_SUBSTANCE_TABLE[rare_index],
        "common_substance_gate": "weather_active == 1",
        "rare_substance_child": 20,
        "rare_substance_draw": 1,
        "rare_substance_word": rare_word,
        "rare_substance_index": rare_index,
        "rare_substance_selector": "mulhi_count_5",
        "substance_prediction_status": "validated_89_planets_16_systems_current_build",
    }


def verify_resource_writer_static() -> dict[str, Any]:
    """Validate the standalone resource rule against its locked regression.

    Native writer hashes remain provenance metadata in the regression JSON;
    the public runtime does not require or read a module image.
    """
    payload = load_json(RESOURCE_LEVEL_REGRESSION_PATH)
    rows = list(payload.get("rows", []))
    native = dict(payload.get("native_writer", {}))
    schedule = dict(payload.get("schedule", {}))
    checks = {
        "regression_file_present": RESOURCE_LEVEL_REGRESSION_PATH.is_file(),
        "regression_rows_71": len(rows) == 71,
        "threshold_f32": math.isclose(
            float(native.get("threshold_f32", -1.0)),
            RESOURCE_LEVEL_THRESHOLD,
            rel_tol=0.0,
            abs_tol=0.0,
        ),
        "comparison_and_outputs": (
            str(native.get("comparison")) == "random_f32 > 0.75"
            and list(native.get("output_values", [])) == [0, 1]
        ),
        "standalone_schedule_locked": (
            str(schedule.get("source")) == "child_1"
            and int(schedule.get("ordinary_planet_preceding_draws", -1)) == 2
            and int(schedule.get("special_planet_preceding_draws", -1)) == 0
            and list(schedule.get("special_biomes", [])) == [6, 14, 15]
        ),
    }
    return {
        "exact": all(checks.values()),
        "checks": checks,
        "observed": {
            "regression_rows": len(rows),
            "threshold_f32": native.get("threshold_f32"),
            "comparison": native.get("comparison"),
            "implementation": "app_owned_standalone_rule",
            "module_dump_required": False,
        },
    }


def ensure_engine_import_paths() -> None:
    # The bundled Unicorn package lives under engine/vendor rather than
    # site-packages. Add both portable paths before any engine import.
    for path in (
        ENGINE_DIR, CLEANROOM_DIR, VENDOR_DIR, NAMEGEN_ENGINE_DIR,
        WATER_PROFILE_ENGINE_DIR,
    ):
        if not path.is_dir():
            continue
        path_text = str(path.resolve())
        if path_text not in sys.path:
            sys.path.insert(0, path_text)



def _load_exact_module(cache_name: str, module_name: str, path: Path):
    module = globals().get(cache_name)
    if module is not None:
        return module
    if not path.is_file():
        raise FileNotFoundError(path)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load exact bundled engine: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    globals()[cache_name] = module
    return module


def load_planet_name_engine():
    return _load_exact_module(
        "_PLANET_NAME_MODULE",
        "atlas_apf_default_planet_name_v1",
        PLANET_NAME_ENGINE_PATH,
    )


def load_system_name_engine():
    return _load_exact_module(
        "_SYSTEM_NAME_MODULE",
        "atlas_apf_default_system_name_v1",
        SYSTEM_NAME_ENGINE_PATH,
    )


def load_water_profile_engine():
    return _load_exact_module(
        "_WATER_PROFILE_MODULE",
        "atlas_apf_address_only_water_profile_v2",
        WATER_PROFILE_ENGINE_PATH,
    )


def load_ring_selector_engine():
    global _RING_SELECTOR_MODULE
    if _RING_SELECTOR_MODULE is not None:
        return _RING_SELECTOR_MODULE
    if not RING_SELECTOR_ENGINE_PATH.is_file():
        raise FileNotFoundError(RING_SELECTOR_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_exact_rendered_rings_v20j",
        RING_SELECTOR_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load ring-selector engine: {RING_SELECTOR_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _RING_SELECTOR_MODULE = module
    return module


def apply_rendered_ring_metadata(
    canonical_system_portal: str,
    rows: list[dict[str, Any]],
    galaxy_index: int = 0,
) -> dict[str, Any]:
    return load_ring_selector_engine().apply_to_rows(
        canonical_system_portal, rows, galaxy_index
    )


def run_rendered_ring_regression_v20j() -> dict[str, Any]:
    return load_ring_selector_engine().run_regression()


def load_parent_structure_engine():
    global _PARENT_STRUCTURE_MODULE
    if _PARENT_STRUCTURE_MODULE is not None:
        return _PARENT_STRUCTURE_MODULE
    if not PARENT_STRUCTURE_ENGINE_PATH.is_file():
        raise FileNotFoundError(PARENT_STRUCTURE_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_parent_structure_v20h20",
        PARENT_STRUCTURE_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load parent-structure engine: {PARENT_STRUCTURE_ENGINE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _PARENT_STRUCTURE_MODULE = module
    return module


def apply_parent_structure_metadata(
    canonical_system_portal: str,
    rows: list[dict[str, Any]],
    galaxy_index: int = 0,
) -> None:
    """Attach exact body-parent metadata from the native candidate arrays.

    The earlier production shortcut replayed only the legacy primary array.
    Purple StarType-4 systems place ordinary bodies in the secondary array, so
    that shortcut discarded valid moon parents and caused 1/2-moon searches to
    return only giants. Candidate-array replay already exposes the exact
    auxiliary parent index for every active body and works in both domains.
    """
    engine = load_parent_structure_engine()
    decoded = engine.v2m.decode_portal(
        canonical_system_portal, galaxy_index
    )
    system = engine.v2m.predict_system(decoded)
    replay = engine.v2m.predict_planet_seeds(decoded, system)
    bodies = list(replay.get("bodies", []))
    if len(bodies) != len(rows):
        raise RuntimeError(
            "Candidate parent replay disagrees with predicted planet count: "
            f"candidate={len(bodies)}, rows={len(rows)}"
        )

    row_sizes = [int(row.get("planet_size", -1)) for row in rows]
    replay_sizes = [int(body.get("source_class", -1)) for body in bodies]
    if replay_sizes != row_sizes:
        raise RuntimeError(
            "Candidate parent replay disagrees with predicted native size classes: "
            f"candidate={replay_sizes}, rows={row_sizes}"
        )

    parents: list[int] = []
    for index, body in enumerate(bodies):
        size = row_sizes[index]
        candidate_parent = int(body.get("auxiliary_parent_index", -1))
        # Parent metadata is meaningful only for native Moon class 3.
        parents.append(candidate_parent if size == 3 else -1)

    moon_counts = {index: 0 for index in range(len(rows))}
    for child_index, parent_index in enumerate(parents):
        if row_sizes[child_index] == 3 and 0 <= parent_index < len(rows):
            moon_counts[parent_index] += 1

    for index, row in enumerate(rows):
        parent_index = int(parents[index])
        size = int(row.get("planet_size", -1))
        is_moon = size == 3
        parent_category = ""
        parent_number = None
        parent_portal = ""
        if is_moon and 0 <= parent_index < len(rows):
            parent = rows[parent_index]
            parent_number = internal_slot_to_gameplay_planet_number(parent_index)
            parent_portal = exact_planet_portal_address(
                canonical_system_portal, parent_index
            )
            if int(parent.get("biome", -1)) == 15:
                parent_category = "Gas giant"
            elif int(parent.get("planet_size", -1)) == 4:
                parent_category = "Giant planet"
            else:
                parent_category = "Normal planet"
        row.update({
            "is_moon": is_moon,
            "moon_count": 0 if is_moon else int(moon_counts.get(index, 0)),
            "can_own_moons": size in {0, 4},
            "moon_parent_internal_slot": parent_index if is_moon else None,
            "moon_parent_gameplay_planet_number": parent_number,
            "moon_parent_exact_planet_portal": parent_portal,
            "moon_parent_body_type": parent_category,
            "moon_parent_mapping_exact": bool(is_moon and parent_category),
            "moon_parent_mapping_status": (
                "exact_candidate_array_auxiliary_parent_v1048r1"
                if is_moon and parent_category
                else ("not_a_moon" if not is_moon else "moon_parent_unresolved")
            ),
            "moon_parent_replay_branch": str(replay.get("branch", "")),
        })

def enrich_moon_parent_metadata(rows: list[dict[str, Any]]) -> None:
    """Copy exact resolved-parent ring/name/body metadata onto every moon row."""
    for row in rows:
        if not bool(row.get("is_moon")):
            row.update({
                "moon_parent_has_rings": None,
                "moon_parent_ring_prediction_exact": False,
                "moon_parent_default_procedural_name": "",
                "moon_parent_generated_size": "",
                "moon_parent_summary": "Not a moon",
            })
            continue
        parent_index = row.get("moon_parent_internal_slot")
        if not isinstance(parent_index, int) or not 0 <= parent_index < len(rows):
            row.update({
                "moon_parent_has_rings": None,
                "moon_parent_ring_prediction_exact": False,
                "moon_parent_default_procedural_name": "",
                "moon_parent_generated_size": "",
                "moon_parent_summary": "Parent unresolved",
            })
            continue
        parent = rows[parent_index]
        has_rings = bool(parent.get("has_rings"))
        exact = bool(parent.get("rings_prediction_exact"))
        parent_name = str(parent.get("default_procedural_planet_name", ""))
        parent_size = str(parent.get("body_type_and_size_display", parent.get("world_size_display", "")))
        parent_type = str(row.get("moon_parent_body_type", ""))
        parent_portal = str(row.get("moon_parent_exact_planet_portal", ""))
        row.update({
            "moon_parent_has_rings": has_rings,
            "moon_parent_ring_prediction_exact": exact,
            "moon_parent_default_procedural_name": parent_name,
            "moon_parent_generated_size": parent_size,
            "moon_parent_body_type": parent_type,
            "moon_parent_exact_planet_portal": parent_portal,
            "moon_parent_summary": (
                f"{parent_name or parent_type or 'Parent'} • {parent_size or parent_type} • "
                f"{'rings' if has_rings else 'no rings'} • {parent_portal}"
            ),
        })


def load_v4y():
    global _V4Y_MODULE
    if _V4Y_MODULE is not None:
        return _V4Y_MODULE

    if not V4Y_PATH.is_file():
        raise FileNotFoundError(V4Y_PATH)

    ensure_engine_import_paths()

    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v1_v4y",
        V4Y_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load the bundled V4Y engine: {V4Y_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _V4Y_MODULE = module
    return module


def load_native_legacy_count_engine():
    global _NATIVE_LEGACY_COUNT_MODULE
    if _NATIVE_LEGACY_COUNT_MODULE is not None:
        return _NATIVE_LEGACY_COUNT_MODULE
    if not NATIVE_LEGACY_COUNT_ENGINE_PATH.is_file():
        raise FileNotFoundError(NATIVE_LEGACY_COUNT_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v1019_native_legacy_count",
        NATIVE_LEGACY_COUNT_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load native legacy-count engine: "
            f"{NATIVE_LEGACY_COUNT_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _NATIVE_LEGACY_COUNT_MODULE = module
    return module


def load_region_traversal_engine():
    global _REGION_TRAVERSAL_MODULE
    if _REGION_TRAVERSAL_MODULE is not None:
        return _REGION_TRAVERSAL_MODULE
    if not REGION_TRAVERSAL_ENGINE_PATH.is_file():
        raise FileNotFoundError(REGION_TRAVERSAL_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v1020_region_traversal",
        REGION_TRAVERSAL_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load region traversal engine: "
            f"{REGION_TRAVERSAL_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _REGION_TRAVERSAL_MODULE = module
    return module


def load_parallel_system_engine():
    global _PARALLEL_SYSTEM_MODULE
    if _PARALLEL_SYSTEM_MODULE is not None:
        return _PARALLEL_SYSTEM_MODULE
    if not PARALLEL_SYSTEM_ENGINE_PATH.is_file():
        raise FileNotFoundError(PARALLEL_SYSTEM_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_parallel_system_search_v20f2",
        PARALLEL_SYSTEM_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(PARALLEL_SYSTEM_ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _PARALLEL_SYSTEM_MODULE = module
    return module


def load_colour_display_engine():
    global _COLOUR_DISPLAY_MODULE
    if _COLOUR_DISPLAY_MODULE is not None:
        return _COLOUR_DISPLAY_MODULE
    if not COLOUR_DISPLAY_ENGINE_PATH.is_file():
        raise FileNotFoundError(COLOUR_DISPLAY_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_colour_display_v20f4",
        COLOUR_DISPLAY_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(COLOUR_DISPLAY_ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _COLOUR_DISPLAY_MODULE = module
    return module


def colour_display_payload(value: str) -> dict[str, Any]:
    return load_colour_display_engine().display_payload(value)


def system_worker_profile() -> dict[str, Any]:
    return load_parallel_system_engine().hardware_profile()


def system_worker_option_values() -> tuple[str, ...]:
    return load_parallel_system_engine().worker_option_values()


def normalize_system_worker_request(value: int | str | None) -> int:
    if value is None:
        return 0
    if isinstance(value, int):
        requested = value
    else:
        text = str(value).strip().casefold()
        if not text or text.startswith("auto"):
            return 0
        if text.startswith("max"):
            return -1
        match = re.search(r"-?\d+", text)
        if not match:
            raise ValueError(
                "System workers must be Auto, Maximum CPU, or an integer."
            )
        requested = int(match.group(0))
    # Resolve against one nominal task to validate the hardware ceiling while
    # preserving the user's configured request.
    load_parallel_system_engine().resolve_worker_request(requested, 1)
    return requested


def system_worker_note(value: int | str | None = 0) -> str:
    return load_parallel_system_engine().worker_note(value)


def region_space_metadata(anchor_portal: str | None = None) -> dict[str, Any]:
    engine = load_region_traversal_engine()
    suffix = portal_region_suffix(anchor_portal) if anchor_portal else None
    result = dict(engine.space_metadata(suffix))
    result["distance_sorted_sphere"] = False
    return result


def region_suffix_at_offset(anchor_portal: str, offset: int) -> str:
    canonical = normalize_portal(anchor_portal)
    engine = load_region_traversal_engine()
    return engine.region_suffix_at_offset(
        portal_region_suffix(canonical),
        int(offset),
    )


def portal_with_region_suffix(anchor_portal: str, region_suffix: str) -> str:
    canonical = normalize_portal(anchor_portal)
    engine = load_region_traversal_engine()
    suffix = engine.normalize_region_suffix(region_suffix)
    engine.decode_region_suffix(suffix, require_canonical=True)
    return canonical[:4] + suffix


def native_legacy_system_count_metadata(
    anchor_portal: str,
    galaxy: int = 0,
    *,
    allow_replay: bool = True,
    force_replay: bool = False,
) -> dict[str, Any]:
    canonical = normalize_portal(anchor_portal)
    engine = load_native_legacy_count_engine()
    return engine.resolve_native_legacy_system_count(
        portal=canonical,
        galaxy_index=int(galaxy),
        dump_path=Path(),
        controls_path=NATIVE_LEGACY_COUNT_CONTROLS_PATH,
        cache_path=NATIVE_LEGACY_COUNT_CACHE_PATH,
        allow_replay=bool(allow_replay),
        force_replay=bool(force_replay),
    )


def run_native_legacy_count_static_regression() -> dict[str, Any]:
    engine = load_native_legacy_count_engine()
    static = engine.verify_static(
        Path(),
        NATIVE_LEGACY_COUNT_CONTROLS_PATH,
    )
    controls = load_json(NATIVE_LEGACY_COUNT_CONTROLS_PATH)
    expected = {
        (0, "239D7F56"): 564,
        (0, "239D7F55"): 562,
        (0, "239D6F56"): 231,
        (0, "229D7F56"): 546,
    }
    observed = {}
    for (galaxy_index, suffix), count in expected.items():
        row = native_legacy_system_count_metadata(
            f"0000{suffix}",
            galaxy_index,
            allow_replay=False,
        )
        observed[(galaxy_index, suffix)] = int(
            row.get("generated_legacy_system_count", -1)
        )
    controls_exact = observed == expected
    purple = controls.get("purple", {})
    purple_exact = (
        int(purple.get("start", -1)) == 0x3E9
        and int(purple.get("count", -1)) == 64
        and int(purple.get("last", -1)) == 0x428
        and int(purple.get("first_invalid", -1)) == 0x429
    )
    exact = bool(static.get("exact") and controls_exact and purple_exact)
    return {
        "status": (
            "PASS_STANDALONE_LEGACY_SYSTEM_COUNT_STATIC_V20G1"
            if exact
            else "ERROR_STANDALONE_LEGACY_SYSTEM_COUNT_STATIC_V20G1"
        ),
        "exact": exact,
        "static": static,
        "controls_exact": controls_exact,
        "purple_exact": purple_exact,
        "expected": {
            f"{galaxy}:{suffix}": count
            for (galaxy, suffix), count in expected.items()
        },
        "observed": {
            f"{galaxy}:{suffix}": count
            for (galaxy, suffix), count in observed.items()
        },
    }


def load_life_creature_engine():
    global _LIFE_CREATURE_MODULE
    if _LIFE_CREATURE_MODULE is not None:
        return _LIFE_CREATURE_MODULE
    if not LIFE_CREATURE_ENGINE_PATH.is_file():
        raise FileNotFoundError(LIFE_CREATURE_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v107_life_creature",
        LIFE_CREATURE_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load Life/Creature engine: "
            f"{LIFE_CREATURE_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _LIFE_CREATURE_MODULE = module
    return module


def load_special_system_engine():
    global _SPECIAL_SYSTEM_MODULE
    if _SPECIAL_SYSTEM_MODULE is not None:
        return _SPECIAL_SYSTEM_MODULE
    if not SPECIAL_SYSTEM_ENGINE_PATH.is_file():
        raise FileNotFoundError(SPECIAL_SYSTEM_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_special_system",
        SPECIAL_SYSTEM_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load special-system engine: "
            f"{SPECIAL_SYSTEM_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _SPECIAL_SYSTEM_MODULE = module
    return module


def load_special_planet_engine():
    global _SPECIAL_PLANET_MODULE
    if _SPECIAL_PLANET_MODULE is not None:
        return _SPECIAL_PLANET_MODULE
    if not SPECIAL_PLANET_ENGINE_PATH.is_file():
        raise FileNotFoundError(SPECIAL_PLANET_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_special_planet",
        SPECIAL_PLANET_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load special-planet engine: "
            f"{SPECIAL_PLANET_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _SPECIAL_PLANET_MODULE = module
    return module


def load_sentinel_difficulty_engine():
    global _SENTINEL_DIFFICULTY_MODULE
    if _SENTINEL_DIFFICULTY_MODULE is not None:
        return _SENTINEL_DIFFICULTY_MODULE
    if not SENTINEL_DIFFICULTY_ENGINE_PATH.is_file():
        raise FileNotFoundError(SENTINEL_DIFFICULTY_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_sentinel_difficulty",
        SENTINEL_DIFFICULTY_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load Sentinel-difficulty engine: "
            f"{SENTINEL_DIFFICULTY_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _SENTINEL_DIFFICULTY_MODULE = module
    return module


def load_terminology_engine():
    global _TERMINOLOGY_MODULE
    if _TERMINOLOGY_MODULE is not None:
        return _TERMINOLOGY_MODULE
    if not TERMINOLOGY_ENGINE_PATH.is_file():
        raise FileNotFoundError(TERMINOLOGY_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_exact_terminology_v19b",
        TERMINOLOGY_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load exact-terminology engine: "
            f"{TERMINOLOGY_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _TERMINOLOGY_MODULE = module
    return module


def infer_planet_type_token(row: dict[str, Any]) -> str:
    """Infer the exact Planet/Moon body token from the validated size class."""
    existing = str(
        row.get("planet_type_token") or row.get("planet_type") or ""
    ).strip()
    if existing:
        return existing
    size = int(row.get("planet_size", -1))
    if size == 3:
        return "PLANETCLASS2"
    if size == 4:
        return "DISC_TYPE_GIANT"
    if size in (0, 1, 2):
        return "PLANETCLASS1"
    return ""


def apply_exact_terminology(row: dict[str, Any]) -> dict[str, Any]:
    output = dict(row)
    inferred_token = infer_planet_type_token(output)
    if inferred_token:
        output.setdefault("planet_type_token", inferred_token)
        output.setdefault("planet_type", inferred_token)
    terminology_input = dict(output)
    giant_world = inferred_token == "DISC_TYPE_GIANT"
    if giant_world:
        # DISC_TYPE_GIANT is an internal body type, not a localisation token
        # for the %PLANETCLASS% placeholder. Giant worlds still use "Planet"
        # in scanner classifications such as Paradise Planet or Humid Planet.
        terminology_input["planet_type_token"] = "PLANETCLASS1"
        terminology_input["planet_type"] = "PLANETCLASS1"

    terminology = load_terminology_engine().enrich_row(
        terminology_input,
        TERMINOLOGY_CATALOG_PATH,
    )
    if giant_world:
        terminology.update({
            "planet_body_type_display": "Giant Planet",
            "planet_body_type_token": "DISC_TYPE_GIANT",
            "planet_body_type_exact": True,
            "planet_classification_giant_grammar_token": "PLANETCLASS1",
            "planet_classification_giant_grammar_status": (
                "giant_world_uses_planet_placeholder_grammar_v20h15"
            ),
        })
    output.update(terminology)
    if giant_world:
        classification = str(output.get("planet_classification_display", ""))
        if classification.endswith(" Planet"):
            output["planet_classification_display"] = classification[:-7] + " Giant"
            output["planet_classification_giant_display_status"] = "body_suffix_hardened_v20h22"
    output["planet_classification_live_override"] = False
    portal_key = str(output.get("planet_portal", "")).strip().upper()
    live_override = LIVE_PLANET_CLASSIFICATION_OVERRIDES_V20C6.get(portal_key)
    if live_override is not None:
        output["planet_classification_display"] = live_override["display"]
        output["planet_classification_exact"] = True
        output["planet_classification_resolution"] = live_override["resolution"]
        output["planet_classification_source_files"] = [live_override["evidence"]]
        output["planet_classification_live_override"] = True
        if "literal_paradise" in live_override:
            output["literal_paradise"] = bool(live_override["literal_paradise"])
            output["literal_paradise_live_override"] = True
    output["planet_type_inference_status"] = (
        "validated_v19i1b_planet_size_mapping_71_of_71"
        if inferred_token
        else "planet_type_unresolved"
    )
    return output


def load_fauna_taxonomy_engine():
    global _FAUNA_TAXONOMY_MODULE
    if _FAUNA_TAXONOMY_MODULE is not None:
        return _FAUNA_TAXONOMY_MODULE
    if not FAUNA_TAXONOMY_ENGINE_PATH.is_file():
        raise FileNotFoundError(FAUNA_TAXONOMY_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_fauna_taxonomy_v19c1",
        FAUNA_TAXONOMY_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load fauna-taxonomy engine: "
            f"{FAUNA_TAXONOMY_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _FAUNA_TAXONOMY_MODULE = module
    return module


def apply_fauna_taxonomy(row: dict[str, Any]) -> dict[str, Any]:
    output = dict(row)
    output.update(
        load_fauna_taxonomy_engine().enrich_row(
            output,
            FAUNA_TAXONOMY_CATALOG_PATH,
            FAUNA_DESCRIPTOR_CATALOG_PATH,
        )
    )
    return output


def apply_names_and_water_profile(
    row: dict[str, Any],
    *,
    default_system_name: dict[str, Any],
) -> dict[str, Any]:
    output = dict(row)
    seed_text = str(output.get("planet_seed_hex") or "").strip()
    if not seed_text:
        raise KeyError("planet_seed_hex")
    root_seed = int(seed_text, 0)
    planet_name = load_planet_name_engine().predict_planet_name(root_seed)
    water = load_water_profile_engine().predict(
        root_seed,
        int(output["biome"]),
        int(output["biome_subtype"]),
    )
    style = dict(water["style"])
    murkyness = dict(water["murkyness"])
    water_emission = dict(water["WaterEmission"])
    foam_emission = dict(water["FoamEmission"])
    intrinsic = dict(style.get("intrinsic_foam_emission", {}))
    hue = str(foam_emission.get("normalised_hue_preview_hex", "")).upper()
    foam_mode = str(foam_emission.get("timing", foam_emission.get("enum_name", "None")))
    water_present = bool(output.get("water_active"))
    glow_display = (
        f"{foam_mode} • intrinsic {hue}"
        if bool(foam_emission.get("active"))
        else "No intrinsic foam emission"
    )
    profile_display = (
        f"Style {style.get('index')} ({style.get('family')}); "
        f"murkiness {float(murkyness.get('value_f32', 0.0)):.6g}; "
        f"{glow_display}"
    )
    output.update({
        "default_procedural_planet_name": planet_name["default_procedural_name"],
        "default_planet_name_language": planet_name.get("language", "English"),
        "default_planet_name_style": int(planet_name["style"]),
        "default_planet_name_components": dict(planet_name.get("components", {})),
        "default_planet_name_exact": True,
        "default_planet_name_scope": "default_procedural_not_current_discovery_name",
        "default_procedural_system_name": default_system_name["default_procedural_name"],
        "default_system_name_exact": True,
        "default_system_name_scope": "default_procedural_not_current_discovery_name",
        "water_style_index": int(style["index"]),
        "water_style_family": str(style["family"]),
        "water_style_selection_weighting": float(style["selection_weighting"]),
        "water_murkyness": float(murkyness["value_f32"]),
        "water_murkyness_bits_hex": str(murkyness["bits_hex"]).upper(),
        "water_emission_enum": int(water_emission["enum"]),
        "water_emission_mode": str(water_emission["enum_name"]),
        "water_emission_active": bool(water_emission["active"]),
        "foam_emission_enum": int(foam_emission["enum"]),
        "foam_emission_mode": foam_mode,
        "foam_emission_active": bool(foam_emission["active"]),
        "intrinsic_foam_emission_rgba": list(foam_emission.get("intrinsic_hdr_rgba", [])),
        "intrinsic_foam_emission_hue_hex": hue,
        "intrinsic_foam_emission_colour_family": str(style.get("family", "")),
        "intrinsic_foam_emission_record": intrinsic,
        "water_profile_display": profile_display if water_present else f"No ocean • generated {profile_display}",
        "water_glow_display": glow_display if water_present else "No ocean",
        "water_profile_exact": True,
        "water_profile_regression_status": "25_of_25_exact_v1059",
        "water_rendering_boundary": water.get("rendering_boundary", {}),
    })
    return output


def apply_grass_glow_prediction(row: dict[str, Any]) -> dict[str, Any]:
    output = dict(row)
    seed_text = str(
        output.get("planet_seed_hex")
        or output.get("root_seed_hex")
        or ""
    ).strip()
    if not seed_text:
        raise KeyError("planet_seed_hex")
    if output.get("life_level") not in (0, 1, 2, 3):
        raise ValueError("Exact Life level is required for surface object-list replay.")

    root_seed = int(seed_text, 0)
    surface = load_surface_objectlist_rule().predict(
        planet_seed=root_seed,
        biome=int(output["biome"]),
        biome_subtype=int(output["biome_subtype"]),
        life_level=int(output["life_level"]),
    )
    source_file = str(surface["source_file"]).replace("\\", "/").upper()
    colours = load_grass_colour_rule().predict(
        planet_root_seed=root_seed,
        biome_source_file=str(surface["source_file"]),
    )

    bubble_grass_sources = {
        "METADATA/SIMULATION/SOLARSYSTEM/BIOMES/LUSH/LUSHBUBBLESBIOME.MBIN",
        "METADATA/SIMULATION/SOLARSYSTEM/BIOMES/LUSH/LUSHROOMABIOME.MBIN",
        "METADATA/SIMULATION/SOLARSYSTEM/BIOMES/LUSH/LUSHROOMBBIOME.MBIN",
    }
    exact_bubble_grass = source_file in bubble_grass_sources

    capability = dict(surface.get("capability", {}))
    surface_flags = dict(surface.get("surface_capability", {}))
    visual_flora = load_visual_flora_rule().classify_capability(
        capability
    )
    # Exact display closure: generated Grass input #AD9284 renders as the rare white grass in-game.
    # Live tests produced white, pale-purple and yellow rendering from the
    # same broad Bubble-Grass route, so no universal white selector is exposed.
    main = dict(surface["main"])
    white_glow_scene_present = bool(exact_bubble_grass)
    white_glow_available = False
    grass = dict(colours["grass"])
    grass_alt = dict(colours["grass_alt"])
    grass_primary = dict(grass["primary"])
    grass_alt_primary = dict(grass_alt["primary"])
    colour_display = load_colour_display_engine()
    grass_primary_display = colour_display.display_payload(
        str(grass_primary["hex"])
    )
    grass_alt_primary_display = colour_display.display_payload(
        str(grass_alt_primary["hex"])
    )
    water = dict(colours["water"])
    deep_water = dict(colours["deep_water_biolum"])

    def present_palette_channel(channel: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        presented: list[dict[str, Any]] = []
        for item in channel.get("colours", []):
            display = colour_display.display_payload(str(item["hex"]))
            presented.append({
                **dict(item),
                "hex": str(item["hex"]).upper(),
                "precise_colour_name": display["name"],
                "colour_display": display["display"],
                "swatch_background": display["swatch_background"],
                "swatch_foreground": display["swatch_foreground"],
            })
        if not presented:
            raise RuntimeError("Generated palette channel was empty.")
        return presented, presented[0]

    water_colours, water_primary = present_palette_channel(water)
    deep_water_colours, deep_water_primary = present_palette_channel(deep_water)

    output.update({
        "surface_biome_source_file": surface["source_file"],
        "surface_main_object_list": main["selected_path"],
        "surface_main_selected_index": int(main["selected_index"]),
        "surface_main_selection_mode": (
            "Life override"
            if bool(main.get("choose_using_life_level"))
            else "Selector RNG"
        ),
        "surface_main_rng_index": int(main["rng_index"]),
        "surface_main_probability_word": int(main["probability_word"]),
        "surface_main_index_word": int(main["index_word"]),
        "surface_objectlist_selector_child": 8,
        "surface_objectlist_prediction_status": (
            "validated_v20a7_47_of_47_address_only"
        ),
        "surface_objectlist_claim": surface["claim"],
        "explicit_grass_asset_available": bool(
            surface_flags.get("explicit_grass_asset_available")
        ),
        "any_emissive_grass_asset_available": bool(
            surface_flags.get("glowing_grass_asset_available")
        ),
        "any_emissive_grass_scenes": list(
            visual_flora["any_emissive_grass_scenes"]
        ),
        "glowing_grass_asset_available": bool(exact_bubble_grass),
        "bioluminescent_grass_carpet_available": bool(exact_bubble_grass),
        "bioluminescent_grass_carpet_scenes": (
            list(visual_flora["bioluminescent_grass_carpet_scenes"])
            if exact_bubble_grass else []
        ),
        "bioluminescent_grass_source_rule_exact": True,
        "bioluminescent_grass_source_rule_status": (
            "exact_lush_subbiome_membership_v1048r1"
        ),
        "bioluminescent_grass_source_rule_claim": (
            "Bioluminescent Bubble Grass is always present on Lush Bubble, "
            "LushRoom A and LushRoom B, and absent from other Lush subbiomes. "
            "Broad emissive props on non-Lush worlds remain separate metadata."
        ),
        "white_glow_bubble_grass_available": False,
        "white_glow_bubble_grass_detection_exact": False,
        "white_glow_bubble_grass_live_validated": False,
        "white_glow_bubble_grass_scene_present": bool(white_glow_scene_present),
        "white_glow_bubble_grass_scene": "",
        "white_glow_bubble_grass_material": "",
        "white_glow_bubble_grass_material_colour_hex": "",
        "white_glow_bubble_grass_material_colour_rgba": [],
        "white_glow_bubble_grass_match_ground_colour": False,
        "white_glow_bubble_grass_ground_colour_index": "",
        "white_glow_bubble_grass_status": "unsupported_visible_white_colour_not_searchable_v20h8",
        "white_glow_bubble_grass_claim": (
            "White rendered grass/glow colour is not predicted in this release. "
            "Use the general Bioluminescent Bubble Grass filter and the exact "
            "generated Grass/GrassAlt palette previews instead."
        ),
        "ground_foliage_candidate_available": bool(
            surface_flags.get("ground_foliage_candidate_available")
        ),
        "glowing_ground_foliage_available": bool(
            surface_flags.get("glowing_ground_foliage_available")
        ),
        "mushroom_asset_available": bool(
            surface_flags.get("mushroom_asset_available")
        ),
        "any_emissive_mushroom_asset_available": bool(
            surface_flags.get("glowing_mushroom_asset_available")
        ),
        "any_emissive_mushroom_scenes": list(
            visual_flora["any_emissive_mushroom_scenes"]
        ),
        "glowing_mushroom_asset_available": bool(
            visual_flora["large_glowing_mushroom_tree_available"]
        ),
        "large_glowing_mushroom_tree_available": bool(
            visual_flora["large_glowing_mushroom_tree_available"]
        ),
        "large_glowing_mushroom_tree_scenes": list(
            visual_flora["large_glowing_mushroom_tree_scenes"]
        ),
        "small_glowing_mushroom_flora_available": bool(
            visual_flora["small_glowing_mushroom_flora_available"]
        ),
        "small_glowing_mushroom_flora_scenes": list(
            visual_flora["small_glowing_mushroom_flora_scenes"]
        ),
        "visual_flora_claim": visual_flora["claim"],
        "explicit_grass_scene_count": int(
            capability.get("explicit_grass_scene_count", 0)
        ),
        "any_emissive_grass_scene_count": int(
            capability.get("glowing_grass_scene_count", 0)
        ),
        "glowing_grass_scene_count": (
            len(visual_flora["bioluminescent_grass_carpet_scenes"])
            if exact_bubble_grass else 0
        ),
        "mushroom_scene_count": int(
            capability.get("mushroom_scene_count", 0)
        ),
        "any_emissive_mushroom_scene_count": int(
            capability.get("glowing_mushroom_scene_count", 0)
        ),
        "glowing_mushroom_scene_count": len(
            visual_flora["large_glowing_mushroom_tree_scenes"]
        ),
        "explicit_grass_scenes": list(
            capability.get("explicit_grass_scenes", [])
        ),
        "glowing_grass_scenes": (
            list(visual_flora["bioluminescent_grass_carpet_scenes"])
            if exact_bubble_grass else []
        ),
        "mushroom_scenes": list(
            capability.get("mushroom_scenes", [])
        ),
        "glowing_mushroom_scenes": list(
            visual_flora["large_glowing_mushroom_tree_scenes"]
        ),
        "colour_palette_file": colours["colour_palette_file"],
        "planet_palette_writer_seed_hex": colours["palette_writer_seed_hex"],
        "planet_palette_writer_seed_rule": colours["palette_writer_seed_rule"],
        "final_palette_seed_hex": colours["final_palette_seed_hex"],
        "generated_water_source_indices": list(water["source_indices"]),
        "generated_water_primary_rgba": list(water_primary["rgba"]),
        "generated_water_primary_hex": str(water_primary["hex"]).upper(),
        "generated_water_primary_colour_family": water_primary["colour_family"],
        "generated_water_primary_precise_colour_name": water_primary["precise_colour_name"],
        "generated_water_primary_colour_display": water_primary["colour_display"],
        "generated_water_primary_swatch_background": water_primary["swatch_background"],
        "generated_water_primary_swatch_foreground": water_primary["swatch_foreground"],
        "generated_water_palette_colours": water_colours,
        "generated_water_palette_summary": " • ".join(
            item["colour_display"] for item in water_colours
        ),
        "generated_water_palette_exact": True,
        "generated_water_palette_status": "exact_native_palette_channel_15_v1052",
        "deep_water_biolum_source_indices": list(deep_water["source_indices"]),
        "deep_water_biolum_primary_rgba": list(deep_water_primary["rgba"]),
        "deep_water_biolum_primary_hex": str(deep_water_primary["hex"]).upper(),
        "deep_water_biolum_primary_colour_family": deep_water_primary["colour_family"],
        "deep_water_biolum_primary_precise_colour_name": deep_water_primary["precise_colour_name"],
        "deep_water_biolum_primary_colour_display": deep_water_primary["colour_display"],
        "deep_water_biolum_primary_swatch_background": deep_water_primary["swatch_background"],
        "deep_water_biolum_primary_swatch_foreground": deep_water_primary["swatch_foreground"],
        "deep_water_biolum_palette_colours": deep_water_colours,
        "deep_water_biolum_palette_summary": " • ".join(
            item["colour_display"] for item in deep_water_colours
        ),
        "deep_water_biolum_palette_exact": True,
        "deep_water_biolum_palette_status": "exact_native_palette_channel_63_three_stage_seed_v1052",
        "grass_source_indices": list(grass["source_indices"]),
        "grass_primary_rgba": list(grass_primary["rgba"]),
        "grass_primary_hex": str(grass_primary["hex"]).upper(),
        "grass_primary_colour_family": grass_primary["colour_family"],
        "grass_primary_precise_colour_name": grass_primary_display["name"],
        "grass_primary_colour_display": grass_primary_display["display"],
        "grass_primary_swatch_background": grass_primary_display["swatch_background"],
        "grass_primary_swatch_foreground": grass_primary_display["swatch_foreground"],
        "grass_palette_colours": list(grass["colours"]),
        "grass_alt_source_indices": list(grass_alt["source_indices"]),
        "grass_alt_primary_rgba": list(grass_alt_primary["rgba"]),
        "grass_alt_primary_hex": str(grass_alt_primary["hex"]).upper(),
        "grass_alt_primary_colour_family": grass_alt_primary["colour_family"],
        "grass_alt_primary_precise_colour_name": grass_alt_primary_display["name"],
        "grass_alt_primary_colour_display": grass_alt_primary_display["display"],
        "grass_alt_primary_swatch_background": grass_alt_primary_display["swatch_background"],
        "grass_alt_primary_swatch_foreground": grass_alt_primary_display["swatch_foreground"],
        "grass_alt_palette_colours": list(grass_alt["colours"]),
        "grass_colour_summary": grass_primary_display["display"],
        "grass_alt_colour_summary": grass_alt_primary_display["display"],
        "grass_palette_presentation_claim": (
            "Grass and GrassAlt are exact generated five-slot surface/flora palette "
            "sequences. The two primary filters inspect slot 0; the combined filter "
            "searches all ten generated slots. Live tests found these colours in "
            "ordinary grass, alternate grass, shrubs and tree-like flora. They do "
            "not determine the Bioluminescent Bubble Grass rendered glow colour."
        ),
        "grass_colour_prediction_status": (
            "validated_generated_surface_flora_palette_sequences_v20h10"
        ),
        "grass_colour_claim": (
            "Exact generated Grass and GrassAlt surface/flora palette data. Primary "
            "filters use slot 0 and the combined filter searches every generated "
            "slot; Bubble Grass glow colour is a separate unresolved channel."
        ),
        "generated_grass_filter_scope": (
            "primary_slot_0_plus_all_ten_slot_combined_filter"
        ),
        "visible_grass_colour_exact": False,
        "visible_white_glow_live_validated": False,
        "visible_grass_colour_prediction_status": (
            "generated_palette_exact_visible_model_channel_not_universal"
        ),
        "visible_grass_colour_claim": (
            "Generated Grass/GrassAlt surface-flora palette values are exact and "
            "live-tested, but they can appear on different ordinary flora assets. "
            "The Bioluminescent Bubble Grass rendered glow colour is not predicted "
            "or searchable in this release."
        ),
        "bubble_grass_asset_presence_exact": True,
        "bubble_grass_glow_colour_exact": False,
        "bubble_grass_glow_colour_prediction_status": (
            "asset_presence_exact_rendered_glow_colour_unresolved_v20h10"
        ),
        "bubble_grass_glow_colour_claim": (
            "ATLAS can predict whether the BUBBLELUSHGRASS carpet asset is present. "
            "Its final rendered glow colour can differ from the generated Grass and "
            "GrassAlt palette channels and is not predicted."
        ),
        "specific_model_visible_colour_channel_complete": False,
        "visual_surface_coverage_confirmed": False,
    })
    atmosphere = load_atmosphere_colour_rule().predict(
        planet_root_seed=root_seed,
        biome_source_file=str(surface["source_file"]),
        biome=int(output["biome"]),
        biome_subtype=int(output["biome_subtype"]),
    )
    output.update(atmosphere["flat_fields"])
    return output


def load_professional_hardening_engine():
    global _PROFESSIONAL_HARDENING_MODULE
    if _PROFESSIONAL_HARDENING_MODULE is not None:
        return _PROFESSIONAL_HARDENING_MODULE
    if not PROFESSIONAL_HARDENING_ENGINE_PATH.is_file():
        raise FileNotFoundError(PROFESSIONAL_HARDENING_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v108_professional_hardening_v19e",
        PROFESSIONAL_HARDENING_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load professional-hardening engine: "
            f"{PROFESSIONAL_HARDENING_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _PROFESSIONAL_HARDENING_MODULE = module
    return module


def load_surface_objectlist_engine():
    global _SURFACE_OBJECTLIST_MODULE
    if _SURFACE_OBJECTLIST_MODULE is not None:
        return _SURFACE_OBJECTLIST_MODULE
    if not SURFACE_OBJECTLIST_ENGINE_PATH.is_file():
        raise FileNotFoundError(SURFACE_OBJECTLIST_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v109_surface_objectlist_v20a7",
        SURFACE_OBJECTLIST_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load surface-object-list engine: "
            f"{SURFACE_OBJECTLIST_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _SURFACE_OBJECTLIST_MODULE = module
    return module


def load_grass_colour_engine():
    global _GRASS_COLOUR_MODULE
    if _GRASS_COLOUR_MODULE is not None:
        return _GRASS_COLOUR_MODULE
    if not GRASS_COLOUR_ENGINE_PATH.is_file():
        raise FileNotFoundError(GRASS_COLOUR_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v109_grass_colour_v20a8a",
        GRASS_COLOUR_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load grass-colour engine: "
            f"{GRASS_COLOUR_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _GRASS_COLOUR_MODULE = module
    return module


def load_visual_flora_engine():
    global _VISUAL_FLORA_MODULE
    if _VISUAL_FLORA_MODULE is not None:
        return _VISUAL_FLORA_MODULE
    if not VISUAL_FLORA_ENGINE_PATH.is_file():
        raise FileNotFoundError(VISUAL_FLORA_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v1010_visual_flora_v20b2",
        VISUAL_FLORA_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load visual-flora engine: "
            f"{VISUAL_FLORA_ENGINE_PATH}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _VISUAL_FLORA_MODULE = module
    return module


def load_visual_flora_rule():
    global _VISUAL_FLORA_RULE
    if _VISUAL_FLORA_RULE is None:
        module = load_visual_flora_engine()
        _VISUAL_FLORA_RULE = module.VisualFloraRule(
            VISUAL_FLORA_RULE_DATA_PATH,
        )
    return _VISUAL_FLORA_RULE


def load_surface_objectlist_rule():
    global _SURFACE_OBJECTLIST_RULE
    if _SURFACE_OBJECTLIST_RULE is None:
        module = load_surface_objectlist_engine()
        _SURFACE_OBJECTLIST_RULE = module.SurfaceObjectListRule(
            SURFACE_OBJECTLIST_RULE_DATA_PATH,
            OBJECTLIST_CAPABILITIES_PATH,
        )
    return _SURFACE_OBJECTLIST_RULE


def load_grass_colour_rule():
    global _GRASS_COLOUR_RULE
    if _GRASS_COLOUR_RULE is None:
        module = load_grass_colour_engine()
        _GRASS_COLOUR_RULE = module.GrassColourRule(
            GRASS_COLOUR_RULE_DATA_PATH,
        )
    return _GRASS_COLOUR_RULE


def grass_colour_filter_values() -> tuple[str, ...]:
    """Broad generated-colour families retained for presets and CLI use."""
    return GRASS_COLOUR_FILTER_VALUES


def load_grass_exact_colour_catalog() -> dict[str, Any]:
    """Load the deduplicated catalogue of reachable Grass/GrassAlt RGB values."""
    global _GRASS_EXACT_COLOUR_CATALOG_CACHE
    if _GRASS_EXACT_COLOUR_CATALOG_CACHE is None:
        _GRASS_EXACT_COLOUR_CATALOG_CACHE = load_json(
            GRASS_EXACT_COLOUR_CATALOG_PATH
        )
    return dict(_GRASS_EXACT_COLOUR_CATALOG_CACHE)


def grass_exact_colour_catalog(
    scope: str = "either_any_slot",
) -> tuple[dict[str, Any], ...]:
    """Return exact reachable colours for one public grass-filter scope.

    Scopes:
    - grass_primary: slot 0 of generated Grass;
    - grass_alt_primary: slot 0 of generated GrassAlt;
    - either_primary: slot 0 of either channel;
    - grass_any_slot: any of five generated Grass slots;
    - grass_alt_any_slot: any of five generated GrassAlt slots;
    - either_any_slot: any of all ten generated slots.
    """
    key = str(scope or "either_any_slot").strip().casefold()
    aliases = {
        "grass": "grass_primary",
        "grass_primary": "grass_primary",
        "grass_slot_0": "grass_primary",
        "grass_alt": "grass_alt_primary",
        "grassalt": "grass_alt_primary",
        "grass_alt_primary": "grass_alt_primary",
        "grass_alt_slot_0": "grass_alt_primary",
        "either_primary": "either_primary",
        "grass_any": "grass_any_slot",
        "grass_any_slot": "grass_any_slot",
        "grass_alt_any": "grass_alt_any_slot",
        "grass_alt_any_slot": "grass_alt_any_slot",
        "either": "either_any_slot",
        "any": "either_any_slot",
        "either_any": "either_any_slot",
        "either_any_slot": "either_any_slot",
    }
    resolved = aliases.get(key)
    if resolved is None:
        raise ValueError(
            "Grass exact-colour scope must be grass_primary, "
            "grass_alt_primary, either_primary, grass_any_slot, "
            "grass_alt_any_slot, or either_any_slot."
        )
    rows = load_grass_exact_colour_catalog().get("entries", [])
    return tuple(
        dict(row)
        for row in rows
        if bool(row.get(resolved))
    )


def grass_exact_colour_count(scope: str = "either_any_slot") -> int:
    return len(grass_exact_colour_catalog(scope))


def grass_exact_colour_display_values(
    scope: str = "either_any_slot",
) -> tuple[str, ...]:
    return tuple(
        str(row.get("display", "")).strip()
        for row in grass_exact_colour_catalog(scope)
        if str(row.get("display", "")).strip()
    )


def grass_colour_selector_values(
    scope: str = "either_any_slot",
) -> tuple[str, ...]:
    """GUI values: broad family choices followed by every exact RGB choice."""
    broad = tuple(
        f"Family — {family} (broad)"
        for family in GRASS_COLOUR_FILTER_VALUES
    )
    return (*broad, *grass_exact_colour_display_values(scope))


def grass_exact_colour_entry(value: str) -> dict[str, Any] | None:
    """Return catalogue metadata for an exact RGB or display string."""
    text = str(value or "").strip()
    match = re.search(r"(#[0-9A-Fa-f]{6})\s*$", text)
    if match:
        exact_hex = match.group(1).upper()
    elif re.fullmatch(r"#[0-9A-Fa-f]{6}", text):
        exact_hex = text.upper()
    else:
        return None
    for row in load_grass_exact_colour_catalog().get("entries", []):
        if str(row.get("hex", "")).upper() == exact_hex:
            return dict(row)
    return None


def load_atmosphere_colour_engine():
    global _ATMOSPHERE_COLOUR_MODULE
    if _ATMOSPHERE_COLOUR_MODULE is not None:
        return _ATMOSPHERE_COLOUR_MODULE
    if not ATMOSPHERE_COLOUR_ENGINE_PATH.is_file():
        raise FileNotFoundError(ATMOSPHERE_COLOUR_ENGINE_PATH)
    ensure_engine_import_paths()
    spec = importlib.util.spec_from_file_location(
        "fibonacci_apf_core_v1017_atmosphere_v20d2",
        ATMOSPHERE_COLOUR_ENGINE_PATH,
    )
    if spec is None or spec.loader is None:
        raise ImportError(ATMOSPHERE_COLOUR_ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _ATMOSPHERE_COLOUR_MODULE = module
    return module


def load_atmosphere_colour_rule():
    global _ATMOSPHERE_COLOUR_RULE
    if _ATMOSPHERE_COLOUR_RULE is None:
        module = load_atmosphere_colour_engine()
        _ATMOSPHERE_COLOUR_RULE = module.AtmosphereColourRule(
            GRASS_COLOUR_RULE_DATA_PATH,
            NATIVE_SKY_TABLES_PATH,
            NATIVE_SKY_INDEX_REGRESSION_PATH,
        )
    return _ATMOSPHERE_COLOUR_RULE


def day_atmosphere_filter_values() -> tuple[str, ...]:
    return DAY_ATMOSPHERE_FILTER_VALUES


def atmosphere_palette_filter_values() -> tuple[str, ...]:
    return ATMOSPHERE_PALETTE_FILTER_VALUES


def normalize_day_atmosphere_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any atmosphere"}:
        return None
    lookup = {item.casefold(): item for item in DAY_ATMOSPHERE_FILTER_VALUES}
    normalized = lookup.get(text.casefold())
    if normalized is None:
        raise ValueError("Rendered day-sky family must be one of: " + ", ".join(DAY_ATMOSPHERE_FILTER_VALUES))
    return normalized


def normalize_atmosphere_palette_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any colour", "any color"}:
        return None
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", text):
        return text.upper()
    lookup = {item.casefold(): item for item in ATMOSPHERE_PALETTE_FILTER_VALUES}
    normalized = lookup.get(text.casefold())
    if normalized is None:
        raise ValueError(
            "Atmosphere palette colour must be one of: "
            + ", ".join(ATMOSPHERE_PALETTE_FILTER_VALUES)
            + "; or an exact #RRGGBB value."
        )
    return normalized


def atmosphere_palette_matches(row: dict[str, Any], key: str, requested: str | None) -> bool:
    normalized = normalize_atmosphere_palette_filter(requested)
    if normalized is None:
        return True
    if normalized.startswith("#"):
        return normalized in {str(value).upper() for value in row.get(f"atmosphere_{key}_hex_values", [])}
    return normalized.casefold() in {str(value).casefold() for value in row.get(f"atmosphere_{key}_categories", [])}

def generated_water_palette_matches(
    row: dict[str, Any], key: str, requested: str | None
) -> bool:
    normalized = normalize_atmosphere_palette_filter(requested)
    if normalized is None:
        return True
    if not bool(row.get("water_active")):
        return False
    colours = list(row.get(key, []))
    if normalized.startswith("#"):
        return normalized in {str(item.get("hex", "")).upper() for item in colours}
    return normalized.casefold() in {
        str(item.get("colour_family", "")).casefold() for item in colours
    }


def normalize_grass_colour_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any colour", "any color"}:
        return None

    # Exact picker values are displayed as "Descriptive name #RRGGBB".
    exact_match = re.search(r"(#[0-9A-Fa-f]{6})\s*$", text)
    if exact_match:
        return exact_match.group(1).upper()

    # Preserve the older broad-family filters and accept the clearer GUI label.
    family_text = text
    family_match = re.fullmatch(
        r"Family\s*[—–:-]\s*(.+?)(?:\s*\(broad\))?",
        text,
        flags=re.IGNORECASE,
    )
    if family_match:
        family_text = family_match.group(1).strip()
    lookup = {
        item.casefold(): item
        for item in GRASS_COLOUR_FILTER_VALUES
    }
    normalized = lookup.get(family_text.casefold())
    if normalized is None:
        raise ValueError(
            "Generated Grass colour must be a broad family, an exact "
            "catalogue entry ending in #RRGGBB, or an exact #RRGGBB value."
        )
    return normalized


def load_biome_table_intelligence() -> dict[str, Any]:
    global _BIOME_TABLE_INTELLIGENCE_CACHE
    if _BIOME_TABLE_INTELLIGENCE_CACHE is None:
        _BIOME_TABLE_INTELLIGENCE_CACHE = load_json(BIOME_TABLE_INTELLIGENCE_PATH)
    return _BIOME_TABLE_INTELLIGENCE_CACHE


def biome_table_metadata(
    *, raw_biome: int, source_file: str, has_scrap: bool
) -> dict[str, Any]:
    payload = load_biome_table_intelligence()
    source = str(source_file or "").replace("\\", "/").upper()
    entry = dict(payload.get("entries", {}).get(f"{int(raw_biome)}|{source}", {}))
    valid = payload.get("valid_biomes", {})
    catalog_biome = str(entry.get("catalog_biome", ""))
    salvage = bool(has_scrap)
    return {
        "subbiome_catalog_biome": catalog_biome,
        "subbiome_table_option_index": entry.get("option_index"),
        "subbiome_table_subtype_name": entry.get("subtype_name", ""),
        "subbiome_normal_relative_weight": entry.get("normal_relative_weight"),
        "subbiome_purple_relative_weight": entry.get("purple_relative_weight"),
        "subbiome_normal_table_enabled": entry.get("normal_enabled"),
        "subbiome_purple_table_enabled": entry.get("purple_enabled"),
        "subbiome_possible_weather_families": list(entry.get("weather_families", [])),
        "subbiome_weather_by_star": dict(entry.get("weather_by_star", {})),
        "subbiome_main_object_lists": list(entry.get("main_object_lists", [])),
        "subbiome_table_weight_claim": str(payload.get("weight_claim", "")),
        "table_valid_start_biome": catalog_biome in set(valid.get("valid_start_planet_biomes", [])),
        "table_valid_purple_moon_biome": catalog_biome in set(valid.get("valid_purple_moon_biomes", [])),
        "table_valid_giant_biome": catalog_biome in set(valid.get("valid_giant_planet_biomes", [])),
        "lava_body_eligibility_live_validated": not (
            catalog_biome == "Lava" and not bool(valid.get("lava_live_generation_validated"))
        ),
        "salvageable_scrap_available": salvage,
        "salvageable_scrap_prediction_exact": True,
        "salvageable_scrap_object_group": "NEW_SCRAP" if salvage else "",
        "salvageable_scrap_object_list": "PROCSALVAGE" if salvage else "",
        "salvageable_scrap_claim": str(
            payload.get("salvageable_scrap_rule", {}).get("boundary", "")
        ),
    }


def load_biome_variant_catalog() -> dict[str, Any]:
    global _BIOME_VARIANT_CACHE
    if _BIOME_VARIANT_CACHE is None:
        _BIOME_VARIANT_CACHE = load_json(BIOME_VARIANT_PRESENTATION_PATH)
    return _BIOME_VARIANT_CACHE


FLOATING_ISLANDS_TERRAIN_DISPLAY = "Floating Islands (terrain)"


def biome_variant_public_display(value: str) -> str:
    text = str(value or "").strip()
    if text.casefold() in {"floating islands", "floating islands (subbiome)"}:
        return "Floating Islands (subbiome)"
    return text


def biome_variant_filter_values() -> tuple[str, ...]:
    # Biome-source subtypes and terrain families are independent selectors.
    # Only source-file variants belong in this list.
    values: list[str] = []
    for value in load_biome_variant_catalog().get("filter_values", []):
        display = biome_variant_public_display(str(value))
        display = biome_variant_public_display(display)
        if display and display not in values:
            values.append(display)
    return tuple(values)



def biome_variant_prefixed_filter_values(
    search_domain: str | None = None,
) -> tuple[str, ...]:
    """Return every reachable subbiome with its owning biome prefix.

    This is used when no overall biome is selected, so duplicate public names
    such as Standard or Floating Islands remain unambiguous.
    """
    values: list[str] = []
    for biome_number, biome_name in BIOME_NAMES.items():
        if biome_number in {11, 16}:
            continue
        for variant in biome_variant_filter_values_for_biome(
            biome_number, search_domain
        ):
            label = f"{biome_name} — {variant}"
            if label not in values:
                values.append(label)
    return tuple(values)


def split_prefixed_biome_variant(value: str) -> tuple[int | None, str]:
    text = str(value or "").strip()
    if " — " not in text:
        return None, text
    prefix, variant = text.split(" — ", 1)
    try:
        biome_number = normalize_biome_filter(prefix)
    except ValueError:
        return None, text
    return biome_number, variant.strip()

def biome_variant_filter_values_for_biome(
    biome: str | int | None,
    search_domain: str | None = None,
) -> tuple[str, ...]:
    """Return only exact variants reachable under an overall biome/domain."""
    number = normalize_biome_filter(biome)
    if number is None:
        return ()
    rules = load_json(SURFACE_OBJECTLIST_RULE_DATA_PATH)
    lookup = rules.get("source_lookup_numeric", {}).get(str(number), {})
    presentation = load_biome_variant_catalog().get("variants", {})
    values: list[str] = []
    for subtype in sorted(lookup, key=lambda value: int(value)):
        source = str(lookup[subtype] or "")
        # RADIOACTIVEVARIANTBBIOME is retained internally for evidence, but
        # current-build BIOMEFILENAMES weights are zero in both standard and
        # purple domains. It must not be offered as a reachable public filter.
        if source.endswith("RADIOACTIVEVARIANTBBIOME.MBIN"):
            continue
        display = biome_variant_public_display(str(
            presentation.get(source, {}).get("display", "")
        ).strip())
        if display == "Floating Islands (subbiome)" and number in {1, 3, 4, 12}:
            # Current-build special subtype 29 has zero normal-system weight and
            # positive StarType-4 weight for Toxic, Radioactive, Frozen and Swamp.
            # Lush uses the separate subtype-13 HydroGarden -> ROCKBIOME route and
            # is therefore intentionally not restricted here.
            if search_domain is not None:
                try:
                    domain = normalize_finder_search_domain(search_domain)
                except ValueError:
                    domain = FINDER_SEARCH_DOMAIN_PORTAL
                if domain != FINDER_SEARCH_DOMAIN_PURPLE:
                    continue
        if display and display not in values:
            values.append(display)
    # Do not mix the independent terrain-family selector into biome subtypes.
    # Genuine *ISLANDSBIOME source variants remain available under the biome
    # families that actually contain them.
    return tuple(values)


PLANET_BODY_DISPLAY = {
    0: "Planet",
    1: "Planet",
    2: "Planet",
    3: "Moon",
    4: "Giant Planet",
}

NATIVE_PLANET_SIZE_CLASS_DISPLAY = {
    # Exact current-build GcPlanetSize mapping recovered from runtime and
    # reflection data during the V2 campaign.
    0: "Large planet",
    1: "Medium planet",
    2: "Small planet",
    3: "Moon",
    4: "Giant planet",
}

WORLD_SIZE_FILTER_LABELS = (
    "Planet (any size, including giant)",
    "Planet (normal size only)",
    "Large planet",
    "Medium planet",
    "Small planet",
    "Moon",
    "Giant planet",
)
MOON_PARENT_RING_FILTER_VALUES = (
    "Any",
    "Parent must have rings",
    "Parent must not have rings",
)

MOON_PARENT_FILTER_VALUES = (
    "",
    "Any moon (any parent)",
    "Normal planet",
    "Giant planet",
    "Gas giant",
)


def world_size_filter_values() -> tuple[str, ...]:
    return WORLD_SIZE_FILTER_LABELS


def normalize_world_size_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    aliases = {
        # Legacy profiles used Planet for native classes 0–2 only. Preserve
        # that behaviour while making the public label explicit.
        "planet": "Planet (normal size only)",
        "normal planet": "Planet (normal size only)",
        "planet (any size, exclude giant)": "Planet (normal size only)",
        "planet (any native size class)": "Planet (normal size only)",
        "planet (native size class 0)": "Large planet",
        "planet (native size class 1)": "Medium planet",
        "planet (native size class 2)": "Small planet",
        "planet (large)": "Large planet",
        "planet (medium)": "Medium planet",
        "planet (small)": "Small planet",
        "large": "Large planet",
        "medium": "Medium planet",
        "small": "Small planet",
        "planet (any size)": "Planet (any size, including giant)",
        "any planet": "Planet (any size, including giant)",
        "giant": "Giant planet",
        "giant planet": "Giant planet",
    }
    text = aliases.get(text.casefold(), text)
    lookup = {item.casefold(): item for item in WORLD_SIZE_FILTER_LABELS}
    result = lookup.get(text.casefold())
    if result is None:
        raise ValueError("Planet/moon type must be one of: " + ", ".join(WORLD_SIZE_FILTER_LABELS))
    return result


def world_size_filter_matches(row: dict[str, Any], value: str | None) -> bool:
    normalized = normalize_world_size_filter(value)
    if normalized is None:
        return True
    size = int(row.get("planet_size", -1))
    expected = {
        "Planet (any size, including giant)": {0, 1, 2, 4},
        "Planet (normal size only)": {0, 1, 2},
        "Large planet": {0},
        "Medium planet": {1},
        "Small planet": {2},
        "Moon": {3},
        "Giant planet": {4},
    }[normalized]
    return size in expected

def normalize_native_size_class_filter(value: int | str | None) -> int | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip()
    match = re.fullmatch(r"(?:Native size class\s*)?([0-4])", text, re.I)
    if not match:
        raise ValueError("Exact native size class must be 0, 1, 2, 3 or 4.")
    return int(match.group(1))


def normalize_moon_parent_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    aliases = {
        "any moon parent": "Any moon (any parent)",
        "any parent": "Any moon (any parent)",
        "any moon": "Any moon (any parent)",
    }
    text = aliases.get(text.casefold(), text)
    lookup = {item.casefold(): item for item in MOON_PARENT_FILTER_VALUES[1:]}
    result = lookup.get(text.casefold())
    if result is None:
        raise ValueError(
            "Moon parent body must be Any moon (any parent), Normal planet, "
            "Giant planet or Gas giant."
        )
    return result


def moon_parent_filter_values() -> tuple[str, ...]:
    return MOON_PARENT_FILTER_VALUES


def normalize_moon_parent_ring_filter(value: str | bool | None) -> bool | None:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip()
    if not text or text.casefold() in {"any", "any parent rings"}:
        return None
    if text.casefold() in {"parent must have rings", "has rings", "ringed parent", "yes"}:
        return True
    if text.casefold() in {"parent must not have rings", "no rings", "unringed parent", "no"}:
        return False
    raise ValueError("Parent rings must be Any, Parent must have rings, or Parent must not have rings.")


def moon_parent_ring_filter_values() -> tuple[str, ...]:
    return MOON_PARENT_RING_FILTER_VALUES




MOON_COUNT_FILTER_VALUES = (
    "",
    "At least 1 moon",
    "No moons",
    "1 moon",
    "2 moons",
    "3 moons (giant only)",
    "4 moons (giant only)",
    "5 moons (giant only)",
)
OCEAN_TYPE_FILTER_VALUES = (
    "",
    "No ocean",
    "Ocean (any depth)",
    "Regular ocean",
    "Deep ocean (450u)",
    "Waterworld biome (1,500u)",
)


def moon_count_filter_values() -> tuple[str, ...]:
    return MOON_COUNT_FILTER_VALUES


def normalize_moon_count_filter(value: str | int | None) -> int | str | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip().casefold()
    if text in {"at least 1 moon", "at least one moon", "1+", ">=1", "any moons"}:
        return "at_least_1"
    if text in {"no moons", "0", "0 moons"}:
        return 0
    text = re.sub(r"\s*\(giant only\)\s*$", "", text)
    match = re.fullmatch(r"([1-5])(?:\s*moons?)?", text)
    if not match:
        raise ValueError(
            "Moon count must be At least 1 moon, No moons, or an exact count from 1 to 5."
        )
    return int(match.group(1))

def ocean_type_filter_values() -> tuple[str, ...]:
    return OCEAN_TYPE_FILTER_VALUES


def normalize_ocean_type_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text or text.casefold() == "any":
        return None
    aliases = {
        "water present": "Ocean (any depth)",
        "must include": "Ocean (any depth)",
        "must exclude": "No ocean",
        "regular ocean": "Regular ocean",
        "deep ocean": "Deep ocean (450u)",
        "waterworld": "Waterworld biome (1,500u)",
    }
    text = aliases.get(text.casefold(), text)
    lookup = {item.casefold(): item for item in OCEAN_TYPE_FILTER_VALUES if item}
    result = lookup.get(text.casefold())
    if result is None:
        raise ValueError("Ocean type must be one of: " + ", ".join(item for item in OCEAN_TYPE_FILTER_VALUES if item))
    return result


def body_cannot_have_ocean(row: dict[str, Any]) -> bool:
    # Legacy/non-purple moons do not receive oceans. Purple-system moons can,
    # so they must still satisfy the selected ocean rule. Giant planets are
    # not treated as impossible: only the separate Gas Giant biome is.
    size = int(row.get("planet_size", -1))
    star_type = int(row.get("star_type", row.get("star", -1)))
    effective_biome = int(
        row.get("effective_biome", row.get("biome", -1))
    )
    nonpurple_moon = size == 3 and star_type != 4
    oceanless_biome = effective_biome in {6, 7, 15}
    return nonpurple_moon or oceanless_biome


def ocean_type_filter_matches(
    row: dict[str, Any],
    value: str | None,
    *,
    allow_impossible: bool = False,
) -> bool:
    normalized = normalize_ocean_type_filter(value)
    if normalized is None:
        return True
    if allow_impossible and body_cannot_have_ocean(row):
        return True
    water = bool(row.get("water_active"))
    sea_level = float(row.get("sea_level", 0.0) or 0.0)
    if normalized == "No ocean":
        return not water
    if normalized == "Ocean (any depth)":
        return water
    if normalized == "Regular ocean":
        return water and any(abs(sea_level - value) < 0.01 for value in (10.0, 35.0, 120.0))
    if normalized == "Deep ocean (450u)":
        return water and abs(sea_level - 450.0) < 0.01
    if normalized == "Waterworld biome (1,500u)":
        return water and int(row.get("effective_biome", row.get("biome", -1))) == 14 and abs(sea_level - 1500.0) < 0.01
    return False


def validate_filter_compatibility(
    *, search_domain: str, biome: int | None, star_colour: str | None,
    world_size: str | None, native_size_class: int | None,
    moon_parent: str | None, moon_count: str | int | None,
    in_empty_system: bool | None, in_abandoned_system: bool | None,
    in_gas_giant_system: bool | None = None,
    ringed: bool | None = None,
) -> None:
    domain = normalize_finder_search_domain(search_domain)
    body = normalize_world_size_filter(world_size)
    size_class = normalize_native_size_class_filter(native_size_class)
    parent = normalize_moon_parent_filter(moon_parent)
    count = normalize_moon_count_filter(moon_count)
    moon_or_giant = body in {"Moon", "Giant planet"} or size_class in {3, 4}
    if domain == FINDER_SEARCH_DOMAIN_PORTAL and (
        body == "Giant planet" or size_class == 4
    ):
        raise ValueError(
            "Impossible filter combination: Giant planets are available only "
            "in the mapped Purple portal-system domain."
        )
    if domain == FINDER_SEARCH_DOMAIN_PURPLE and ringed is True:
        raise ValueError(
            "Impossible filter combination: rendered planetary rings are not "
            "generated in the validated Purple portal-system domain."
        )
    if int(biome) == 14 if biome is not None else False:
        if moon_or_giant:
            raise ValueError("Impossible filter combination: Waterworlds cannot be moons or giant planets.")
    if domain == FINDER_SEARCH_DOMAIN_PURPLE and biome == 13 and moon_or_giant:
        raise ValueError("Impossible filter combination: purple-system moons and giant planets cannot be volcanic.")
    colour = str(star_colour or "").strip().casefold()
    if colour == "yellow" and in_empty_system is True:
        raise ValueError("Impossible filter combination: yellow systems cannot be uncharted.")
    if colour == "yellow" and in_abandoned_system is True:
        raise ValueError("Impossible filter combination: yellow systems cannot be abandoned.")
    if colour == "red" and in_abandoned_system is True:
        raise ValueError("Impossible filter combination: red systems cannot be abandoned.")
    if parent is not None and body not in {None, "Moon"}:
        raise ValueError("A Moon parent body filter can only be combined with Moon body type.")
    if parent is not None and size_class not in {None, 3}:
        raise ValueError("A Moon parent body filter can only use native Moon class 3.")

    positive_count = count == "at_least_1" or (isinstance(count, int) and count > 0)
    if count is not None and (body == "Moon" or size_class == 3):
        raise ValueError("Moon-count filtering is disabled for Moon bodies because moons cannot own moons.")
    if positive_count and (body in {"Medium planet", "Small planet"} or size_class in {1, 2}):
        raise ValueError("Medium and Small planets cannot own moons. Choose No moons or clear the Moon count filter.")
    if isinstance(count, int) and count > 2 and (
        body in {"Large planet", "Planet (normal size only)"}
        or size_class == 0
    ):
        raise ValueError("Normal-size planets can have at most 2 moons, and only Large planets can own them.")
    if isinstance(count, int) and count not in {5} and (
        (body == "Giant planet" or size_class == 4)
        and (biome == 15 or in_gas_giant_system is True)
    ):
        raise ValueError("A gas giant has exactly 5 generated moons in the current layout.")

def terrain_record_filter_values() -> tuple[str, ...]:
    # Diagnostic-only identities for the 98 biome/subtype terrain-control
    # records recovered by V4R. These are NOT the 31 named terrain settings in
    # VOXELGENERATORSETTINGS.MBIN and are intentionally not exposed as the
    # normal Terrain type filter.
    return tuple(f"Internal control record {index}" for index in range(98))


def load_terrain_setting_catalog() -> dict[str, Any]:
    return load_json(TERRAIN_SETTING_CATALOG_PATH)


def load_terrain_selector_rule() -> dict[str, Any]:
    global _TERRAIN_SELECTOR_RULE_CACHE
    if _TERRAIN_SELECTOR_RULE_CACHE is None:
        _TERRAIN_SELECTOR_RULE_CACHE = load_json(TERRAIN_SELECTOR_RULE_PATH)
    return _TERRAIN_SELECTOR_RULE_CACHE


def terrain_setting_names() -> tuple[str, ...]:
    return tuple(
        str(row["name"])
        for row in load_terrain_setting_catalog().get("settings", [])
    )


def terrain_family_filter_values() -> tuple[str, ...]:
    return tuple(
        str(row["display"])
        for row in load_terrain_selector_rule().get("terrain_families", [])
    )


def normalize_terrain_setting_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    rule = load_terrain_selector_rule()
    aliases: dict[str, str] = {}
    for row in rule.get("terrain_families", []):
        display = str(row["display"])
        aliases[display.casefold()] = display
        for key in ("standard", "prime", "purple"):
            aliases[str(row[key]).casefold()] = display
        if int(row.get("local_index", -1)) == 0:
            aliases["floating islands"] = display
            aliases["floating islands terrain"] = display
            aliases["floating islands (terrain)"] = display
    normalized = aliases.get(text.casefold())
    if normalized is None:
        raise ValueError(
            "Terrain type must be one of: "
            + ", ".join(terrain_family_filter_values())
        )
    return normalized


def predict_terrain_setting(row: dict[str, Any]) -> dict[str, Any]:
    seed_text = str(
        row.get("planet_seed_hex") or row.get("root_seed_hex") or ""
    ).strip()
    if not seed_text:
        raise KeyError("planet_seed_hex")
    root_seed = int(seed_text, 0)
    selector_word = stream_words(root_seed, 5, 1)[0]
    local_index = select_mulhi(selector_word, 10)
    families = {
        int(item["local_index"]): dict(item)
        for item in load_terrain_selector_rule().get("terrain_families", [])
    }
    family = families[local_index]
    star_type = int(row.get("star_type", -1))
    purple = star_type == 4
    if purple:
        setting_index = 21 + local_index
        setting_group = "Purple"
        setting_name = str(family["purple"])
        setting_candidates = [setting_name]
        full_setting_exact = True
    else:
        setting_index = None
        setting_group = "Standard or Prime"
        setting_name = ""
        setting_candidates = [
            str(family["standard"]), str(family["prime"])
        ]
        full_setting_exact = False
    return {
        "terrain_family_index": int(local_index),
        "terrain_setting_local_index": int(local_index),
        "terrain_family_display": str(family["display"]),
        "terrain_setting_prediction_available": True,
        "terrain_family_prediction_exact": True,
        "terrain_selector_child": 5,
        "terrain_selector_draw_number": 1,
        "terrain_selector_word": int(selector_word),
        "terrain_selector_method": "multiply_high_10",
        "terrain_selector_status": (
            "exact_child_05_direct_draw_1_mulhi_10_v20h20_"
            "23_planets_4_systems_unique_candidate"
        ),
        "terrain_setting_index": setting_index,
        "terrain_setting_group": setting_group,
        "terrain_setting_group_exact": purple,
        "terrain_setting_name": setting_name,
        "terrain_setting_name_candidates": setting_candidates,
        "terrain_setting_exact": full_setting_exact,
        "terrain_setting_display": (
            setting_name if full_setting_exact
            else f"{family['display']} (Standard/Prime generation set)"
        ),
        "terrain_setting_is_floating_islands": local_index == 0,
        "terrain_setting_claim": (
            "The 10-way terrain family selector is exact. Purple systems also "
            "have an exact full setting name. The non-purple Standard-versus-"
            "Prime generation-set selector remains unmapped, but both sets use "
            "the same local terrain family. Terrain families are independent of "
            "biome and biome-source subtype; all ten terrain-family filters remain exact."
        ),
    }


def run_terrain_setting_selector_regression_v20h20() -> dict[str, Any]:
    rule = load_terrain_selector_rule()
    checks: dict[str, bool] = {}
    observed: list[dict[str, Any]] = []
    for index, sample in enumerate(
        rule.get("evidence", {}).get("embedded_rows", []), start=1
    ):
        seed = int(str(sample["planet_seed_hex"]), 0)
        actual_local = select_mulhi(stream_words(seed, 5, 1)[0], 10)
        expected_local = int(sample["terrain_local_index"])
        checks[f"sample_{index:02d}_local"] = actual_local == expected_local
        star_type = int(sample.get("star_type", -1))
        if star_type == 4:
            checks[f"sample_{index:02d}_purple_index"] = (
                21 + actual_local == int(sample["terrain_setting_index"])
            )
        observed.append({
            "system": sample["system"],
            "slot": sample["slot"],
            "planet_seed_hex": sample["planet_seed_hex"],
            "expected_local_index": expected_local,
            "actual_local_index": actual_local,
        })
    exact = bool(checks) and all(checks.values())
    return {
        "version": VERSION,
        "status": (
            "PASS_TERRAIN_SETTING_SELECTOR_V20H20"
            if exact else "ERROR_TERRAIN_SETTING_SELECTOR_V20H20"
        ),
        "exact": exact,
        "checks": checks,
        "correct": sum(checks.values()),
        "total": len(checks),
        "observed": observed,
        "campaign_reported_unique_systems": int(
            rule.get("evidence", {}).get("campaign_reported_unique_systems", 0)
        ),
        "campaign_reported_unique_planet_samples": int(
            rule.get("evidence", {}).get("campaign_reported_unique_planet_samples", 0)
        ),
    }


def normalize_terrain_record_filter(value: str | int | None) -> int | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, int):
        number = value
    else:
        text = str(value).strip()
        match = re.fullmatch(r"(?:Internal\s+control\s+record\s+)?(\d+)", text, re.I)
        if not match:
            raise ValueError("Internal terrain-control record must be 0-97.")
        number = int(match.group(1))
    if not 0 <= number <= 97:
        raise ValueError("Internal terrain-control record must be 0-97.")
    return number


def normalize_biome_variant_filter(value: str | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    _, unprefixed = split_prefixed_biome_variant(text)
    lookup = {
        str(item).casefold(): str(item)
        for item in biome_variant_filter_values()
    }
    normalized = lookup.get(unprefixed.casefold())
    if normalized is None:
        raise ValueError(
            "Subbiome must be one of: "
            + ", ".join(biome_variant_filter_values())
        )
    # Preserve a valid biome prefix so rows from different biome families do
    # not collide when an overall biome was intentionally left blank.
    prefix_biome, _ = split_prefixed_biome_variant(text)
    if prefix_biome is not None:
        return f"{BIOME_NAMES[prefix_biome]} — {normalized}"
    return normalized

def normalize_biome_variant_list_filter(
    value: str | list[str] | tuple[str, ...] | set[str] | None,
) -> tuple[str, ...]:
    """Normalize a delimiter-separated or iterable biome-variant list."""
    if value is None:
        return ()
    if isinstance(value, str):
        raw_items = re.split(r"[|,;\n]+", value)
    else:
        raw_items = [str(item) for item in value]

    normalized: list[str] = []
    unknown: list[str] = []
    for raw in raw_items:
        text = str(raw).strip()
        if not text:
            continue
        try:
            canonical = normalize_biome_variant_filter(text)
        except ValueError:
            unknown.append(text)
            continue
        if canonical and canonical not in normalized:
            normalized.append(canonical)
    if unknown:
        raise ValueError(
            "Unknown subbiome list value(s): " + ", ".join(unknown)
        )
    return tuple(normalized)

def functional_weather_filter_values() -> tuple[str, ...]:
    return FUNCTIONAL_STORM_FREQUENCY_VALUES


def passive_hazard_filter_values() -> tuple[str, ...]:
    return PASSIVE_HAZARD_VALUES



def load_current_static_table_reference() -> dict[str, Any]:
    return load_json(CURRENT_STATIC_TABLE_REFERENCE_PATH)


def load_technical_reference() -> dict[str, Any]:
    """Load the structured No Man's Sky procedural-generation domain specification."""
    return load_json(TECHNICAL_REFERENCE_PATH)


def technical_reference_export_files() -> tuple[Path, ...]:
    """Return the packaged procedural-generation specification bundle."""
    return tuple(TECHNICAL_REFERENCE_EXPORT_FILES)


def current_static_table_summary() -> dict[str, Any]:
    payload = load_current_static_table_reference()
    return {
        "weather_hazards": int(payload.get("counts", {}).get("weather_hazards", 0)),
        "gas_giant_atmospheres": int(payload.get("counts", {}).get("gas_giant_atmospheres", 0)),
        "water_colour_settings": int(payload.get("counts", {}).get("water_colour_settings", 0)),
        "claim_boundary": dict(payload.get("claim_boundary", {})),
    }

def load_colour_family_swatch_guide() -> dict[str, Any]:
    global _COLOUR_FAMILY_GUIDE_CACHE
    if _COLOUR_FAMILY_GUIDE_CACHE is None:
        _COLOUR_FAMILY_GUIDE_CACHE = load_json(COLOUR_FAMILY_SWATCH_GUIDE_PATH)
    return dict(_COLOUR_FAMILY_GUIDE_CACHE)


def colour_family_swatch_guide(kind: str) -> dict[str, list[str]]:
    key = str(kind or "").strip().casefold()
    aliases = {
        "grass": "grass", "grassalt": "grass", "surface": "grass",
        "atmosphere": "atmosphere", "sky": "atmosphere", "day": "atmosphere",
    }
    resolved = aliases.get(key)
    if resolved is None:
        raise ValueError("Colour guide kind must be grass or atmosphere.")
    data = load_colour_family_swatch_guide().get(resolved, {})
    return {str(name): [str(h).upper() for h in values] for name, values in data.items()}


def functional_weather_metadata(row: dict[str, Any]) -> dict[str, Any]:
    biome = int(row.get("biome", -1))
    active = int(row.get("weather_active", 0))
    mode = int(row.get("weather_mode", 0))

    # In-game weather names for Waterworld and red/green/blue/exotic worlds
    # are not reliable descriptions of function. The generated active/mode
    # fields are the exact functional storm state and were live-validated
    # across the comprehensive V20H23 mapping campaign. Gas giants remain a
    # fixed special environment rather than an ordinary storm-frequency row.
    if biome == 15:
        frequency = "Gas-giant fixed weather"
        frequency_exact = True
    elif active != 0:
        frequency = "Extreme storms"
        frequency_exact = True
    elif mode == 2:
        frequency = "Frequent storms"
        frequency_exact = True
    elif mode == 1:
        frequency = "Occasional storms"
        frequency_exact = True
    else:
        frequency = "No storms"
        frequency_exact = True

    passive_candidates: list[str]
    passive_exact = True
    passive_boundary = "exact biome-linked passive condition"
    weather_index = int(row.get("weather_index", -1))
    # Waterworlds inherit their passive condition from the weather type selected
    # for that planet. The selected weather index is already exact.
    weather_index_passive = {
        0: "Life-support drain",  # Dead weather
        1: "Nightly cold",       # Barren / Dust weather
        2: "None",               # Lush weather
        3: "Cold",               # Frozen weather
        4: "Toxicity",           # Toxic weather
        5: "Heat",               # Scorched weather
        6: "Radiation",          # Radioactive weather
        11: "Heat",              # Lava weather
        14: "Heat",              # Scorched override
        15: "Life-support drain",# Dead override
    }
    if biome == 14 and weather_index in weather_index_passive:
        passive = weather_index_passive[weather_index]
        passive_candidates = [passive]
        passive_boundary = "exact Waterworld assigned-weather passive condition"
    elif biome == 5 and weather_index in {1, 5, 14}:
        passive = "Nightly cold" if weather_index == 1 else "Heat"
        passive_candidates = [passive]
        passive_boundary = "exact Barren selected-weather passive condition"
    elif biome == 5:
        passive = "Barren heat / nightly cold unresolved"
        passive_candidates = ["Heat", "Nightly cold"]
        passive_exact = False
        passive_boundary = (
            "Barren branch can be Heat or Nightly cold; selected weather type unavailable"
        )
    else:
        passive = {
            0: "None",
            1: "Toxicity",
            2: "Heat",
            3: "Radiation",
            4: "Cold",
            6: "Life-support drain",
            12: "Variable / special",
            13: "Heat",
            14: "Variable / special",
            15: "Variable / special",
        }.get(biome, "Variable / special")
        passive_candidates = [passive]

    if passive == "None":
        passive_text = "no passive hazard"
    elif passive_exact:
        passive_text = f"passive {passive.casefold()}"
    else:
        passive_text = "passive heat or nightly cold (Barren selector unresolved)"

    weather_source_names = {
        0: "Dead / life-support weather source",
        1: "Barren / dust weather source",
        2: "Lush weather source",
        3: "Frozen weather source",
        4: "Toxic weather source",
        5: "Scorched / heat weather source",
        6: "Radioactive weather source",
        11: "Lava weather source",
        14: "Scorched override weather source",
        15: "Dead override weather source",
    }
    weather_source = weather_source_names.get(
        weather_index, f"Native weather source {weather_index}"
    )
    if biome == 5 and weather_index in {5, 14}:
        weather_source = "Barren planet using a Scorched weather source"
    elif biome == 5 and weather_index == 1:
        weather_source = "Barren planet using its Barren / dust weather source"
    standard_possible = bool(STANDARD_PASSIVE_HAZARDS.intersection(passive_candidates))
    return {
        "weather_source_display": weather_source,
        "weather_source_index": weather_index,
        "weather_source_exact": True,
        "weather_storm_frequency": frequency,
        "weather_functional_display": f"{frequency}; {passive_text}",
        "weather_functional_exact": bool(frequency_exact and passive_exact),
        "weather_storm_frequency_exact": frequency_exact,
        "weather_passive_hazard": passive,
        "weather_passive_hazard_candidates": passive_candidates,
        "weather_passive_hazard_exact": passive_exact,
        "weather_passive_hazard_boundary": passive_boundary,
        "weather_has_standard_passive_hazard": standard_possible,
        "weather_has_storms": frequency in {
            "Occasional storms", "Frequent storms", "Extreme storms"
        },
        "weather_is_extreme_hazard": frequency == "Extreme storms",
        "weather_is_frequent_non_extreme": frequency == "Frequent storms",
        "weather_is_stormless": frequency == "No storms",
        "weather_functional_rule": (
            "weather_active => extreme; otherwise mode 2 => frequent, "
            "mode 1 => occasional, mode 0 => none; Waterworld and Barren "
            "passive conditions follow the exact selected weather type"
        ),
    }


def effective_biome_from_source(raw_biome: int, source_file: str) -> tuple[int, str, str]:
    """Return the gameplay-facing biome after exact source-file conversions.

    Some generated Lush/Scorched rows are replaced by dedicated Swamp/Lava
    biome files. Filtering and public presentation must follow the exact source
    file rather than the pre-conversion numeric family.
    """
    source_upper = str(source_file or "").replace("\\", "/").upper()
    if "/BIOMES/SWAMP/" in source_upper:
        return 12, BIOME_NAMES.get(12, "Swamp / Marsh"), "source_file_swamp_conversion"
    if "/BIOMES/LAVA/" in source_upper:
        return 13, BIOME_NAMES.get(13, "Lava / Volcanic"), "source_file_lava_conversion"
    if (
        int(raw_biome) == 6
        and source_upper.endswith("/BIOMES/DEAD/DEADFROZENWEIRDBIOME.MBIN")
    ):
        # Static table and generated-token audit: despite the historical
        # "WEIRD" substring, this remains a Dead-family body.  Its native
        # description/weather selectors are DEAD / clear-cold, not the Weird
        # exotic family.  Only the source-variant presentation is Frozen Weird.
        return 6, BIOME_NAMES[6], "dead_frozen_weird_variant_retains_dead_family"
    return int(raw_biome), BIOME_NAMES.get(int(raw_biome), "Unknown"), "no_source_conversion"


def apply_effective_biome_weather_family(
    output: dict[str, Any],
    *,
    effective_biome: int,
    conversion_status: str,
) -> dict[str, Any]:
    """Harden display naming after a source-file biome conversion.

    Actual Swamp-family planets retain Swamp weather names.  A generated Lush
    world that uses a Swamp source file must retain the Lush weather-name
    family shown in game; its raw generation/source family remains available
    in the dedicated audit fields added during enrichment.
    """
    if not (
        int(effective_biome) == 12
        and str(conversion_status) == "source_file_swamp_conversion"
    ):
        return {}

    generated_biome = int(output.get("generated_biome", output.get("biome", -1)))
    if generated_biome == 0:
        family = lush_display_weather_family(
            output.get("weather_family")
            or output.get("weather_generation_family")
        )
        word = int(output.get("selector_child_22_draw_2_weather", 0))
        suffix = int(select_mulhi(word, 10)) + 1
        return {
            "weather_source_biome_family": "Swamp / Marsh",
            "weather_source_biome_conversion_status": str(conversion_status),
            "weather_display_name_family": family,
            "weather_family": family,
            "weather_family_friendly": weather_friendly(family),
            "weather_family_coverage": (
                "grouch_live_lush_world_swamp_source_uses_lush_names_v1061_r2"
            ),
            "weather_token": f"{family}{suffix}",
            "weather_token_suffix": suffix,
            "weather_token_coverage": (
                "exact_child22_draw2_lush_display_family_v1061_r2"
            ),
            "weather_discovery_display_override": "",
            "weather_discovery_display_override_exact": False,
            "weather_discovery_display_override_source": (
                "Lush display-name family resolved by exact terminology catalog"
            ),
        }

    if bool(output.get("weather_clear_family")):
        family = "WEATHER_SWAMP_CLEAR"
    elif bool(output.get("weather_extreme_family")):
        family = "WEATHER_SWAMP_EXTREME"
    else:
        family = "WEATHER_SWAMP"

    word = int(output.get("selector_child_22_draw_2_weather", 0))
    suffix = int(select_mulhi(word, 10)) + 1
    display = SWAMP_WEATHER_DISCOVERY_DISPLAY[family][suffix - 1]
    return {
        "weather_generation_family": str(
            output.get("weather_generation_family", family)
        ),
        "weather_display_name_family": family,
        "weather_family": family,
        "weather_family_friendly": weather_friendly(family),
        "weather_family_coverage": (
            "effective_swamp_family_child22_draw2_live_validated_v20i1"
        ),
        "weather_token": f"{family}{suffix}",
        "weather_token_suffix": suffix,
        "weather_token_coverage": (
            "effective_swamp_family_child22_draw2_live_validated_v20i1"
        ),
        "weather_discovery_display_override": display,
        "weather_discovery_display_override_exact": True,
        "weather_discovery_display_override_source": (
            "current-game Swamp weather family and live 61F0239D6F69 control"
        ),
    }


def exact_sentinel_discovery_metadata(
    output: dict[str, Any],
    *,
    sentinel_is_low: bool,
) -> dict[str, Any]:
    """Return the exact scanner/Discovery-page Sentinel wording when solved."""
    if not sentinel_is_low:
        return {
            "sentinel_discovery_display": str(
                output.get("sentinel_standard_activity_display", "Unknown")
            ),
            "sentinel_discovery_exact": False,
            "sentinel_discovery_status": (
                "exact_low_activity_family_only_nonlow_category_display"
            ),
        }
    seed_text = str(
        output.get("planet_seed_hex", output.get("root_seed_hex", ""))
    )
    if not seed_text:
        return {
            "sentinel_discovery_display": "Low Sentinel Activity",
            "sentinel_discovery_exact": False,
            "sentinel_discovery_status": "missing_planet_seed",
        }
    root_seed = int(seed_text, 0)
    word = int(stream_words(root_seed, 22, 6)[5])
    suffix = int(select_mulhi(word, 12)) + 1
    return {
        "sentinel_discovery_display": SENTINEL_RARE_DISCOVERY_DISPLAY[suffix],
        "sentinel_discovery_token": f"SENTINEL_RARE{suffix}",
        "sentinel_discovery_suffix": suffix,
        "sentinel_discovery_selector_child_22_draw_6": word,
        "sentinel_discovery_exact": True,
        "sentinel_discovery_status": (
            "exact_child22_draw6_mulhi12_current_localisation_v20i1"
        ),
    }


def apply_hardened_discovery_presentation(row: dict[str, Any]) -> dict[str, Any]:
    """Apply verified final-screen wording without changing internal tokens."""
    output = dict(row)
    weather_override = str(
        output.get("weather_discovery_display_override", "")
    ).strip()
    if not weather_override:
        weather_override = WEATHER_DISCOVERY_DISPLAY_OVERRIDES.get(
            str(output.get("weather_token", "")), ""
        )
    if weather_override:
        output.update({
            "weather_display": weather_override,
            "weather_display_exact": True,
            "weather_display_resolution": (
                "live_verified_discovery_page_hardening_v20i1"
            ),
            "weather_display_token": str(output.get("weather_token", "")),
        })
    output["weather_severity_display"] = (
        "Extreme" if bool(output.get("is_weather_extreme")) else "Normal"
    )
    output["weather_severity_exact"] = True
    return output


TERRAIN_VISUAL_DESCRIPTIONS = {
    "Floating Islands (terrain)": (
        "Suspended terrain masses; independent from biome and biome-source subtype."
    ),
    "Lily Pad": (
        "Exact internal preset. Live controls showed very large ring/toroidal "
        "landforms; local appearance can vary."
    ),
    "Alien": (
        "Exact internal preset. Live controls showed elevated slabs, blunt "
        "overhangs and unusually artificial silhouettes."
    ),
    "Craters": (
        "Exact internal preset. Broad crater basins are live-confirmed; other "
        "large landforms can occur in the same preset."
    ),
    "Huge Arches": (
        "Exact internal terrain preset. A live control showed narrow raised ridges, "
        "trenches and elevated mountainous formations; literal giant arches are not guaranteed."
    ),
    "Mountain Ravines": (
        "Exact internal terrain preset; water coverage and local land visibility "
        "are independent."
    ),
    "Alpine": (
        "Exact internal terrain preset; it does not imply a dry or uniformly "
        "mountainous landing region."
    ),
    "Caverns": (
        "Exact internal terrain preset associated with extensive cave/cavern "
        "generation; surface appearance still varies."
    ),
}


def visual_filter_metadata(
    output: dict[str, Any],
    *,
    source_file: str,
    effective_biome: int,
) -> dict[str, Any]:
    """Expose only visual filters that are tied to an exact source variant."""
    source_upper = str(source_file or "").replace("\\", "/").upper()
    if "MSTRUCTBIOME.MBIN" in source_upper:
        return {
            "visual_filter_display": (
                "Monochrome / selective-colour exotic filter"
            ),
            "visual_filter_status": (
                "exact_source_variant_live_confirmed_51F0239D6F69"
            ),
            "visual_filter_exact": True,
            "palette_input_visibility_warning": (
                "This strong planet-wide filter desaturates much of the scene "
                "while preserving selected emissive/highlight colours. Generated "
                "grass and atmosphere palette inputs may not resemble the final "
                "rendered scene."
            ),
        }
    if int(effective_biome) == 7:
        return {
            "visual_filter_display": "No exact filter mapped for this exotic source",
            "visual_filter_status": "exotic_source_filter_not_yet_mapped",
            "visual_filter_exact": False,
            "palette_input_visibility_warning": (
                "Weird/Exotic rendering can override or heavily transform native "
                "grass and atmosphere palette inputs."
            ),
        }
    return {
        "visual_filter_display": "No dedicated planet-wide filter identified",
        "visual_filter_status": "none_identified_for_source",
        "visual_filter_exact": False,
        "palette_input_visibility_warning": (
            "Weather, time of day, exposure and renderer colour grading can still "
            "change the final visible colours."
        ),
    }


def apply_biome_weather_paradise_metadata(
    row: dict[str, Any],
    *,
    family_catalog: dict[str, Any],
) -> dict[str, Any]:
    output = dict(row)
    catalog = load_biome_variant_catalog()
    source = str(output.get("surface_biome_source_file", ""))
    variant = dict(catalog.get("variants", {}).get(source, {}))
    subtype = int(output.get("biome_subtype", -1))
    subtype_name = str(
        catalog.get("subtype_names", {}).get(str(subtype), "Unknown")
    )
    terrain = predict_terrain_setting(output)
    source_has_floating_islands = bool(variant.get("has_floating_islands"))
    raw_variant_display = str(variant.get("display", "Unmapped"))
    public_variant_display = biome_variant_public_display(raw_variant_display)
    filter_labels = [public_variant_display, raw_variant_display]
    raw_biome = int(output.get("biome", -1))
    effective_biome, effective_biome_name, conversion_status = effective_biome_from_source(
        raw_biome, source
    )
    filter_labels.extend([
        f"{effective_biome_name} — {public_variant_display}",
        f"{effective_biome_name} — {raw_variant_display}",
    ])
    filter_labels = list(dict.fromkeys(filter_labels))
    output.update(
        apply_effective_biome_weather_family(
            output,
            effective_biome=effective_biome,
            conversion_status=conversion_status,
        )
    )
    output.update({
        "generated_biome": raw_biome,
        "generated_biome_name": str(output.get("biome_name", BIOME_NAMES.get(raw_biome, "Unknown"))),
        "effective_biome": effective_biome,
        "effective_biome_name": effective_biome_name,
        "biome_conversion_status": conversion_status,
        "biome_conversion_applied": effective_biome != raw_biome,
        "biome_public_translation_status": (
            "exact_native_red_green_blue_family_label"
            if raw_biome in {8, 9, 10}
            else (
                "dead_frozen_weird_source_audited_as_dead_family"
                if conversion_status == "dead_frozen_weird_variant_retains_dead_family"
                else "native_or_exact_source_conversion"
            )
        ),
        **terrain,
        "terrain_visual_description": TERRAIN_VISUAL_DESCRIPTIONS.get(
            str(terrain.get("terrain_family_display", "")),
            "Exact internal terrain preset; local visual form can vary.",
        ),
        **visual_filter_metadata(
            output, source_file=source, effective_biome=effective_biome
        ),
        "internal_generated_slot": int(output.get("slot", -1)),
        "biome_subtype_name": subtype_name,
        "biome_subtype_display": f"{subtype} — {subtype_name}",
        "biome_variant_key": variant.get("key", "unmapped"),
        "biome_variant_display": public_variant_display,
        "biome_variant_category": variant.get("category", "Unmapped"),
        "biome_source_stem": variant.get("source_stem", Path(source).stem),
        "biome_variant_is_infested": bool(variant.get("is_infested")),
        "biome_variant_is_ruined": bool(variant.get("is_ruined")),
        "biome_variant_has_floating_islands": source_has_floating_islands,
        "biome_variant_has_floating_island_props": source_has_floating_islands,
        "terrain_family_is_floating_islands": bool(
            terrain.get("terrain_setting_is_floating_islands")
        ),
        "floating_islands_axes_independent": True,
        "biome_variant_filter_labels": filter_labels,
        "biome_source_has_floating_islands": source_has_floating_islands,
        "biome_variant_is_giant": bool(variant.get("is_giant_variant")),
        "biome_variant_mapping_status": (
            "exact_source_file_to_functional_variant_v20h21"
            if variant else "source_file_unmapped"
        ),
        "biome_variant_claim": str(catalog.get("claim", "")),
        "biome_variant_source_exact": bool(variant),
    })
    output.update(
        biome_table_metadata(
            raw_biome=raw_biome,
            source_file=source,
            has_scrap=bool(output.get("has_scrap")),
        )
    )
    output.update(functional_weather_metadata(output))
    output.update({
        # Final rendered-ring metadata is applied once the complete system
        # parent/body structure is available in predict_system().
        "rings_prediction_exact": False,
        "has_rings": None,
        "rings_filter_available": False,
        "rings_display": "Resolving exact rendered-ring selector…",
        "internal_terrain_control_record_index": int(
            output.get("terrain_record_index", -1)
        ),
        "water_colour_display": (
            "Exact generated Water palette and exact selected WATERCOLOURS profile"
        ),
        "water_colour_table_recovered": True,
        "water_colour_table_entry_count": 19,
        "water_colour_all_emission_rgb_zero": False,
        "water_colour_prediction_exact": True,
        "water_colour_filter_available": True,
        "generated_water_palette_filter_available": True,
        "generated_water_palette_exact": bool(output.get("generated_water_palette_exact")),
        "deep_water_biolum_route_separate": True,
        "deep_water_biolum_palette_filter_available": True,
        "deep_water_biolum_palette_exact": bool(output.get("deep_water_biolum_palette_exact")),
        "water_palette_claim": (
            "Native generated Water channel 15 and DeepWaterBioLum channel 63 are exact. "
            "The selected one-of-19 WATERCOLOURS style, murkiness and emission modes are exact; final renderer grading remains separate."
        ),
        "weather_hazard_table_recovered": True,
        "weather_hazard_definition_count": 16,
        "weather_hazard_assignment_exact": False,
        "gas_giant_atmosphere_table_recovered": True,
        "gas_giant_atmosphere_definition_count": 6,
        "gas_giant_atmosphere_assignment_exact": False,
        "gas_giant_exterior_green_blue_swap_known": True,
    })

    planet_type_token = infer_planet_type_token(output)
    is_giant_world = planet_type_token == "DISC_TYPE_GIANT"
    world_type_display = {
        "PLANETCLASS1": "Planet",
        "PLANETCLASS2": "Moon",
        "DISC_TYPE_GIANT": "Giant Planet",
    }.get(planet_type_token, "World")

    sentinel_reference_enum = int(
        output.get("sentinel_difficulty_reference_enum", 99)
    )
    sentinel_reference_name = str(
        output.get("sentinel_difficulty_reference_name", "Unknown")
    )
    legacy_sentinel_level = int(output.get("sentinel_level", -1))
    legacy_low = legacy_sentinel_level in (0, 1)
    native_reference_low = sentinel_reference_enum == 0
    sentinel_is_low = bool(legacy_low or native_reference_low)
    sentinel_functional_display = (
        "Low / Rare"
        if sentinel_is_low
        else {
            1: "Standard / Default",
            2: "Aggressive",
            3: "Corrupt",
        }.get(sentinel_reference_enum, "Unknown")
    )
    sentinel_low_sources = [
        source
        for condition, source in (
            (legacy_low, "legacy generated Sentinel level 0/1"),
            (native_reference_low, "native reference category Rare"),
        )
        if condition
    ]
    sentinel_pattern = [
        int(value) for value in output.get("sentinel_difficulty_enums", [])
    ]
    sentinel_activity_by_difficulty = {
        ON_FOOT_COMBAT_DIFFICULTY_NAMES[index]: (
            SENTINEL_ACTIVITY_DISPLAY_NAMES.get(value, "Unknown")
        )
        for index, value in enumerate(sentinel_pattern[:4])
    }
    sentinel_activity_display_names = [
        SENTINEL_ACTIVITY_DISPLAY_NAMES.get(value, "Unknown")
        for value in sentinel_pattern[:4]
    ]

    output.update({
        "is_giant_world": is_giant_world,
        "world_type_display": PLANET_BODY_DISPLAY.get(
            int(output.get("planet_size", -1)), world_type_display
        ),
        "world_size_display": PLANET_BODY_DISPLAY.get(
            int(output.get("planet_size", -1)), world_type_display
        ),
        "planet_size_index": int(output.get("planet_size", -1)),
        "native_planet_size_class_display": (
            NATIVE_PLANET_SIZE_CLASS_DISPLAY.get(
                int(output.get("planet_size", -1)), "Unknown native size class"
            )
        ),
        "body_type_and_size_display": (
            NATIVE_PLANET_SIZE_CLASS_DISPLAY.get(
                int(output.get("planet_size", -1)), "Unknown world"
            )
        ),
        "visible_planet_size_mapping_status": (
            "unresolved_not_inferred_from_discovery_screen_v20h18"
        ),
        "world_type_token": planet_type_token,
        "world_type_mapping_status": (
            "native_planet_type_token_v20h15"
            if planet_type_token
            else "world_type_unresolved"
        ),
        "sentinel_functional_reference_index": int(
            output.get("sentinel_difficulty_reference_index", 2)
        ),
        "sentinel_functional_reference_enum": sentinel_reference_enum,
        "sentinel_functional_reference_name": sentinel_reference_name,
        "sentinel_functional_activity_display": sentinel_functional_display,
        "sentinel_activity_by_on_foot_combat": sentinel_activity_by_difficulty,
        "sentinel_difficulty_activity_display_names": sentinel_activity_display_names,
        "sentinel_standard_activity_display": (
            sentinel_activity_by_difficulty.get("Standard", "Unknown")
        ),
        "sentinel_functional_is_low": sentinel_is_low,
        "sentinel_functional_rule": (
            "Low activity is accepted when either the exact legacy generated "
            "Sentinel level is 0/1 or the native reference category is Rare."
        ),
        "sentinel_functional_low_sources": sentinel_low_sources,
        "legacy_sentinel_level": legacy_sentinel_level,
        "legacy_sentinel_level_used_for_paradise": legacy_low,
        "native_reference_sentinel_used_for_paradise": native_reference_low,
    })
    output.update(
        exact_sentinel_discovery_metadata(
            output,
            sentinel_is_low=sentinel_is_low,
        )
    )

    if bool(output.get("biome_variant_is_ruined")) and not bool(output.get("biome_variant_is_infested")):
        ruined_biome = int(output.get("effective_biome", output.get("biome", -1)))
        ruined_family = RUINED_DESCRIPTION_FAMILY_BY_BIOME_V20H23.get(
            ruined_biome, "RUINED"
        )
        output["description_family"] = ruined_family
        output["description_family_friendly"] = description_friendly(ruined_family)
        ruined_token = token_prediction(
            ruined_family,
            word=int(output.get("selector_child_22_draw_1_description", 0)),
            catalog=family_catalog,
        )
        output["description_token"] = ruined_token.get("token", "")
        output["description_token_coverage"] = ruined_token.get(
            "coverage", "family_only_count_unknown"
        )
        output["description_family_coverage"] = (
            "exact_native_ruined_family_by_biome_v20h23"
        )
        output["ruined_description_family_native_selector"] = (
            "biome 0/1/2/3/4/5 -> RUINEDLUSH/TOX/HOT/RAD/COLD/DUST; "
            "otherwise RUINED"
        )

    paradise = bool(
        int(output.get("effective_biome", output.get("biome", -1))) == 0
        and output.get("weather_storm_frequency") == "No storms"
        and sentinel_is_low
        and not bool(output.get("infested_planet"))
        and not bool(output.get("biome_variant_is_ruined"))
    )
    output["literal_paradise"] = paradise
    output["paradise_functional_eligibility"] = paradise
    output["paradise_rule"] = (
        "Lush + no storms + low Sentinel evidence "
        "(legacy level 0/1 or native Rare) + not infested/ruined"
    )
    output["paradise_rule_status"] = (
        "live_validated_dual_sentinel_paradise_controls_v20h17"
    )
    output["paradise_exclusion_reasons"] = [
        reason for condition, reason in (
            (int(output.get("effective_biome", output.get("biome", -1))) != 0, "not lush"),
            (
                output.get("weather_storm_frequency") != "No storms",
                "storms present or unknown",
            ),
            (
                not sentinel_is_low,
                "neither legacy Sentinel level 0/1 nor native Rare category",
            ),
            (bool(output.get("infested_planet")), "infested"),
            (
                bool(output.get("biome_variant_is_ruined")),
                "ruined biome variant",
            ),
        ) if condition
    ]

    if paradise:
        output["description_family"] = "UI_PARADISE_PLANET"
        output["description_token"] = "UI_PARADISE_PLANET"
        output["description_family_coverage"] = (
            "functional_paradise_dual_sentinel_rule_v20h17"
        )
    elif str(output.get("description_family", "")) == "UI_PARADISE_PLANET":
        fallback = str(output.get("description_base_family", "")) or str(
            DESCRIPTION_DEFAULT_FAMILY_BY_BIOME_V20B4.get(
                int(output.get("biome", -1)), ""
            )
        )
        output["description_family"] = fallback
        token = token_prediction(
            fallback,
            word=int(output.get("selector_child_22_draw_1_description", 0)),
            catalog=family_catalog,
        )
        output["description_token"] = token.get("token", "")
        output["description_family_coverage"] = (
            "functional_paradise_dual_sentinel_exclusion_v20h17"
        )
    return output


def load_model() -> dict[str, Any]:
    global _MODEL_CACHE
    if _MODEL_CACHE is None:
        model = load_json(MODEL_PATH)
        readiness = model.get("readiness", {})
        if not readiness.get("ready_for_final_independent_validation"):
            raise RuntimeError(
                "The bundled V5I branch model is not marked ready."
            )
        _MODEL_CACHE = model
    return _MODEL_CACHE


def load_family_catalog() -> dict[str, Any]:
    global _FAMILY_CACHE
    if _FAMILY_CACHE is None:
        _FAMILY_CACHE = load_json(FAMILY_CATALOG_PATH)
    return _FAMILY_CACHE


def unique_lookup(section: dict[str, Any]) -> dict[tuple[Any, ...], Any]:
    output: dict[tuple[Any, ...], Any] = {}
    for item in section.get("lookup", []):
        if item.get("unique"):
            output[tuple(item.get("key", []))] = item.get("value")
    return output


def derive_weather_branches(row: dict[str, Any]) -> dict[str, bool]:
    active = int(row["weather_active"])
    mode = int(row["weather_mode"])
    biome = int(row["biome"])

    actual_extreme = bool(active != 0 or mode == 2)
    token_extreme = bool(
        actual_extreme and biome in NORMAL_WEATHER_BIOMES
    )
    token_clear = bool(
        not actual_extreme
        and mode == 0
        and biome in NORMAL_WEATHER_BIOMES
    )
    # Live V4Z controls prove Paradise Planet/Moon can use SentinelLevel 1
    # (Infrequent / Spread Thin). The former == 0 check was too strict and
    # caused valid Paradise worlds to fall back to generic lush names.
    paradise = bool(
        biome == 0
        and token_clear
        and int(row["sentinel_level"]) <= 1
    )
    return {
        "is_weather_extreme": actual_extreme,
        "weather_extreme_family": token_extreme,
        "weather_clear_family": token_clear,
        "literal_paradise": paradise,
    }


def token_prediction(
    family: str | None,
    *,
    word: int,
    catalog: dict[str, Any],
) -> dict[str, Any]:
    family = str(family or "").upper()
    if not family:
        return {
            "family": "",
            "token": "",
            "coverage": "family_unmapped",
            "exact_token_available": False,
            "selector_word": int(word),
        }

    entry = catalog.get("families", {}).get(family)
    if not entry:
        return {
            "family": family,
            "token": "",
            "coverage": "family_only_count_unknown",
            "exact_token_available": False,
            "selector_word": int(word),
        }

    literal = entry.get("literal_token")
    if literal:
        return {
            "family": family,
            "token": str(literal),
            "coverage": "validated_literal_token",
            "exact_token_available": True,
            "selector_word": int(word),
            "family_count": 1,
        }

    count = entry.get("count")
    contiguous = entry.get("contiguous")
    if count is None or contiguous is not True:
        return {
            "family": family,
            "token": "",
            "coverage": "family_only_count_unknown",
            "exact_token_available": False,
            "selector_word": int(word),
            "observed_tokens": entry.get("observed_tokens", []),
        }

    suffix = select_mulhi(word, int(count)) + 1
    return {
        "family": family,
        "token": f"{family}{suffix}",
        "coverage": "validated_child22_mulhi_token",
        "exact_token_available": True,
        "selector_word": int(word),
        "family_count": int(count),
        "suffix": int(suffix),
    }


def description_friendly(family: str | None) -> str:
    family = str(family or "")
    return DESCRIPTION_FRIENDLY.get(
        family,
        family.replace("_", " ").title() if family else "Unknown",
    )


def weather_friendly(family: str | None) -> str:
    family = str(family or "")
    return WEATHER_FRIENDLY.get(
        family,
        family.replace("WEATHER_", "").replace("_", " ").title()
        if family
        else "Unknown",
    )


def lush_display_weather_family(family: str | None) -> str:
    """Return the in-game display-name family for a Lush world.

    Current-game controls supplied by Grouch show that Lush worlds whose
    functional weather source resolves through a Swamp family still use the
    Lush localisation-name family on the Discovery page.  Keep the raw family
    separately for auditability, but present the matching Lush clear/normal/
    extreme family to users.
    """
    value = str(family or "").upper()
    mapping = {
        "WEATHER_SWAMP_CLEAR": "WEATHER_LUSH_CLEAR",
        "WEATHER_SWAMP": "WEATHER_LUSH",
        "WEATHER_SWAMP_EXTREME": "WEATHER_LUSHEXTREME",
    }
    return mapping.get(value, value)


def predict_special_planet_state(
    *,
    star_type: int,
    planet_index: int,
    biome_subtype: int,
) -> dict[str, Any]:
    """Return only the exact V17A/V17F special-planet states."""
    return load_special_planet_engine().predict_special_planet_state(
        star_type=int(star_type),
        planet_index=int(planet_index),
        biome_subtype=int(biome_subtype),
    )


def predict_sentinel_difficulty_state(
    row: dict[str, Any],
    *,
    galaxy_index: int,
) -> dict[str, Any]:
    """Return the exact V18A native per-difficulty Sentinel categories."""
    return load_sentinel_difficulty_engine().predict_native_pattern(
        row,
        galaxy_index=int(galaxy_index),
    )


def enrich_planet_row(
    row: dict[str, Any],
    *,
    model: dict[str, Any] | None = None,
    family_catalog: dict[str, Any] | None = None,
    galaxy_index: int = 0,
) -> dict[str, Any]:
    model = model or load_model()
    family_catalog = family_catalog or load_family_catalog()

    description_lookup = unique_lookup(model["description_base_model"])
    weather_lookup = unique_lookup(model["weather_family_model"])

    branches = derive_weather_branches(row)
    biome = int(row["biome"])
    subtype = int(row["biome_subtype"])
    weather_index = int(row["weather_index"])
    planet_index = int(row["slot"])
    special_planet_state = predict_special_planet_state(
        star_type=int(row["star_type"]),
        planet_index=planet_index,
        biome_subtype=subtype,
    )
    sentinel_difficulty_state = predict_sentinel_difficulty_state(
        row,
        galaxy_index=int(galaxy_index),
    )
    legacy_direct_corrupt = bool(
        special_planet_state.get("dissonant_planet")
    )
    reference_difficulty_index = int(
        sentinel_difficulty_state.get(
            "sentinel_difficulty_reference_index",
            2,
        )
    )
    reference_difficulty_enum = int(
        sentinel_difficulty_state.get(
            "sentinel_difficulty_reference_enum",
            -1,
        )
    )
    portal_safe_dissonant = reference_difficulty_enum == 3
    portal_safe_dissonance_state = {
        "portal_safe_dissonant_planet": portal_safe_dissonant,
        "portal_safe_dissonant_rule": (
            "SentinelDifficulty[reference index "
            f"{reference_difficulty_index}] == Corrupt (enum 3)"
        ),
        "portal_safe_dissonant_reference_index": reference_difficulty_index,
        "portal_safe_dissonant_reference_enum": reference_difficulty_enum,
        "portal_safe_dissonant_pattern": (
            list(
                sentinel_difficulty_state.get(
                    "sentinel_difficulty_enums",
                    [],
                )
            )
            if portal_safe_dissonant
            else []
        ),
        "portal_safe_dissonant_prediction_status": (
            "validated_v19i_portal_safe_live_positive_and_two_negatives"
        ),
        "legacy_direct_corrupt_branch": legacy_direct_corrupt,
        "legacy_direct_corrupt_rule": special_planet_state.get(
            "dissonant_rule",
            "",
        ),
        "legacy_direct_corrupt_pattern": list(
            special_planet_state.get(
                "dissonant_sentinel_pattern",
                [],
            )
        ),
    }

    description_key = (biome, subtype)
    base_description_family = description_lookup.get(description_key)
    description_family_source = (
        "validated_v5i_lookup"
        if base_description_family
        else "unmapped_biome_subtype_key"
    )
    if not base_description_family:
        base_description_family = (
            DESCRIPTION_FAMILY_COMPLETION_V20B3.get(description_key)
        )
        if base_description_family:
            description_family_source = (
                "validated_v20b3_biome_source_family_completion"
            )

    infested_planet = bool(
        special_planet_state.get("infested_planet")
    )
    infested_family = (
        INFESTED_DESCRIPTION_FAMILY_BY_BIOME_V20B4.get(biome)
        if infested_planet
        else None
    )

    if infested_family:
        # Native special-state precedence: infestation overrides ordinary
        # biome and Paradise wording.
        description_family = infested_family
        description_family_coverage = (
            "validated_v20b4_native_infested_family_precedence"
        )
    elif branches["literal_paradise"]:
        description_family = "UI_PARADISE_PLANET"
        description_family_coverage = "validated_paradise_rule"
    else:
        if not base_description_family:
            base_description_family = (
                DESCRIPTION_DEFAULT_FAMILY_BY_BIOME_V20B4.get(biome)
            )
            if base_description_family:
                description_family_source = (
                    "validated_v20b4_native_base_biome_family_fallback"
                )
        description_family = base_description_family
        description_family_coverage = description_family_source

    weather_key = (
        biome,
        weather_index,
        bool(branches["weather_clear_family"]),
        bool(branches["weather_extreme_family"]),
    )
    weather_family = weather_lookup.get(weather_key)
    weather_family_coverage = (
        "validated_v5i_lookup"
        if weather_family
        else "unmapped_weather_key"
    )
    if not weather_family:
        if bool(branches["weather_clear_family"]):
            weather_family = (
                WEATHER_CLEAR_FAMILY_BY_BIOME_V20B4.get(biome)
            )
            weather_family_coverage = (
                "validated_v20b4_native_clear_family_fallback"
            )
        elif bool(branches["weather_extreme_family"]):
            weather_family = (
                WEATHER_EXTREME_FAMILY_BY_BIOME_V20B4.get(biome)
            )
            weather_family_coverage = (
                "validated_v20b4_native_extreme_family_fallback"
            )
        else:
            weather_family = (
                WEATHER_NORMAL_FAMILY_BY_BIOME_V20B4.get(biome)
            )
            weather_family_coverage = (
                "validated_v20b4_native_normal_family_fallback"
                if weather_family
                else "unmapped_weather_key"
            )

    seed_text = str(
        row.get("planet_seed_hex", row.get("root_seed_hex", ""))
    )
    if not seed_text:
        raise KeyError("planet_seed_hex")
    root_seed = int(seed_text, 0)
    words = stream_words(root_seed, 22, 3)

    description_token = token_prediction(
        description_family,
        word=words[0],
        catalog=family_catalog,
    )
    generated_weather_family = str(weather_family or "")
    display_weather_family = generated_weather_family
    if biome == 0:
        display_weather_family = lush_display_weather_family(
            generated_weather_family
        )
    generated_weather_token = token_prediction(
        generated_weather_family,
        word=words[1],
        catalog=family_catalog,
    )
    weather_token = token_prediction(
        display_weather_family,
        word=words[1],
        catalog=family_catalog,
    )
    resource_state = predict_resource_level(
        root_seed,
        biome=biome,
        planet_class=int(row["planet_class"]),
    )
    resources_token = token_prediction(
        resource_state["resources_family"],
        word=words[2],
        catalog=family_catalog,
    )
    substance_state = predict_substances(
        root_seed,
        biome=biome,
        star_type=int(row["star_type"]),
        weather_active=int(row["weather_active"]),
    )

    output = dict(row)
    output.update(branches)
    output.update({
        "description_lookup_key": list(description_key),
        "description_base_family": base_description_family or "",
        "description_family": description_family or "",
        "description_family_friendly": description_friendly(
            description_family
        ),
        "description_family_coverage": description_family_coverage,
        "description_token": description_token["token"],
        "description_token_coverage": description_token["coverage"],
        "weather_lookup_key": list(weather_key),
        "weather_generation_family": generated_weather_family,
        "weather_generation_family_friendly": weather_friendly(
            generated_weather_family
        ),
        "weather_generation_token": generated_weather_token["token"],
        "weather_generation_token_coverage": generated_weather_token[
            "coverage"
        ],
        "weather_display_name_family": display_weather_family,
        "weather_display_name_family_corrected_from_swamp": bool(
            biome == 0
            and display_weather_family != generated_weather_family
        ),
        "weather_display_name_family_rule": (
            "Lush worlds use Lush Discovery-page weather names even when "
            "their functional source family is Swamp."
            if biome == 0
            and display_weather_family != generated_weather_family
            else "Display-name family follows generated weather family."
        ),
        "weather_family": display_weather_family,
        "weather_family_friendly": weather_friendly(display_weather_family),
        "weather_family_coverage": (
            "grouch_live_lush_world_swamp_source_uses_lush_names_v1061_r2"
            if biome == 0
            and display_weather_family != generated_weather_family
            else weather_family_coverage
        ),
        "weather_token": weather_token["token"],
        "weather_token_coverage": weather_token["coverage"],
        "selector_child_22_draw_1_description": words[0],
        "selector_child_22_draw_2_weather": words[1],
        "selector_child_22_draw_3_resources": words[2],
        **resource_state,
        "resources_token": resources_token["token"],
        "resources_token_coverage": resources_token["coverage"],
        "resources_token_exact_available": resources_token[
            "exact_token_available"
        ],
        "resources_token_suffix": resources_token.get("suffix"),
        "resource_prediction_status": (
            "validated_native_writer_current_build"
        ),
        **substance_state,
        **special_planet_state,
        **sentinel_difficulty_state,
        **portal_safe_dissonance_state,
        "numeric_prediction_status": "validated_current_build",
        "branch_prediction_status": "validated_v5i_v5j",
    })
    return output


def is_portal_safe_dissonant(row: dict[str, Any]) -> bool:
    return bool(
        row.get(
            "portal_safe_dissonant_planet",
            row.get("dissonant_planet", False),
        )
    )


def predict_system(
    portal: str,
    galaxy: int = 0,
) -> dict[str, Any]:
    requested_text, requested_portal_planet_number = parse_portal(portal)
    requested_internal_slot = gameplay_planet_number_to_internal_slot(
        requested_portal_planet_number
    )
    canonical = "0" + requested_text[1:]
    galaxy_index = normalize_internal_galaxy_index(galaxy)
    galaxy_info = galaxy_metadata(galaxy_index)
    default_system_name = load_system_name_engine().predict_system_name_from_portal(
        canonical, galaxy_index
    )

    v4y = load_v4y()
    numeric = v4y.run(canonical, galaxy_index)
    if not str(numeric.get("status", "")).startswith("PASS_"):
        raise RuntimeError(
            f"Bundled numeric engine failed: {numeric.get('status')}"
        )

    model = load_model()
    family_catalog = load_family_catalog()
    life_engine = load_life_creature_engine()
    special_system_engine = load_special_system_engine()
    system_state = special_system_engine.predict_system_state(
        life_engine,
        canonical,
        galaxy_index,
    )
    enriched_rows = [
        enrich_planet_row(
            row,
            model=model,
            family_catalog=family_catalog,
            galaxy_index=galaxy_index,
        )
        for row in numeric.get("planet_rows", [])
    ]
    rows = []
    for source_row in enriched_rows:
        output_row = life_engine.enrich_planet(
            sys.modules[__name__],
            source_row,
            system_state=system_state,
            galaxy_index=galaxy_index,
        )
        output_row.update(system_selector_metadata(system_state))
        output_row = apply_grass_glow_prediction(output_row)
        output_row = apply_biome_weather_paradise_metadata(
            output_row,
            family_catalog=family_catalog,
        )
        output_row = apply_exact_terminology(output_row)
        output_row = apply_hardened_discovery_presentation(output_row)
        output_row = apply_fauna_taxonomy(output_row)
        output_row = apply_names_and_water_profile(
            output_row, default_system_name=default_system_name
        )
        output_row["dangerous_predatory_fauna_signal_present"] = bool(
            "DANGEROUS" in output_row.get("fauna_descriptor_tokens", [])
        )
        output_row["dangerous_predatory_fauna_signal_excluded"] = not bool(
            output_row["dangerous_predatory_fauna_signal_present"]
        )
        output_row["dangerous_predatory_fauna_signal_boundary"] = (
            "Exact native descriptor-signal exclusion; not a guarantee that no predators exist."
        )
        rows.append(output_row)

    apply_parent_structure_metadata(canonical, rows, galaxy_index)
    ring_prediction = apply_rendered_ring_metadata(
        canonical, rows, galaxy_index
    )

    for row in rows:
        internal_slot = int(row["slot"])
        generated_code = str(row.get("planet_portal", ""))
        exact_address = exact_planet_portal_address(canonical, internal_slot)
        row.update({
            "generation_galaxy_index": galaxy_index,
            "generation_galaxy_name": galaxy_info["galaxy_name"],
            "galaxy_seed_applied": True,
            "galaxy_generation_status": "test_r2_native_packed_seed_and_reality_weights",
            "internal_generated_slot": internal_slot,
            "gameplay_planet_number": internal_slot_to_gameplay_planet_number(
                internal_slot
            ),
            "generated_planet_slot_code": generated_code,
            "canonical_system_address": canonical,
            "exact_planet_portal_address": exact_address,
            "glyph_portal_planet_address": exact_address,
            "recommended_portal_address": exact_address,
            "portal_target_scope": "exact_planet",
            "exact_planet_portal_target_verified": True,
            "planet_target_mapping_status": (
                "validated_one_based_portal_planet_numbering_v20h14"
            ),
            **galaxy_info,
        })
    enrich_moon_parent_metadata(rows)
    infested_system = any(
        bool(row.get("infested_planet")) for row in rows
    )
    dissonant_system = any(
        is_portal_safe_dissonant(row) for row in rows
    )
    direct_corrupt_system = any(
        bool(row.get("legacy_direct_corrupt_branch", row.get("dissonant_planet")))
        for row in rows
    )

    description_family_known = sum(
        bool(row["description_family"]) for row in rows
    )
    description_token_known = sum(
        bool(row["description_token"]) for row in rows
    )
    weather_family_known = sum(
        bool(row["weather_family"]) for row in rows
    )
    weather_token_known = sum(
        bool(row["weather_token"]) for row in rows
    )
    resource_level_known = sum(
        row.get("resource_level") in (0, 1) for row in rows
    )
    resources_token_known = sum(
        bool(row.get("resources_token")) for row in rows
    )
    exact_substance_rows = sum(
        bool(row.get("common_substance_id"))
        and bool(row.get("uncommon_substance_id"))
        and bool(row.get("rare_substance_id"))
        for row in rows
    )
    exact_life_rows = sum(
        row.get("life_level") in (0, 1, 2, 3)
        and row.get("creature_life_level") in (0, 1, 2, 3)
        for row in rows
    )
    exact_descriptor_rows = sum(
        bool(row.get("creature_descriptor_primary"))
        and bool(row.get("creature_descriptor_aux_1"))
        and bool(row.get("creature_descriptor_aux_2"))
        and bool(row.get("creature_descriptor_aux_3"))
        for row in rows
    )

    requested_planet_exists = bool(
        requested_internal_slot is None
        or requested_internal_slot < int(numeric["system"]["planet_count"])
    )
    address_domain = system_address_domain_metadata(
        requested_text,
        galaxy=galaxy_index,
        resolve_native=True,
    )
    warnings: list[str] = []
    if requested_portal_planet_number == 0:
        warnings.append(
            "The zero-prefixed address identifies the system and portals to the "
            "first planet. Select a row to copy its exact one-based planet address."
        )
    if not address_domain["validated_in_game_system"]:
        warnings.append(
            "Solar-system index "
            f"{address_domain['system_index_decimal']} "
            f"({address_domain['system_index_hex']}) is not a validated real "
            "portal destination for this region. "
            f"{address_domain['in_game_existence_status']}. The following "
            "planet output is generator replay only and a glyph portal may "
            "approximate to a different destination."
        )
    if not requested_planet_exists:
        warnings.append(
            f"Requested gameplay planet {requested_portal_planet_number} does not exist "
            f"in this {numeric['system']['planet_count']}-body system. The portal may redirect."
        )
    portal_target_warning = " ".join(warnings)

    result = {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": (
            "PASS_CORE_V1_ADDRESS_PREDICTION"
            if address_domain["validated_in_game_system"]
            else "PASS_CORE_V1_SYNTHETIC_GENERATOR_INPUT_ANALYSIS"
        ),
        "mode": (
            "OFFLINE_SELF_CONTAINED_ADDRESS_PREDICTION"
            if address_domain["validated_in_game_system"]
            else "OFFLINE_SYNTHETIC_GENERATOR_REPLAY_UNVERIFIED"
        ),
        "input": {
            "requested_portal": requested_text,
            "requested_portal_planet_number": requested_portal_planet_number,
            "requested_internal_slot": requested_internal_slot,
            "requested_planet_index": requested_internal_slot,
            "requested_planet_index_exists": requested_planet_exists,
            "portal_target_warning": portal_target_warning,
            "canonical_system_portal": canonical,
            "recommended_portal_address": (
                requested_text if requested_portal_planet_number else canonical
            ),
            "portal_target_scope": (
                "exact_planet" if requested_portal_planet_number else "system_only"
            ),
            "exact_planet_portal_target_verified": bool(
                requested_portal_planet_number and requested_planet_exists
            ),
            "planet_target_mapping_status": (
                "validated_one_based_portal_planet_numbering_v20h14"
            ),
            "galaxy_index": galaxy_index,
            **galaxy_info,
            **address_domain,
        },
        "system": {
            **numeric["system"],
            **galaxy_info,
            **system_selector_metadata(system_state),
            "default_procedural_system_name": default_system_name["default_procedural_name"],
            "default_system_name_language": default_system_name.get("language", "English"),
            "default_system_name_exact": True,
            "default_system_name_scope": "default_procedural_not_current_discovery_name",
            "default_system_name_address_conversion": default_system_name.get("address_conversion", {}),
            "source_system_kind": system_state["source_system_kind"],
            "in_empty_system": system_state["in_empty_system"],
            "in_abandoned_system": system_state["in_abandoned_system"],
            "in_gas_giant_system": system_state[
                "in_gas_giant_system"
            ],
            "in_pirate_system": system_state[
                "in_pirate_system"
            ],
            "raw2c_auxiliary_flag": system_state[
                "raw2c_auxiliary_flag"
            ],
            "in_gas_giant_system_candidate": system_state[
                "in_gas_giant_system"
            ],
            "in_pirate_system_candidate": system_state[
                "in_pirate_system"
            ],
            "infested_system": infested_system,
            "dissonant_system": dissonant_system,
            "direct_corrupt_system": direct_corrupt_system,
            "system_state_status": system_state[
                "system_state_status"
            ],
            "rendered_ring_selector_exact": True,
            "ringed_planet_numbers": list(
                ring_prediction.get("ringed_planet_numbers", [])
            ),
            "ringed_planet_count": len(
                ring_prediction.get("ringed_planet_numbers", [])
            ),
            "rendered_ring_selector_status": ring_prediction.get(
                "status", ""
            ),
        },
        "layer_statuses": numeric.get("layer_statuses", {}),
        "planet_rows": rows,
        "coverage": {
            "numeric_planets": len(rows),
            "default_planet_names_exact": sum(bool(row.get("default_planet_name_exact")) for row in rows),
            "default_system_name_exact": bool(default_system_name.get("default_procedural_name")),
            "water_profiles_exact": sum(bool(row.get("water_profile_exact")) for row in rows),
            "exact_rendered_ring_rows": sum(
                bool(row.get("rings_prediction_exact")) for row in rows
            ),
            "rendered_ring_planets": sum(
                bool(row.get("has_rings")) for row in rows
            ),
            "numeric_exact_current_build": len(rows),
            "branch_exact_current_build": len(rows),
            "description_family_known": description_family_known,
            "description_token_known": description_token_known,
            "weather_family_known": weather_family_known,
            "weather_token_known": weather_token_known,
            "address_only_resource_level_known": resource_level_known,
            "resources_token_known": resources_token_known,
            "exact_substance_rows": exact_substance_rows,
            "address_only_life_creature_rows": exact_life_rows,
            "creature_descriptor_rows": exact_descriptor_rows,
            "fauna_token_rows": sum(
                bool(row.get("fauna_token")) for row in rows
            ),
            "flora_token_rows": sum(
                bool(row.get("flora_token")) for row in rows
            ),
            "exact_planet_classification_rows": sum(
                bool(row.get("planet_classification_exact")) for row in rows
            ),
            "exact_weather_wording_rows": sum(
                bool(row.get("weather_display_exact")) for row in rows
            ),
            "exact_resource_wording_rows": sum(
                bool(row.get("resources_display_exact")) for row in rows
            ),
            "exact_fauna_wording_rows": sum(
                bool(row.get("fauna_display_exact")) for row in rows
            ),
            "exact_flora_wording_rows": sum(
                bool(row.get("flora_display_exact")) for row in rows
            ),
            "fauna_descriptor_profile_rows": sum(
                bool(row.get("fauna_descriptor_profile_exact"))
                for row in rows
            ),
            "fauna_archetype_signal_rows": sum(
                bool(row.get("fauna_community_archetype_signals"))
                for row in rows
            ),
            "infested_planets": sum(
                bool(row.get("infested_planet")) for row in rows
            ),
            "direct_dissonant_planets": sum(
                bool(row.get("legacy_direct_corrupt_branch", row.get("dissonant_planet")))
                for row in rows
            ),
            "portal_safe_dissonant_planets": sum(
                is_portal_safe_dissonant(row) for row in rows
            ),
            "surface_objectlist_rows": sum(
                bool(row.get("surface_main_object_list")) for row in rows
            ),
            "grass_palette_rows": sum(
                bool(row.get("grass_primary_hex")) for row in rows
            ),
            "grass_alt_palette_rows": sum(
                bool(row.get("grass_alt_primary_hex")) for row in rows
            ),
            "explicit_grass_asset_planets": sum(
                bool(row.get("explicit_grass_asset_available")) for row in rows
            ),
            "bioluminescent_grass_carpet_planets": sum(
                bool(row.get("glowing_grass_asset_available")) for row in rows
            ),
            "any_emissive_grass_asset_planets": sum(
                bool(row.get("any_emissive_grass_asset_available"))
                for row in rows
            ),
            "mushroom_asset_planets": sum(
                bool(row.get("mushroom_asset_available")) for row in rows
            ),
            "large_glowing_mushroom_tree_planets": sum(
                bool(row.get("glowing_mushroom_asset_available")) for row in rows
            ),
            "any_emissive_mushroom_asset_planets": sum(
                bool(row.get("any_emissive_mushroom_asset_available"))
                for row in rows
            ),
        },
        "validation": {
            "training_systems": 13,
            "training_planets": 71,
            "independent_systems": 4,
            "independent_planets": 20,
            "v5j_status": (
                "PASS_V5J_FINAL_INDEPENDENT_BRANCH_VALIDATION_EXACT"
            ),
            "negative_y_independent_systems": 3,
            "negative_y_independent_planets": 18,
            "negative_y_status": (
                "PASS_NEGATIVE_Y_INDEPENDENT_VALIDATION_EXACT"
            ),
            "resource_writer_training_systems": 13,
            "resource_writer_training_planets": 71,
            "resource_level_exact": "71/71",
            "resources_token_exact": "71/71",
            "resource_writer_status": (
                "PASS_NATIVE_RESOURCE_LEVEL_WRITER_REPLAY_EXACT"
            ),
            "substance_validation_systems": 16,
            "substance_validation_planets": 89,
            "common_substance_exact": "89/89",
            "uncommon_substance_exact": "89/89",
            "rare_substance_exact": "89/89",
            "substance_status": (
                "PASS_COMMON_SUBSTANCE_WEATHER_ACTIVE_GATE_EXACT"
            ),
            "life_numeric_exact": "71/71",
            "flora_token_exact": "47/47",
            "fauna_standard_token_exact": "60/60",
            "fauna_weird_token_exact": "8/8",
            "fauna_robot_token_exact": "3/3",
            "creature_descriptors_exact": "18/18",
            "creature_life_address_derived_exact": "18/18",
            "source_system_kind_controls": "4/4",
            "in_empty_system_controls": "8/8",
            "special_system_controls": "9/9",
            "special_system_boolean_fields": "36/36",
            "special_system_status": (
                "PASS_ADDRESS_ONLY_SPECIAL_SYSTEM_REPLAY_V16C_EXACT"
            ),
            "life_creature_status": (
                "PASS_IN_EMPTY_SYSTEM_ADDRESS_ONLY_SOURCE_V14_EXACT"
            ),
            "infested_rule": "BiomeSubType == 24",
            "infested_status": (
                "PASS_SPECIAL_PLANET_PREDICATES_STATIC_V17A_EXACT"
            ),
            "direct_dissonance_rule": DIRECT_DISSONANT_RULE,
            "direct_dissonance_corpus_exact": "71/71",
            "direct_dissonance_status": (
                "PASS_DISSONANT_NATIVE_RULE_CLOSURE_V17F_EXACT"
            ),
            "surface_objectlist_exact": "47/47",
            "surface_objectlist_status": (
                "PASS_ADDRESS_ONLY_SURFACE_OBJECTLIST_CLOSURE_V20A7_DATA_COMPLETE"
            ),
            "grass_colour_sequences_exact": "47/47",
            "grass_alt_colour_sequences_exact": "47/47",
            "grass_primary_hex_exact": "47/47",
            "grass_alt_primary_hex_exact": "47/47",
            "grass_colour_status": (
                "PASS_ADDRESS_ONLY_GRASS_COLOUR_CLOSURE_V20A8A_DATA_COMPLETE"
            ),
        },
        "claim_boundary": {
            "validated_current_build": True,
            "negative_signed8_y_normalization_validated": True,
            "description_weather_paradise_extreme_core": True,
            "address_only_resource_level_solved": True,
            "address_only_resources_token_solved": True,
            "exact_substance_ids_solved": True,
            "address_only_source_system_kind_solved": True,
            "address_only_in_empty_system_solved": True,
            "address_only_in_abandoned_system_solved": True,
            "address_only_in_gas_giant_system_solved": True,
            "address_only_in_pirate_system_solved": True,
            "address_only_infested_predicate_solved": True,
            "address_only_direct_dissonance_rule_solved": True,
            "address_only_full_sentinel_difficulty_replay_solved": True,
            "address_only_life_abundance_solved": True,
            "address_only_creature_life_abundance_solved": True,
            "address_only_creature_descriptors_solved": True,
            "fauna_flora_abundance_token_schedule_solved": True,
            "surface_deposit_coordinates_solved": False,
            "hotspot_coordinates_solved": False,
            "individual_fauna_species_generation_solved": False,
            "primary_surface_objectlist_generation_solved": True,
            "primary_surface_grass_asset_capability_solved": True,
            "primary_surface_glowing_grass_capability_solved": True,
            "primary_surface_mushroom_capability_solved": True,
            "primary_surface_glowing_mushroom_capability_solved": True,
            "grass_palette_generation_solved": True,
            "grass_alt_palette_generation_solved": True,
            "specific_model_visible_colour_channel_solved": False,
            "visual_surface_coverage_solved": False,
            "terrain_visual_assets_solved": False,
            "default_procedural_planet_names_solved": True,
            "default_procedural_system_names_solved": True,
            "address_only_water_style_solved": True,
            "address_only_water_murkyness_solved": True,
            "address_only_water_emission_solved": True,
            "address_only_foam_emission_solved": True,
            "current_discovery_names_solved": False,
            "screenshot_pixel_colour_solved": False,
            "updates_may_require_new_static_data": True,
        },
        "safety": {
            "nms_process_required": False,
            "process_access": False,
            "process_memory_writes": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
        },
    }
    return result


def scalar_csv_value(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return value


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            extrasaction="ignore",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: scalar_csv_value(row.get(key))
                for key in fields
            })


def bool_word(value: Any) -> str:
    return "YES" if bool(value) else "NO"


def format_planet_line(row: dict[str, Any]) -> str:
    desc = row.get("planet_classification_display") or row.get(
        "description_token"
    ) or row.get("description_family_friendly", "Unknown")
    weather = row.get("weather_display") or row.get(
        "weather_token"
    ) or row.get("weather_family_friendly", "Unknown")
    resources = row.get("resources_display") or row.get(
        "resources_token"
    ) or row.get("resources_family", "Unknown")
    return (
        f"INTERNAL_SLOT={row['slot']} "
        f"GAMEPLAY_PLANET={row.get('gameplay_planet_number', int(row['slot']) + 1)} "
        f"EXACT_PLANET_PORTAL={row.get('exact_planet_portal_address', '')} "
        f"GENERATED_SLOT_CODE={row.get('generated_planet_slot_code', row['planet_portal'])} "
        f"BIOME_FAMILY={row['biome_name']} "
        f"BIOME_VARIANT={row.get('biome_variant_display', '')!r} "
        f"WORLD_TYPE={row.get('world_type_display', '')!r} "
        f"PLANET_CLASSIFICATION={desc!r} "
        f"SUBTYPE={row['biome_subtype']} "
        f"CLASS={row['planet_class']} "
        f"SIZE={row['planet_size']} "
        f"DEFAULT_PLANET_NAME={row.get('default_procedural_planet_name', '')!r} "
        f"DEFAULT_SYSTEM_NAME={row.get('default_procedural_system_name', '')!r} "
        f"WATER={row['water_active']} "
        f"SEA_LEVEL={row['sea_level']} "
        f"WATER_PROFILE={row.get('water_profile_display', '')!r} "
        f"FOAM_EMISSION={row.get('foam_emission_mode', '')!r} "
        f"INTRINSIC_GLOW_HUE={row.get('intrinsic_foam_emission_hue_hex', '')!r} "
        f"DESCRIPTION={desc!r} "
        f"WEATHER={weather!r} "
        f"WEATHER_SEVERITY={row.get('weather_severity_display', 'Extreme' if row.get('is_weather_extreme') else 'Normal')!r} "
        f"STORMS_AND_PASSIVE_HAZARD={row.get('weather_functional_display', '')!r} "
        f"RESOURCES={resources!r} "
        f"RESOURCE_LEVEL={row['resource_level']} "
        f"RESOURCE_ABUNDANCE={row['resource_abundance']!r} "
        f"COMMON_SUBSTANCE={row['common_substance_id']!r} "
        f"UNCOMMON_SUBSTANCE={row['uncommon_substance_id']!r} "
        f"RARE_SUBSTANCE={row['rare_substance_id']!r} "
        f"FAUNA_LEVEL={row['fauna_level']} "
        f"FAUNA_ABUNDANCE={row['fauna_abundance']!r} "
        f"FAUNA_DISPLAY={row.get('fauna_display', row['fauna_abundance'])!r} "
        f"FAUNA_TOKEN={row['fauna_token']!r} "
        f"FLORA_LEVEL={row['flora_level']} "
        f"FLORA_ABUNDANCE={row['flora_abundance']!r} "
        f"FLORA_DISPLAY={row.get('flora_display', row['flora_abundance'])!r} "
        f"FLORA_TOKEN={row['flora_token']!r} "
        f"CREATURE_PRIMARY={row['creature_descriptor_primary']!r} "
        f"FAUNA_PROFILE={row.get('fauna_descriptor_profile_summary', '')!r} "
        f"FAUNA_ARCHETYPE_SIGNALS={row.get('fauna_community_archetype_signal_summary', '')!r} "
        f"FAUNA_TAXONOMY_CLAIM={row.get('fauna_taxonomy_claim', '')!r} "
        f"PARADISE={row['literal_paradise']} "
        f"EXTREME={row['is_weather_extreme']} "
        f"INFESTED={row['infested_planet']} "
        f"DISSONANT={is_portal_safe_dissonant(row)} "
        f"DISSONANT_PATTERN={row.get('portal_safe_dissonant_pattern', [])} "
        f"LEGACY_DIRECT_CORRUPT={row.get('legacy_direct_corrupt_branch', row.get('dissonant_planet', False))} "
        f"SURFACE_OBJECT_LIST={row.get('surface_main_object_list', '')!r} "
        f"GRASS_ASSET={row.get('explicit_grass_asset_available', False)} "
        f"GLOWING_GRASS={row.get('glowing_grass_asset_available', False)} "
        f"MAJOR_MUSHROOM_FLORA_SET={row.get('mushroom_asset_available', False)} "
        f"GLOWING_MUSHROOM={row.get('glowing_mushroom_asset_available', False)} "
        f"GRASS_SLOT0_DIAGNOSTIC={row.get('grass_colour_summary', '')!r} "
        f"GRASS_ALT_SLOT0_DIAGNOSTIC={row.get('grass_alt_colour_summary', '')!r} "
        f"VISIBLE_GRASS_COLOUR_EXACT={row.get('visible_grass_colour_exact', False)} "
        f"VISIBLE_GRASS_COLOUR_STATUS={row.get('visible_grass_colour_prediction_status', '')!r} "
        f"VISUAL_FILTER={row.get('visual_filter_display', '')!r} "
        f"VISUAL_FILTER_STATUS={row.get('visual_filter_status', '')!r} "
        f"DAY_ATMOSPHERE={row.get('day_atmosphere_display', '')!r} "
        f"SKY_PALETTE={row.get('atmosphere_sky_summary', '')!r} "
        f"SUNSET_PALETTE={row.get('atmosphere_sunset_summary', '')!r} "
        f"NIGHT_PALETTE={row.get('atmosphere_night_summary', '')!r} "
        f"CLOUD_PALETTE={row.get('atmosphere_cloud_summary', '')!r} "
        f"SENTINELS_DISPLAY={row.get('sentinel_discovery_display', row.get('sentinel_standard_activity_display', ''))!r} "
        f"SENTINELS_DISPLAY_EXACT={row.get('sentinel_discovery_exact', False)} "
        f"SENTINEL_STANDARD_CATEGORY={row.get('sentinel_standard_activity_display', row.get('sentinel_functional_activity_display', ''))!r} "
        f"LEGACY_SENTINEL_LEVEL={row['sentinel_level']} "
        f"BUILDING_LEVEL={row['building_level']} "
        f"HAS_SCRAP={row['has_scrap']}"
    )


def prediction_report_text(result: dict[str, Any]) -> str:
    system = result["system"]
    input_data = result["input"]
    lines = [
        "ATLAS APF — CORE V1",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        "NMS_PROCESS_REQUIRED=False",
        "PROCESS_ACCESS=False",
        "GAME_FILE_WRITES=False",
        "SAVE_WRITES=False",
        "MOD_WRITES=False",
        "",
        "ADDRESS",
        "-------",
        f"REQUESTED_PORTAL={input_data['requested_portal']}",
        f"REQUESTED_GAMEPLAY_PLANET_NUMBER={input_data['requested_portal_planet_number']}",
        f"REQUESTED_INTERNAL_GENERATED_SLOT={input_data['requested_internal_slot']}",
        (
            "REQUESTED_PLANET_EXISTS="
            f"{input_data['requested_planet_index_exists']}"
        ),
        (
            "PORTAL_TARGET_WARNING="
            f"{input_data['portal_target_warning'] or 'NONE'}"
        ),
        f"CANONICAL_SYSTEM_PORTAL={input_data['canonical_system_portal']}",
        f"RECOMMENDED_PORTAL_ADDRESS={input_data['recommended_portal_address']}",
        (
            "EXACT_PLANET_PORTAL_TARGET_VERIFIED="
            f"{input_data['exact_planet_portal_target_verified']}"
        ),
        f"PORTAL_TARGET_SCOPE={input_data['portal_target_scope']}",
        f"SYSTEM_INDEX_DECIMAL={input_data['system_index_decimal']}",
        f"SYSTEM_INDEX_HEX={input_data['system_index_hex']}",
        f"VALIDATED_IN_GAME_SYSTEM={input_data['validated_in_game_system']}",
        f"GLYPH_PORTAL_ACCESSIBLE={input_data['glyph_portal_accessible']}",
        f"ADDRESS_KIND={input_data['address_kind']}",
        f"IN_GAME_EXISTENCE_STATUS={input_data['in_game_existence_status']}",
        f"TRAVEL_ACCESS={input_data['travel_access']}",
        f"TRAVEL_GUIDANCE={input_data['guidance']}",
        f"GALAXY_INDEX={input_data['galaxy_index']}",
        "",
        "SYSTEM",
        "------",
        f"DEFAULT_PROCEDURAL_SYSTEM_NAME={system.get('default_procedural_system_name', '')}",
        "DEFAULT_SYSTEM_NAME_SCOPE=default procedural; current discovery/player name may differ",
        f"PLANET_COUNT={system['planet_count']}",
        f"STAR_TYPE={system['star_type']}",
        f"STAR_COLOUR={system['colour']}",
        f"SOURCE_SYSTEM_KIND={system['source_system_kind']}",
        f"IN_EMPTY_SYSTEM={system['in_empty_system']}",
        f"IN_ABANDONED_SYSTEM={system['in_abandoned_system']}",
        f"IN_GAS_GIANT_SYSTEM={system['in_gas_giant_system']}",
        f"IN_PIRATE_SYSTEM={system['in_pirate_system']}",
        f"INFESTED_SYSTEM={system['infested_system']}",
        f"DISSONANT_SYSTEM={system['dissonant_system']}",
        "",
        "PLANETS",
        "-------",
    ]
    lines.extend(format_planet_line(row) for row in result["planet_rows"])
    lines.extend([
        "",
        "COVERAGE",
        "--------",
    ])
    for key, value in result["coverage"].items():
        lines.append(f"{key.upper()}={value}")
    lines.extend([
        "",
        "IMPORTANT",
        "---------",
        (
            "Planet classifications, weather, fauna, flora and solved low-Sentinel "
            "descriptions use exact current-game English wording. Weather severity "
            "is reported separately from the weather name. Internal generation "
            "tokens remain available in JSON and CSV outputs for auditability."
        ),
        (
            "The major mushroom-style flora field identifies the dominant generated "
            "asset set; small incidental mushroom props can still appear when it is "
            "false. The live-confirmed bioluminescent grass-carpet and large glowing "
            "mushroom-tree asset variants are address-only exact. Broad emissive "
            "asset diagnostics are retained separately. Grass and GrassAlt generated "
            "five-slot palette sequences are address-only exact. Summary swatches and "
            "colour filters use generated slot 0 only. Visible grass colour is not "
            "predicted because GroundColourIndex=Auto, material/emission channels and "
            "local surface coverage remain separate."
        ),
        (
            "Cloud and all six generated sky/fog palette sequences are address-only "
            "exact. Native DayColourIndex, DuskColourIndex and NightColourIndex are "
            "also address-only exact and select exact current-build sky-table entries. "
            "Final screenshots can still vary with solar angle, weather blending, "
            "exposure and renderer LUTs."
        ),
    ])
    return "\n".join(lines) + "\n"


def write_prediction_outputs(
    result: dict[str, Any],
    output_folder: Path | None = None,
) -> dict[str, str]:
    if output_folder is None:
        portal = result["input"]["canonical_system_portal"]
        output_folder = (
            OUTPUT_ROOT / f"prediction_{portal}_{stamp()}"
        )
    output_folder.mkdir(parents=True, exist_ok=False)

    json_path = output_folder / "planet_prediction_core_v1.json"
    csv_path = output_folder / "planet_prediction_core_v1.csv"
    report_path = (
        output_folder
        / "OPEN_THIS_PLANET_PREDICTION_CORE_V1.txt"
    )
    safe_json(json_path, result)
    write_csv(csv_path, result["planet_rows"])
    report_path.write_text(
        prediction_report_text(result),
        encoding="utf-8",
    )
    return {
        "folder": str(output_folder),
        "json": str(json_path),
        "csv": str(csv_path),
        "report": str(report_path),
    }


def open_path(path: Path) -> None:
    if os.name == "nt":
        os.startfile(str(path))  # type: ignore[attr-defined]


def normalize_biome_filter(value: str | int | None) -> int | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip()
    if text.isdigit():
        number = int(text)
        if number not in BIOME_NAMES:
            raise ValueError(f"Unknown biome number: {number}")
        return number
    folded = text.casefold()
    matches = [
        number
        for number, name in BIOME_NAMES.items()
        if folded in name.casefold()
    ]
    if len(matches) != 1:
        raise ValueError(
            f"Biome filter {value!r} is ambiguous or unknown."
        )
    return matches[0]



SENTINEL_CATEGORY_ENUMS = {
    "rare": 0,
    "default": 1,
    "aggressive": 2,
    "corrupt": 3,
}

ON_FOOT_COMBAT_DIFFICULTY_NAMES = {
    0: "None",
    1: "Minimal",
    2: "Standard",
    3: "Hostile",
}

SENTINEL_ACTIVITY_DISPLAY_NAMES = {
    0: "Low Sentinel Activity",
    1: "High Sentinel Activity",
    2: "Aggressive Sentinels",
    3: "Dissonance detected",
}


def on_foot_combat_difficulty_values() -> tuple[str, ...]:
    return tuple(ON_FOOT_COMBAT_DIFFICULTY_NAMES[index] for index in range(4))


def sentinel_activity_filter_values() -> tuple[str, ...]:
    return tuple(SENTINEL_ACTIVITY_DISPLAY_NAMES[index] for index in range(4))


def sentinel_activity_filter_values_for_difficulty(
    difficulty: str | int | None,
) -> tuple[str, ...]:
    """Return only native activity categories reachable for a difficulty."""
    if difficulty is None or str(difficulty).strip() == "":
        return ()
    if isinstance(difficulty, int) or str(difficulty).strip().isdigit():
        index = int(difficulty)
    else:
        lookup = {name.casefold(): idx for idx, name in ON_FOOT_COMBAT_DIFFICULTY_NAMES.items()}
        index = lookup.get(str(difficulty).strip().casefold(), -1)
    if index not in ON_FOOT_COMBAT_DIFFICULTY_NAMES:
        raise ValueError("Unknown on-foot combat difficulty.")
    reachable = {
        # Native difficulty index 0 (None) always writes Rare/low activity.
        0: (0,),
        # Minimal can produce Rare, Default or the direct Corrupt/Dissonant
        # branch, but not the Aggressive category.
        1: (0, 1, 3),
        # Standard and Hostile can reach all four native categories.
        2: (0, 1, 2, 3),
        3: (0, 1, 2, 3),
    }[index]
    return tuple(SENTINEL_ACTIVITY_DISPLAY_NAMES[value] for value in reachable)


def normalize_native_sentinel_enum_filter(
    *,
    category: str | None = None,
    enum_value: int | None = None,
) -> int | None:
    """Normalize a CLI or GUI native Sentinel category filter."""
    if category is not None and enum_value is not None:
        raise ValueError(
            "Choose either a Sentinel category or a Sentinel enum, not both."
        )
    if category is not None:
        key = str(category).strip().casefold()
        if key not in SENTINEL_CATEGORY_ENUMS:
            raise ValueError(
                "Sentinel category must be Rare, Default, Aggressive or Corrupt."
            )
        return SENTINEL_CATEGORY_ENUMS[key]
    if enum_value is None:
        return None
    result = int(enum_value)
    if result not in (0, 1, 2, 3):
        raise ValueError("Native Sentinel enum must be 0, 1, 2 or 3.")
    return result

def normalize_optional_bool_filter(value: Any) -> bool | None:
    """Normalize optional GUI/CLI include/exclude filters."""
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    folded = str(value).strip().casefold()
    if folded in {"true", "yes", "include", "must include", "required"}:
        return True
    if folded in {"false", "no", "exclude", "must exclude", "forbidden"}:
        return False
    raise ValueError(f"Unknown optional boolean filter: {value!r}")


def _text_contains(value: Any, query: str | None) -> bool:
    if not query:
        return True
    return str(query).strip().casefold() in str(value or "").casefold()


def planet_classification_filter_values() -> tuple[str, ...]:
    """Return every unique exact current-game scanned planet classification."""
    catalog = load_terminology_engine().load_catalog(TERMINOLOGY_CATALOG_PATH)
    entries = catalog.get("entries", {})
    planet_word = str(entries.get("PLANETCLASS1", {}).get("text_en_GB", "Planet"))
    moon_word = str(entries.get("PLANETCLASS2", {}).get("text_en_GB", "Moon"))
    giant_word = "Giant"
    values: set[str] = set()
    for entry in entries.values():
        if entry.get("category") != "planet_classification":
            continue
        template = str(entry.get("text_en_GB", "")).strip()
        if not template:
            continue
        if "%PLANETCLASS%" in template:
            values.add(template.replace("%PLANETCLASS%", planet_word))
            values.add(template.replace("%PLANETCLASS%", moon_word))
            values.add(template.replace("%PLANETCLASS%", giant_word))
        else:
            values.add(template)
    result = tuple(sorted(values, key=lambda value: (value.casefold(), value)))
    if not result or any("%PLANETCLASS%" in value for value in result):
        raise RuntimeError("Exact planet-classification catalog is incomplete.")
    return result


def normalize_planet_classification_filter(value: str | None) -> str | None:
    """Normalize an exact scanned planet type selected by GUI or CLI."""
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.casefold() in {"any", "any planet type", "any classification"}:
        return None
    lookup = {item.casefold(): item for item in planet_classification_filter_values()}
    canonical = lookup.get(text.casefold())
    if canonical is None:
        raise ValueError(
            f"Unknown exact planet classification: {value!r}. "
            "Choose one of the current-game classification values."
        )
    return canonical


def weather_family_filter_values() -> tuple[str, ...]:
    """Return only real exact weather-family tokens from bundled data."""
    families = load_family_catalog().get("families", {})
    values = tuple(sorted(
        str(key) for key in families
        if str(key).startswith("WEATHER_")
    ))
    if len(values) != 27 or "CLEAR" in values or "EXTREME" in values:
        raise RuntimeError("Exact weather-family filter catalog is incomplete.")
    return values


def normalize_weather_family_filter(value: str | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.casefold() in {"any", "any weather family"}:
        return None
    lookup = {item.casefold(): item for item in weather_family_filter_values()}
    canonical = lookup.get(text.casefold())
    if canonical is None:
        raise ValueError(
            f"Unknown exact weather-family token: {value!r}. "
            "Generic CLEAR/EXTREME values are not exact family tokens; use the "
            "Clear weather or Extreme weather tri-state filters instead."
        )
    return canonical


def run_portal_addressability_weather_filter_regression() -> dict[str, Any]:
    """Prove native legacy occupancy, purple bounds and weather filtering."""
    checks: dict[str, list[bool]] = {
        "native_static": [],
        "native_control_counts": [],
        "portal_index_boundary": [],
        "finder_range_validation": [],
        "finder_no_wrap": [],
        "invalid_portal_results_blocked": [],
        "clear_weather_filter": [],
        "exact_weather_family_catalog": [],
        "legacy_generic_weather_rejected": [],
        "expanded_search_domains": [],
        "internal_address_safety_labels": [],
    }
    failures: list[dict[str, Any]] = []

    native_static = run_native_legacy_count_static_regression()
    checks["native_static"].append(bool(native_static.get("exact")))
    controls = {
        "239D7F56": 564,
        "239D7F55": 562,
        "239D6F56": 231,
        "229D7F56": 546,
    }
    for suffix, expected_count in controls.items():
        occupancy = native_legacy_system_count_metadata(
            f"0000{suffix}",
            0,
            allow_replay=False,
        )
        checks["native_control_counts"].extend([
            bool(occupancy.get("resolved")),
            int(occupancy.get("generated_legacy_system_count", -1))
            == expected_count,
            int(occupancy.get("last_valid_legacy_ssi", -1))
            == expected_count - 1,
            int(occupancy.get("first_invalid_legacy_ssi", -1))
            == expected_count,
            str(occupancy.get("source", "")).startswith(
                "app_owned_standalone_"
            ),
        ])

    control_count = controls["239D7F56"]
    for value, expected in (
        (0x000, True),
        (0x233, True),
        (0x234, False),
        (0x2FF, False),
        (0x300, False),
        (0x3E7, False),
        (0x3E8, False),
        (0x3EE, True),
        (0x40E, True),
        (0x428, True),
        (0x429, False),
        (0xFFF, False),
    ):
        checks["portal_index_boundary"].append(
            is_portal_addressable_system_index(value, control_count)
            == expected
        )

    for value in (0x000, 0x233, 0x3E9, 0x3EE, 0x40E, 0x428):
        portal = portal_with_addressable_system_index(
            "020B239D7F56", value, control_count
        )
        checks["finder_range_validation"].append(
            portal_system_index(portal) == value
        )
    for value in (0x234, 0x2FF, 0x300, 0x3E7, 0x429, 0xFFF):
        try:
            portal_with_addressable_system_index(
                "020B239D7F56", value, control_count
            )
            checks["finder_range_validation"].append(False)
        except ValueError:
            checks["finder_range_validation"].append(True)

    checks["finder_no_wrap"].extend([
        validate_finder_system_range(
            0, 564, "portal", native_legacy_count=control_count
        ) == (0, 564),
        validate_finder_system_range(
            0x233, 1, "portal", native_legacy_count=control_count
        ) == (0x233, 1),
        validate_finder_system_range(0x3E9, 64, "purple")
        == (0x3E9, 64),
        validate_finder_system_range(0x428, 1, "purple")
        == (0x428, 1),
    ])
    for start_value, count_value, domain, native_count in (
        (0x233, 2, "portal", control_count),
        (0x234, 1, "portal", control_count),
        (0, 565, "portal", control_count),
        (0x3E7, 1, "purple", None),
        (0x428, 2, "purple", None),
        (0x429, 1, "purple", None),
        (0x3E8, 1, "purple", None),
        (0x3E9, 65, "purple", None),
    ):
        try:
            validate_finder_system_range(
                start_value,
                count_value,
                domain,
                native_legacy_count=native_count,
            )
            checks["finder_no_wrap"].append(False)
        except ValueError:
            checks["finder_no_wrap"].append(True)

    checks["expanded_search_domains"].extend([
        finder_search_domain_values() == (
            "Standard portal systems (exact count per region)",
            "Purple portal systems (64 per region)",
        ),
        normalize_finder_search_domain("portal")
        == FINDER_SEARCH_DOMAIN_PORTAL,
        normalize_finder_search_domain("purple")
        == FINDER_SEARCH_DOMAIN_PURPLE,
        finder_system_range_bounds(
            "portal",
            anchor_portal="0000239D7F56",
            galaxy=0,
            resolve_native=False,
        ) == (0x000, 0x233, 564),
        finder_system_range_bounds("purple")
        == (0x3E9, 0x428, 64),
    ])
    for rejected_domain in ("internal", "all", "synthetic"):
        try:
            normalize_finder_search_domain(rejected_domain)
            checks["expanded_search_domains"].append(False)
        except ValueError:
            checks["expanded_search_domains"].append(True)

    legacy_last = system_address_domain_metadata(
        "0233239D7F56", 0, resolve_native=False
    )
    legacy_first_invalid = system_address_domain_metadata(
        "0234239D7F56", 0, resolve_native=False
    )
    purple_lower = system_address_domain_metadata("03E9FC7FDDC2")
    purple_upper = system_address_domain_metadata("0428FC7FDDC2")
    gap = system_address_domain_metadata("0300FC7FDDC2")
    above = system_address_domain_metadata("0429FC7FDDC2")
    checks["internal_address_safety_labels"].extend([
        legacy_last["validated_in_game_system"],
        legacy_last["address_kind"] == "legacy_portal_system",
        legacy_last["native_legacy_system_count"] == 564,
        not legacy_first_invalid["validated_in_game_system"],
        legacy_first_invalid["address_kind"]
        == "legacy_unoccupied_system_index",
        purple_lower["validated_in_game_system"],
        purple_lower["glyph_portal_accessible"],
        purple_lower["address_kind"]
        == "worlds_ii_purple_portal_system",
        purple_upper["validated_in_game_system"],
        not gap["validated_in_game_system"],
        gap["address_kind"] == "unmapped_system_index_gap",
        not above["validated_in_game_system"],
        above["address_kind"] == "unsupported_generator_index",
    ])

    checks["invalid_portal_results_blocked"].extend([
        is_portal_addressable("0233239D7F56"),
        not is_portal_addressable("0234239D7F56"),
        not is_portal_addressable("0300239D7F56"),
        not is_portal_addressable("03E8FC7FDDC2"),
        is_portal_addressable("03E9FC7FDDC2"),
        is_portal_addressable("0428FC7FDDC2"),
        not is_portal_addressable("0429239D7F56"),
    ])

    clear_row = {"weather_is_stormless": True}
    storm_row = {"weather_is_stormless": False}
    empty_system: dict[str, Any] = {}
    checks["clear_weather_filter"].extend([
        planet_matches(clear_row, empty_system, weather_clear=True),
        not planet_matches(storm_row, empty_system, weather_clear=True),
        planet_matches(storm_row, empty_system, weather_clear=False),
        not planet_matches(clear_row, empty_system, weather_clear=False),
    ])

    weather_values = weather_family_filter_values()
    checks["exact_weather_family_catalog"].extend([
        len(weather_values) == 27,
        all(value.startswith("WEATHER_") for value in weather_values),
        "WEATHER_LUSH_CLEAR" in weather_values,
        "CLEAR" not in weather_values,
        "EXTREME" not in weather_values,
    ])
    for legacy_token in ("CLEAR", "EXTREME"):
        try:
            normalize_weather_family_filter(legacy_token)
            checks["legacy_generic_weather_rejected"].append(False)
        except ValueError:
            checks["legacy_generic_weather_rejected"].append(True)

    metrics = {}
    for name, values in checks.items():
        metric = {
            "correct": sum(bool(value) for value in values),
            "total": len(values),
        }
        metric["exact"] = (
            metric["correct"] == metric["total"]
            and metric["total"] > 0
        )
        metrics[name] = metric
        if not metric["exact"]:
            failures.append({"metric": name, **metric})
    exact = not failures
    return {
        "status": (
            "PASS_NATIVE_PORTAL_OCCUPANCY_WEATHER_FILTER_V20E3"
            if exact
            else "ERROR_NATIVE_PORTAL_OCCUPANCY_WEATHER_FILTER_V20E3"
        ),
        "exact": exact,
        "metrics": metrics,
        "native_static": native_static,
        "weather_family_values": list(weather_values),
        "failures": failures,
        "claim_boundary": {
            "prediction_algorithm_changed": False,
            "native_legacy_predicate": "SSI < GeneratedLegacySystemCount",
            "legacy_control_region": "239D7F56",
            "legacy_control_count": 564,
            "legacy_control_band": "0x000-0x233",
            "legacy_control_first_invalid": "0x234",
            "purple_portal_band": "0x3E9-0x428",
            "purple_system_count": 64,
            "live_verified_purple_controls": [
                "03E8FC7FDDC2",
                "0428FC7FDDC2",
                "0429FC7FDDC2 rejected",
            ],
            "unmapped_gap_not_searchable": "0x300-0x3E8",
            "at_or_above_upper_rejection_not_searchable": "0x429-0xFFF",
            "semantic_clear_filter_uses_weather_is_stormless": True,
        },
    }


def run_planet_classification_filter_regression() -> dict[str, Any]:
    """Validate dropdown completeness and exact positive/negative matching."""
    values = planet_classification_filter_values()
    catalog_metric = {
        "correct": sum(bool(value and "%PLANETCLASS%" not in value) for value in values),
        "total": len(values),
    }
    corpus = load_json(SENTINEL_DIFFICULTY_REGRESSION_PATH)
    terminology = load_terminology_engine()
    rows = list(corpus.get("planet_rows", []))
    match_correct = 0
    match_total = 0
    coverage_correct = 0
    failures: list[dict[str, Any]] = []
    for index, source in enumerate(rows):
        row = dict(source)
        row.setdefault("description_token", row.get("planet_description_token", ""))
        row.setdefault("planet_type_token", row.get("planet_type_token", row.get("planet_type", "")))
        row.update(terminology.enrich_row(row, TERMINOLOGY_CATALOG_PATH))
        actual = str(row.get("planet_classification_display", ""))
        in_catalog = actual in values
        coverage_correct += int(in_catalog)
        if not in_catalog:
            failures.append({"row": index, "field": "catalog_coverage", "actual": actual})
        positive = planet_matches(row, {}, planet_classification=actual)
        different = next(value for value in values if value.casefold() != actual.casefold())
        negative = not planet_matches(row, {}, planet_classification=different)
        match_correct += int(positive) + int(negative)
        match_total += 2
        if not positive or not negative:
            failures.append({
                "row": index,
                "field": "exact_filter_match",
                "actual": actual,
                "different": different,
                "positive": positive,
                "negative": negative,
            })
    normalization_checks = [
        normalize_planet_classification_filter("Any planet type") is None,
        normalize_planet_classification_filter(values[0].swapcase()) == values[0],
    ]
    try:
        normalize_planet_classification_filter("NOT A REAL PLANET TYPE")
        normalization_checks.append(False)
    except ValueError:
        normalization_checks.append(True)
    metrics = {
        "classification_catalog": {
            **catalog_metric,
            "exact": catalog_metric["correct"] == catalog_metric["total"],
        },
        "classification_filter_match": {
            "correct": match_correct,
            "total": match_total,
            "exact": match_correct == match_total == 142,
        },
        "classification_catalog_coverage": {
            "correct": coverage_correct,
            "total": len(rows),
            "exact": coverage_correct == len(rows) == 71,
        },
        "classification_filter_normalization": {
            "correct": sum(normalization_checks),
            "total": len(normalization_checks),
            "exact": all(normalization_checks),
        },
    }
    return {
        "version": "19G.0.0",
        "status": (
            "PASS_EXACT_PLANET_CLASSIFICATION_FILTER_V19G"
            if all(metric["exact"] for metric in metrics.values()) and not failures
            else "ERROR_EXACT_PLANET_CLASSIFICATION_FILTER_V19G"
        ),
        "exact": all(metric["exact"] for metric in metrics.values()) and not failures,
        "metrics": metrics,
        "failures": failures,
        "claim_boundary": {
            "exact_current_game_dropdown_values": True,
            "planet_and_moon_classifications_separate": True,
            "exact_equality_filter": True,
            "prediction_logic_changed": True,
        },
    }


def build_match_reasons(
    row: dict[str, Any],
    system: dict[str, Any],
    filters: dict[str, Any],
) -> list[str]:
    """Return concise, user-facing reasons for a successful finder match."""
    reasons: list[str] = []
    bool_labels = (
        ("literal_paradise", "literal_paradise", "Paradise", "Not Paradise"),
        ("lush_biome", None, "Lush biome", "Non-lush biome"),
        ("water_active", "water_active", "Water present", "No water"),
        ("weather_extreme", "is_weather_extreme", "Extreme weather", "Non-extreme weather"),
        ("weather_clear", "weather_is_stormless", "No storms", "Storms or special weather"),
        ("in_empty_system", "in_empty_system", "Empty system", "Not an empty system"),
        ("in_abandoned_system", "in_abandoned_system", "Abandoned system", "Not an abandoned system"),
        ("in_gas_giant_system", "in_gas_giant_system", "Gas-giant system", "Not a gas-giant system"),
        ("in_pirate_system", "in_pirate_system", "Pirate system", "Not a pirate system"),
        ("infested", "infested_planet", "Infested planet", "Not infested"),
        ("dissonant", "portal_safe_dissonant_planet", "Corrupt Sentinel state", "No corrupt Sentinel state"),
        ("grass_assets", "explicit_grass_asset_available", "Generated grass assets", "No generated grass assets"),
        ("glowing_grass", "glowing_grass_asset_available", "Bioluminescent Bubble Grass asset", "No Bioluminescent Bubble Grass asset"),
        ("mushroom_flora", "mushroom_asset_available", "Major mushroom-style flora set", "No major mushroom-style flora set"),
        ("glowing_mushroom", "glowing_mushroom_asset_available", "Large glowing mushroom trees", "No large glowing mushroom trees"),
        ("salvageable_scrap", "salvageable_scrap_available", "Salvageable Scrap", "No Salvageable Scrap"),
    )
    for filter_key, row_key, positive, negative in bool_labels:
        requested = filters.get(filter_key)
        if requested is None:
            continue
        if filter_key == "lush_biome":
            actual = int(row.get("biome", -1)) == 0
        else:
            actual = bool(row.get(row_key, False))
        reasons.append(positive if actual else negative)

    scalar_labels = (
        ("planet_classification", "Planet type", row.get("planet_classification_display")),
        ("biome", "Biome", row.get("biome_name")),
        ("biome_variant", "Subbiome", row.get("biome_variant_display")),
        ("terrain_setting", "Terrain type", row.get("terrain_family_display")),
        ("functional_storm_frequency", "Storm frequency", row.get("weather_storm_frequency")),
        ("passive_hazard", "Passive environmental condition", row.get("weather_passive_hazard")),
        ("passive_hazard_boundary", "Passive-condition confidence", row.get("weather_passive_hazard_boundary")),
        ("star_colour", "Star", system.get("colour")),
        ("resource_level", "Resources", row.get("resources_display", row.get("resource_abundance"))),
        ("fauna_level", "Fauna", row.get("fauna_display", row.get("fauna_abundance"))),
        ("flora_level", "Flora", row.get("flora_display", row.get("flora_abundance"))),
        ("max_sentinel", "Sentinel level", row.get("sentinel_level")),
        ("grass_colour", "Generated Grass surface/flora palette—not Bubble glow", row.get("grass_colour_summary")),
        ("grass_alt_colour", "Generated GrassAlt surface/flora palette—not Bubble glow", row.get("grass_alt_colour_summary")),
        ("day_atmosphere", "Rendered day-sky colour", row.get("day_atmosphere_display")),
        ("sky_palette_colour", "Sky palette", row.get("atmosphere_sky_summary")),
        ("sunset_palette_colour", "Sunset palette", row.get("atmosphere_sunset_summary")),
        ("night_palette_colour", "Night palette", row.get("atmosphere_night_summary")),
        ("cloud_palette_colour", "Cloud palette", row.get("atmosphere_cloud_summary")),
        (
            "either_grass_colour",
            "Any generated surface/flora palette slot—not Bubble glow",
            str(filters.get("either_grass_colour") or ""),
        ),
    )
    for key, label, shown in scalar_labels:
        if filters.get(key) is not None:
            reasons.append(f"{label}: {shown}")

    if filters.get("high_water") is not None:
        reasons.append(
            "High-water terrain: "
            + ("required" if filters["high_water"] else "confirmed absent")
        )
    if filters.get("world_size"):
        reasons.append(f"World Size: {filters['world_size']}")
    if filters.get("native_size_class") is not None:
        reasons.append(f"Exact native size class: {filters['native_size_class']}")
    if filters.get("moon_parent"):
        reasons.append(f"Moon parent body: {filters['moon_parent']}")
    if filters.get("moon_count") is not None:
        reasons.append(f"Moon count: {filters['moon_count']}")
    if filters.get("ocean_type"):
        suffix = " (allow impossible bodies)" if filters.get("allow_ocean_impossible") else ""
        reasons.append(f"Ocean type: {filters['ocean_type']}{suffix}")
    if filters.get("terrain_record") is not None:
        reasons.append(f"Internal terrain-control record: {filters['terrain_record']}")
    if filters.get("ringed") is not None:
        reasons.append(
            "Rings" if bool(row.get("has_rings")) else "No rings"
        )
    if filters.get("biome_variant_include_any"):
        reasons.append(
            "Subbiome in allowed list: "
            + ", ".join(filters["biome_variant_include_any"])
        )
    if filters.get("biome_variant_exclude_any"):
        reasons.append(
            "Subbiome not in excluded list: "
            + ", ".join(filters["biome_variant_exclude_any"])
        )
    if filters.get("biome_source_contains"):
        reasons.append(f"Biome source contains: {filters['biome_source_contains']}")
    if filters.get("fauna_profile_text"):
        reasons.append(f"Fauna profile contains: {filters['fauna_profile_text']}")
    if filters.get("fauna_archetype_signal"):
        reasons.append(f"Archetype signal: {filters['fauna_archetype_signal']}")
    if filters.get("native_sentinel_difficulty") is not None:
        difficulty = int(filters["native_sentinel_difficulty"])
        names = list(row.get("sentinel_difficulty_names", []))
        if len(names) == 4:
            reasons.append(f"Sentinel D{difficulty}: {names[difficulty]}")
    selector_bypass = bool(filters.get("allow_unavailable_system_data"))
    selector_unavailable = bool(system.get("system_selector_data_unavailable"))
    if filters.get("economy_type"):
        reasons.append(
            "Economy filter bypassed — data unavailable"
            if selector_bypass and selector_unavailable
            else f"Economy: {system.get('economy_type_display', '')}"
        )
    if filters.get("economy_tier"):
        reasons.append(
            "Economy-tier filter bypassed — data unavailable"
            if selector_bypass and selector_unavailable
            else f"Economy tier: {system.get('economy_tier_star_display', '')}"
        )
    if filters.get("conflict_level"):
        reasons.append(
            "Conflict filter bypassed — data unavailable"
            if selector_bypass and selector_unavailable
            else f"Conflict: {system.get('conflict_level_display', '')}"
        )
    if filters.get("dominant_race"):
        reasons.append(
            "Dominant-race filter bypassed — data unavailable"
            if selector_bypass and selector_unavailable
            else f"Dominant race: {system.get('dominant_race_display', '')}"
        )
    if filters.get("generated_water_colour"):
        reasons.append(f"Generated Water palette: {filters['generated_water_colour']}")
    if filters.get("deep_water_biolum_colour"):
        reasons.append(f"Deep-water biolum palette: {filters['deep_water_biolum_colour']}")
    return reasons or ["No restrictive filters — regional result"]


def planet_matches(
    row: dict[str, Any],
    system: dict[str, Any],
    *,
    paradise: bool = False,
    lush: bool = False,
    water: bool = False,
    non_extreme: bool = False,
    max_sentinel: int | None = None,
    biome: int | None = None,
    star_colour: str | None = None,
    description_family: str | None = None,
    weather_family: str | None = None,
    resource_level: int | None = None,
    common_substance: str | None = None,
    uncommon_substance: str | None = None,
    rare_substance: str | None = None,
    fauna_level: int | None = None,
    flora_level: int | None = None,
    in_empty_system: bool | None = None,
    in_abandoned_system: bool | None = None,
    in_gas_giant_system: bool | None = None,
    in_pirate_system: bool | None = None,
    infested: bool | None = None,
    dissonant: bool | None = None,
    native_sentinel_difficulty: int | None = None,
    native_sentinel_enum: int | None = None,
    literal_paradise: bool | None = None,
    lush_biome: bool | None = None,
    water_active: bool | None = None,
    high_water: bool | None = None,
    world_size: str | None = None,
    native_size_class: int | str | None = None,
    moon_parent: str | None = None,
    moon_parent_rings: str | bool | None = None,
    moon_count: int | str | None = None,
    ocean_type: str | None = None,
    allow_ocean_impossible: bool = False,
    terrain_record: int | str | None = None,
    terrain_setting: str | None = None,
    ringed: bool | None = None,
    weather_extreme: bool | None = None,
    weather_clear: bool | None = None,
    biome_variant: str | None = None,
    biome_variant_include_any: tuple[str, ...] = (),
    biome_variant_exclude_any: tuple[str, ...] = (),
    biome_source_contains: str | None = None,
    functional_storm_frequency: str | None = None,
    passive_hazard: str | None = None,
    fauna_profile_text: str | None = None,
    fauna_archetype_signal: str | None = None,
    planet_classification: str | None = None,
    grass_assets: bool | None = None,
    glowing_grass: bool | None = None,
    mushroom_flora: bool | None = None,
    glowing_mushroom: bool | None = None,
    salvageable_scrap: bool | None = None,
    grass_colour: str | None = None,
    grass_alt_colour: str | None = None,
    either_grass_colour: str | None = None,
    day_atmosphere: str | None = None,
    sky_palette_colour: str | None = None,
    sunset_palette_colour: str | None = None,
    night_palette_colour: str | None = None,
    cloud_palette_colour: str | None = None,
    economy_type: str | None = None,
    economy_tier: str | None = None,
    conflict_level: str | None = None,
    dominant_race: str | None = None,
    dominant_race_include_any: str | Iterable[str] | None = None,
    dominant_race_exclude_any: str | Iterable[str] | None = None,
    allow_unavailable_system_data: bool = False,
    generated_water_colour: str | None = None,
    deep_water_biolum_colour: str | None = None,
) -> bool:
    if paradise and not row["literal_paradise"]:
        return False
    if lush and int(row.get("effective_biome", row["biome"])) != 0:
        return False
    if water and not row["water_active"]:
        return False
    if non_extreme and row["is_weather_extreme"]:
        return False
    if (
        literal_paradise is not None
        and bool(row.get("literal_paradise")) != bool(literal_paradise)
    ):
        return False
    if (
        lush_biome is not None
        and (int(row.get("effective_biome", row.get("biome", -1))) == 0) != bool(lush_biome)
    ):
        return False
    if (
        water_active is not None
        and bool(row.get("water_active")) != bool(water_active)
    ):
        return False
    if high_water is not None and bool(row.get("high_water")) != bool(high_water):
        return False
    if not world_size_filter_matches(row, world_size):
        return False
    native_size = normalize_native_size_class_filter(native_size_class)
    if native_size is not None and int(row.get("planet_size", -1)) != native_size:
        return False
    parent_filter = normalize_moon_parent_filter(moon_parent)
    if parent_filter == "Any moon (any parent)":
        if not bool(row.get("is_moon")):
            return False
    elif parent_filter is not None and str(row.get("moon_parent_body_type", "")) != parent_filter:
        return False
    parent_ring_filter = normalize_moon_parent_ring_filter(moon_parent_rings)
    if parent_ring_filter is not None:
        if not bool(row.get("is_moon")) or not bool(row.get("moon_parent_ring_prediction_exact")):
            return False
        if bool(row.get("moon_parent_has_rings")) != parent_ring_filter:
            return False
    moon_count_number = normalize_moon_count_filter(moon_count)
    if moon_count_number == "at_least_1":
        if int(row.get("moon_count", 0)) < 1:
            return False
    elif moon_count_number is not None and int(row.get("moon_count", 0)) != moon_count_number:
        return False
    if not ocean_type_filter_matches(
        row, ocean_type, allow_impossible=bool(allow_ocean_impossible)
    ):
        return False
    terrain_record_number = normalize_terrain_record_filter(terrain_record)
    if (
        terrain_record_number is not None
        and int(row.get("terrain_record_index", -1)) != terrain_record_number
    ):
        return False
    terrain_setting_filter = normalize_terrain_setting_filter(terrain_setting)
    if (
        terrain_setting_filter is not None
        and str(row.get("terrain_family_display", "")).casefold()
        != terrain_setting_filter.casefold()
    ):
        return False
    if (
        ringed is not None
        and bool(row.get("has_rings")) != bool(ringed)
    ):
        return False
    if (
        weather_extreme is not None
        and bool(row.get("weather_is_extreme_hazard")) != bool(weather_extreme)
    ):
        return False
    if (
        weather_clear is not None
        and bool(row.get("weather_is_stormless")) != bool(weather_clear)
    ):
        return False
    if (
        planet_classification is not None
        and str(row.get("planet_classification_display", "")).casefold()
        != str(planet_classification).casefold()
    ):
        return False
    if not _text_contains(
        row.get("fauna_descriptor_profile_summary", ""),
        fauna_profile_text,
    ):
        return False
    if fauna_archetype_signal:
        query = str(fauna_archetype_signal).strip().casefold()
        names = [
            str(value).casefold()
            for value in row.get("fauna_community_archetype_signals", [])
        ]
        ids = [
            str(value).replace("_", " ").casefold()
            for value in row.get("fauna_community_archetype_signal_ids", [])
        ]
        if not any(query in value for value in names + ids):
            return False
    if (
        max_sentinel is not None
        and int(row["sentinel_level"]) > int(max_sentinel)
    ):
        return False
    if biome is not None and int(row.get("effective_biome", row["biome"])) != int(biome):
        return False
    row_variant = str(row.get("biome_variant_display", "")).casefold()
    row_variant_labels = {
        str(value).casefold()
        for value in row.get("biome_variant_filter_labels", [row_variant])
    }
    row_variant_labels.add(row_variant)
    if (
        biome_variant is not None
        and str(biome_variant).casefold() not in row_variant_labels
    ):
        return False
    if biome_variant_include_any and not row_variant_labels.intersection({
        str(value).casefold() for value in biome_variant_include_any
    }):
        return False
    if biome_variant_exclude_any and row_variant_labels.intersection({
        str(value).casefold() for value in biome_variant_exclude_any
    }):
        return False
    if biome_source_contains and str(biome_source_contains).casefold() not in str(
        row.get("surface_biome_source_file", "")
    ).casefold():
        return False
    if functional_storm_frequency is not None and str(
        row.get("weather_storm_frequency", "")
    ).casefold() != str(functional_storm_frequency).casefold():
        return False
    if passive_hazard is not None:
        requested_passive = str(passive_hazard).strip()
        if requested_passive == "Any standard hazard":
            if not bool(row.get("weather_has_standard_passive_hazard")):
                return False
        elif str(row.get("weather_passive_hazard", "")).casefold() != requested_passive.casefold():
            # An unresolved Barren branch must not be returned as an exact Heat
            # or Nightly-cold match. The aggregate option can include it safely.
            return False
    if star_colour and str(system["colour"]).casefold() != (
        str(star_colour).casefold()
    ):
        return False
    selector_data_unavailable = bool(
        system.get("system_selector_data_unavailable")
        or system.get("in_empty_system")
        or system.get("in_abandoned_system")
    )

    def selector_filter_matches(
        requested: str | None,
        *,
        exact_key: str,
        internal_key: str,
    ) -> bool:
        if requested is None:
            return True
        if not bool(system.get(exact_key)):
            return bool(allow_unavailable_system_data and selector_data_unavailable)
        return str(system.get(internal_key, "")).casefold() == requested.casefold()

    requested_economy = normalize_economy_type_filter(economy_type)
    if not selector_filter_matches(
        requested_economy,
        exact_key="economy_type_exact",
        internal_key="economy_type_internal",
    ):
        return False
    requested_tier = normalize_economy_tier_filter(economy_tier)
    if requested_tier == ECONOMY_TIER_AT_LEAST_MEDIUM:
        if not bool(system.get("economy_tier_exact")):
            if not bool(allow_unavailable_system_data and selector_data_unavailable):
                return False
        elif str(system.get("economy_tier_internal", "")).casefold() not in {
            "medium", "high"
        }:
            return False
    elif not selector_filter_matches(
        requested_tier,
        exact_key="economy_tier_exact",
        internal_key="economy_tier_internal",
    ):
        return False
    requested_conflict = normalize_conflict_level_filter(conflict_level)
    if requested_conflict == CONFLICT_LEVEL_AT_MOST_MEDIUM:
        if not bool(system.get("conflict_level_exact")):
            if not bool(allow_unavailable_system_data and selector_data_unavailable):
                return False
        elif str(system.get("conflict_level_internal", "")).casefold() not in {
            "low", "medium"
        }:
            return False
    elif not selector_filter_matches(
        requested_conflict,
        exact_key="conflict_level_exact",
        internal_key="conflict_level_internal",
    ):
        return False
    requested_race = normalize_dominant_race_filter(dominant_race)
    include_races = normalize_dominant_race_list_filter(dominant_race_include_any)
    exclude_races = normalize_dominant_race_list_filter(dominant_race_exclude_any)
    if requested_race and requested_race not in include_races:
        include_races = (*include_races, requested_race)
    overlap_races = set(include_races) & set(exclude_races)
    if overlap_races:
        raise ValueError("Dominant races cannot be both allowed and excluded: " + ", ".join(sorted(overlap_races)))
    race_exact = bool(system.get("dominant_race_exact"))
    race_value = str(system.get("dominant_race_internal", ""))
    if include_races:
        if not race_exact:
            if not bool(allow_unavailable_system_data and selector_data_unavailable):
                return False
        elif race_value not in include_races:
            return False
    if exclude_races:
        if not race_exact:
            if not bool(allow_unavailable_system_data and selector_data_unavailable):
                return False
        elif race_value in exclude_races:
            return False
    if description_family and str(
        row.get("description_family", "")
    ).casefold() != str(description_family).casefold():
        return False
    if weather_family and str(
        row.get("weather_family", "")
    ).casefold() != str(weather_family).casefold():
        return False
    if (
        resource_level is not None
        and int(row.get("resource_level", -1)) != int(resource_level)
    ):
        return False
    common_filter = normalize_substance_filter(common_substance)
    uncommon_filter = normalize_substance_filter(uncommon_substance)
    rare_filter = normalize_substance_filter(rare_substance)
    if common_filter and str(row.get("common_substance_id", "")).upper() != common_filter:
        return False
    if uncommon_filter and str(row.get("uncommon_substance_id", "")).upper() != uncommon_filter:
        return False
    if rare_filter and str(row.get("rare_substance_id", "")).upper() != rare_filter:
        return False
    if (
        fauna_level is not None
        and int(row.get("fauna_level", -1)) != int(fauna_level)
    ):
        return False
    if (
        flora_level is not None
        and int(row.get("flora_level", -1)) != int(flora_level)
    ):
        return False
    if (
        in_empty_system is not None
        and bool(row.get("in_empty_system"))
        != bool(in_empty_system)
    ):
        return False
    if (
        in_abandoned_system is not None
        and bool(row.get("in_abandoned_system"))
        != bool(in_abandoned_system)
    ):
        return False
    if (
        in_gas_giant_system is not None
        and bool(row.get("in_gas_giant_system"))
        != bool(in_gas_giant_system)
    ):
        return False
    if (
        in_pirate_system is not None
        and bool(row.get("in_pirate_system"))
        != bool(in_pirate_system)
    ):
        return False
    if (
        infested is not None
        and bool(row.get("infested_planet")) != bool(infested)
    ):
        return False
    if (
        dissonant is not None
        and is_portal_safe_dissonant(row) != bool(dissonant)
    ):
        return False
    if (
        grass_assets is not None
        and bool(row.get("explicit_grass_asset_available"))
        != bool(grass_assets)
    ):
        return False
    if (
        glowing_grass is not None
        and bool(row.get("glowing_grass_asset_available"))
        != bool(glowing_grass)
    ):
        return False
    if (
        mushroom_flora is not None
        and bool(row.get("mushroom_asset_available"))
        != bool(mushroom_flora)
    ):
        return False
    if (
        glowing_mushroom is not None
        and bool(row.get("glowing_mushroom_asset_available"))
        != bool(glowing_mushroom)
    ):
        return False

    if (
        salvageable_scrap is not None
        and bool(row.get("salvageable_scrap_available", row.get("has_scrap")))
        != bool(salvageable_scrap)
    ):
        return False

    normalized_grass_colour = normalize_grass_colour_filter(grass_colour)
    if normalized_grass_colour is not None:
        if normalized_grass_colour.startswith("#"):
            if str(row.get("grass_primary_hex", "")).upper() != normalized_grass_colour:
                return False
        elif str(row.get("grass_primary_colour_family", "")).casefold() != (
            normalized_grass_colour.casefold()
        ):
            return False

    normalized_grass_alt_colour = normalize_grass_colour_filter(
        grass_alt_colour
    )
    if normalized_grass_alt_colour is not None:
        if normalized_grass_alt_colour.startswith("#"):
            if str(row.get("grass_alt_primary_hex", "")).upper() != (
                normalized_grass_alt_colour
            ):
                return False
        elif str(row.get("grass_alt_primary_colour_family", "")).casefold() != (
            normalized_grass_alt_colour.casefold()
        ):
            return False

    normalized_either_grass_colour = normalize_grass_colour_filter(
        either_grass_colour
    )
    if normalized_either_grass_colour is not None:
        generated_colours = [
            *list(row.get("grass_palette_colours", [])),
            *list(row.get("grass_alt_palette_colours", [])),
        ]
        if not generated_colours:
            generated_colours = [
                {
                    "hex": row.get("grass_primary_hex", ""),
                    "colour_family": row.get(
                        "grass_primary_colour_family", ""
                    ),
                },
                {
                    "hex": row.get("grass_alt_primary_hex", ""),
                    "colour_family": row.get(
                        "grass_alt_primary_colour_family", ""
                    ),
                },
            ]
        if normalized_either_grass_colour.startswith("#"):
            values = {
                str(item.get("hex", "")).upper()
                for item in generated_colours
            }
            if normalized_either_grass_colour not in values:
                return False
        else:
            values = {
                str(item.get("colour_family", "")).casefold()
                for item in generated_colours
            }
            if normalized_either_grass_colour.casefold() not in values:
                return False

    normalized_day_atmosphere = normalize_day_atmosphere_filter(day_atmosphere)
    if normalized_day_atmosphere is not None and str(
        row.get("day_atmosphere_category", "")
    ).casefold() != normalized_day_atmosphere.casefold():
        return False
    if not atmosphere_palette_matches(row, "sky", sky_palette_colour):
        return False
    if not atmosphere_palette_matches(row, "sunset", sunset_palette_colour):
        return False
    if not atmosphere_palette_matches(row, "night", night_palette_colour):
        return False
    if not atmosphere_palette_matches(row, "cloud", cloud_palette_colour):
        return False
    if not generated_water_palette_matches(
        row, "generated_water_palette_colours", generated_water_colour
    ):
        return False
    if not generated_water_palette_matches(
        row, "deep_water_biolum_palette_colours", deep_water_biolum_colour
    ):
        return False

    if native_sentinel_difficulty is not None:
        difficulty = int(native_sentinel_difficulty)
        if difficulty not in (0, 1, 2, 3):
            raise ValueError("Native Sentinel difficulty must be 0, 1, 2 or 3.")
        pattern = list(row.get("sentinel_difficulty_enums", []))
        if len(pattern) != 4:
            return False
        if native_sentinel_enum is not None:
            requested_enum = int(native_sentinel_enum)
            if requested_enum not in (0, 1, 2, 3):
                raise ValueError("Native Sentinel enum must be 0, 1, 2 or 3.")
            if int(pattern[difficulty]) != requested_enum:
                return False
    elif native_sentinel_enum is not None:
        raise ValueError(
            "native_sentinel_enum requires native_sentinel_difficulty."
        )
    return True


def _percentage_rows(counter: Counter[str], total: int) -> list[dict[str, Any]]:
    return [
        {
            "value": value,
            "count": int(count),
            "percentage": round((100.0 * int(count) / total), 4) if total else 0.0,
        }
        for value, count in sorted(counter.items(), key=lambda item: (-item[1], item[0].casefold()))
    ]


def new_scan_statistics_accumulator() -> dict[str, Any]:
    return {
        "systems_scanned": 0,
        "planets_scanned": 0,
        "system_state": Counter(),
        "economy_type": Counter(),
        "economy_tier": Counter(),
        "conflict_level": Counter(),
        "dominant_race": Counter(),
        "sentinel_by_difficulty": [Counter() for _ in range(4)],
        "unavailable_system_selector_rows": 0,
    }


def update_scan_statistics(acc: dict[str, Any], prediction: dict[str, Any]) -> None:
    system = dict(prediction.get("system", {}))
    rows = list(prediction.get("planet_rows", []))
    acc["systems_scanned"] += 1
    acc["planets_scanned"] += len(rows)
    acc["system_state"][str(system.get("system_state_display", "Unknown"))] += 1
    for key in ("economy_type", "economy_tier", "conflict_level", "dominant_race"):
        display_key = key + "_display"
        acc[key][str(system.get(display_key, "Data unavailable"))] += 1
    if bool(system.get("system_selector_data_unavailable")):
        acc["unavailable_system_selector_rows"] += 1
    for row in rows:
        labels = list(row.get("sentinel_activity_display_names", []))
        if len(labels) != 4:
            labels = [
                SENTINEL_ACTIVITY_DISPLAY_NAMES.get(int(value), "Unknown")
                for value in list(row.get("sentinel_difficulty_enums", []))[:4]
            ]
        for index in range(4):
            label = str(labels[index] if index < len(labels) else "Unknown")
            acc["sentinel_by_difficulty"][index][label] += 1


def finalise_scan_statistics(acc: dict[str, Any]) -> dict[str, Any]:
    systems = int(acc["systems_scanned"])
    planets = int(acc["planets_scanned"])
    return {
        "scope": "all systems and planets actually generated before planet-match filters",
        "systems_scanned": systems,
        "planets_scanned": planets,
        "system_state": _percentage_rows(acc["system_state"], systems),
        "economy_type": _percentage_rows(acc["economy_type"], systems),
        "economy_tier": _percentage_rows(acc["economy_tier"], systems),
        "conflict_level": _percentage_rows(acc["conflict_level"], systems),
        "dominant_race": _percentage_rows(acc["dominant_race"], systems),
        "sentinel_by_difficulty": {
            ON_FOOT_COMBAT_DIFFICULTY_NAMES[index]: _percentage_rows(counter, planets)
            for index, counter in enumerate(acc["sentinel_by_difficulty"])
        },
        "unavailable_system_selector_rows": int(acc["unavailable_system_selector_rows"]),
    }


def merge_scan_statistics_payload(acc: dict[str, Any], payload: dict[str, Any]) -> None:
    acc["systems_scanned"] += int(payload.get("systems_scanned", 0))
    acc["planets_scanned"] += int(payload.get("planets_scanned", 0))
    for key in ("system_state", "economy_type", "economy_tier", "conflict_level", "dominant_race"):
        for item in payload.get(key, []):
            acc[key][str(item.get("value", "Unknown"))] += int(item.get("count", 0))
    by_diff = dict(payload.get("sentinel_by_difficulty", {}))
    for index, name in ON_FOOT_COMBAT_DIFFICULTY_NAMES.items():
        for item in by_diff.get(name, []):
            acc["sentinel_by_difficulty"][index][str(item.get("value", "Unknown"))] += int(item.get("count", 0))
    acc["unavailable_system_selector_rows"] += int(payload.get("unavailable_system_selector_rows", 0))


def find_planets(
    *,
    anchor_portal: str,
    galaxy: int = 0,
    start_system: int = 0,
    system_count: int = 64,
    result_limit: int = 25,
    search_domain: str = FINDER_SEARCH_DOMAIN_PORTAL,
    paradise: bool = False,
    lush: bool = False,
    water: bool = False,
    non_extreme: bool = False,
    max_sentinel: int | None = None,
    biome: str | int | None = None,
    star_colour: str | None = None,
    description_family: str | None = None,
    weather_family: str | None = None,
    resource_level: int | None = None,
    common_substance: str | None = None,
    uncommon_substance: str | None = None,
    rare_substance: str | None = None,
    fauna_level: int | None = None,
    flora_level: int | None = None,
    in_empty_system: bool | None = None,
    in_abandoned_system: bool | None = None,
    in_gas_giant_system: bool | None = None,
    in_pirate_system: bool | None = None,
    infested: bool | None = None,
    dissonant: bool | None = None,
    native_sentinel_difficulty: int | None = None,
    native_sentinel_enum: int | None = None,
    literal_paradise: bool | None = None,
    lush_biome: bool | None = None,
    water_active: bool | None = None,
    high_water: bool | None = None,
    world_size: str | None = None,
    native_size_class: int | str | None = None,
    moon_parent: str | None = None,
    moon_parent_rings: str | bool | None = None,
    moon_count: int | str | None = None,
    ocean_type: str | None = None,
    allow_ocean_impossible: bool = False,
    terrain_record: int | str | None = None,
    terrain_setting: str | None = None,
    ringed: bool | None = None,
    weather_extreme: bool | None = None,
    weather_clear: bool | None = None,
    biome_variant: str | None = None,
    biome_variant_include_any: tuple[str, ...] = (),
    biome_variant_exclude_any: tuple[str, ...] = (),
    biome_source_contains: str | None = None,
    functional_storm_frequency: str | None = None,
    passive_hazard: str | None = None,
    fauna_profile_text: str | None = None,
    fauna_archetype_signal: str | None = None,
    planet_classification: str | None = None,
    grass_assets: bool | None = None,
    glowing_grass: bool | None = None,
    mushroom_flora: bool | None = None,
    glowing_mushroom: bool | None = None,
    salvageable_scrap: bool | None = None,
    grass_colour: str | None = None,
    grass_alt_colour: str | None = None,
    either_grass_colour: str | None = None,
    day_atmosphere: str | None = None,
    sky_palette_colour: str | None = None,
    sunset_palette_colour: str | None = None,
    night_palette_colour: str | None = None,
    cloud_palette_colour: str | None = None,
    economy_type: str | None = None,
    economy_tier: str | None = None,
    conflict_level: str | None = None,
    dominant_race: str | None = None,
    dominant_race_include_any: str | Iterable[str] | None = None,
    dominant_race_exclude_any: str | Iterable[str] | None = None,
    allow_unavailable_system_data: bool = False,
    generated_water_colour: str | None = None,
    deep_water_biolum_colour: str | None = None,
    system_workers: int | str | None = 1,
    progress: Callable[[int, int, str], None] | None = None,
    cancel: Callable[[], bool] | None = None,
    pause: Callable[[], bool] | None = None,
    match_callback: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    canonical = normalize_portal(anchor_portal)
    galaxy_index = normalize_internal_galaxy_index(galaxy)
    galaxy_info = galaxy_metadata(galaxy_index)
    domain = normalize_finder_search_domain(search_domain)
    native_occupancy: dict[str, Any] | None = None
    native_legacy_count: int | None = None
    if domain == FINDER_SEARCH_DOMAIN_PORTAL:
        if progress:
            progress(
                0,
                1,
                f"Resolving native legacy occupancy for {portal_region_suffix(canonical)}",
            )
        native_occupancy = native_legacy_system_count_metadata(
            canonical,
            galaxy_index,
            allow_replay=True,
        )
        if not native_occupancy.get("resolved"):
            raise RuntimeError(
                "Native legacy-system count did not resolve for the anchor region."
            )
        native_legacy_count = int(
            native_occupancy["generated_legacy_system_count"]
        )
        domain_minimum, domain_maximum, domain_capacity = (
            LEGACY_SYSTEM_INDEX_MIN,
            native_legacy_count - 1,
            native_legacy_count,
        )
    else:
        domain_minimum, domain_maximum, domain_capacity = finder_system_range_bounds(
            domain
        )
    validated_start, validated_count = validate_finder_system_range(
        start_system,
        system_count,
        domain,
        anchor_portal=canonical,
        galaxy=galaxy_index,
        native_legacy_count=native_legacy_count,
    )
    if int(result_limit) < 1:
        raise ValueError("Result limit must be positive.")

    biome_number = normalize_biome_filter(biome)
    classification_filter = normalize_planet_classification_filter(planet_classification)
    world_size_filter = normalize_world_size_filter(world_size)
    native_size_class_filter = normalize_native_size_class_filter(native_size_class)
    moon_parent_filter = normalize_moon_parent_filter(moon_parent)
    moon_parent_ring_filter = normalize_moon_parent_ring_filter(moon_parent_rings)
    moon_count_filter = normalize_moon_count_filter(moon_count)
    ocean_type_filter = normalize_ocean_type_filter(ocean_type)
    terrain_record_filter = normalize_terrain_record_filter(terrain_record)
    terrain_setting_filter = normalize_terrain_setting_filter(terrain_setting)
    validate_filter_compatibility(
        search_domain=domain, biome=biome_number, star_colour=star_colour,
        world_size=world_size_filter, native_size_class=native_size_class_filter,
        moon_parent=moon_parent_filter, moon_count=moon_count_filter,
        in_empty_system=in_empty_system,
        in_abandoned_system=in_abandoned_system,
        in_gas_giant_system=in_gas_giant_system,
    )
    weather_family_filter = normalize_weather_family_filter(weather_family)
    biome_variant_filter = normalize_biome_variant_filter(biome_variant)
    biome_variant_include_filter = normalize_biome_variant_list_filter(
        biome_variant_include_any
    )
    biome_variant_exclude_filter = normalize_biome_variant_list_filter(
        biome_variant_exclude_any
    )
    requested_biome_variants = tuple(
        value for value in (biome_variant_filter, *biome_variant_include_filter)
        if value
    )
    if (
        domain != FINDER_SEARCH_DOMAIN_PURPLE
        and biome_number in {1, 3, 4, 12}
        and any(
            split_prefixed_biome_variant(value)[1].casefold()
            == "floating islands (subbiome)"
            for value in requested_biome_variants
        )
    ):
        raise ValueError(
            "The Toxic, Radioactive, Frozen and Swamp / Marsh Floating Islands "
            "subbiomes are exclusive to the purple-system search domain."
        )
    overlap = sorted(
        set(biome_variant_include_filter)
        & set(biome_variant_exclude_filter),
        key=str.casefold,
    )
    if overlap:
        raise ValueError(
            "Subbiomes cannot be both included and excluded: "
            + ", ".join(overlap)
        )
    storm_frequency_filter = (
        str(functional_storm_frequency).strip()
        if functional_storm_frequency else None
    )
    if storm_frequency_filter and storm_frequency_filter not in FUNCTIONAL_STORM_FREQUENCY_VALUES:
        raise ValueError(
            "Functional storm frequency must be one of: "
            + ", ".join(FUNCTIONAL_STORM_FREQUENCY_VALUES)
        )
    passive_hazard_filter = str(passive_hazard).strip() if passive_hazard else None
    if passive_hazard_filter and passive_hazard_filter not in PASSIVE_HAZARD_VALUES:
        raise ValueError(
            "Passive hazard must be one of: " + ", ".join(PASSIVE_HAZARD_VALUES)
        )
    grass_colour_filter = normalize_grass_colour_filter(grass_colour)
    grass_alt_colour_filter = normalize_grass_colour_filter(grass_alt_colour)
    either_grass_colour_filter = normalize_grass_colour_filter(
        either_grass_colour
    )
    day_atmosphere_filter = normalize_day_atmosphere_filter(day_atmosphere)
    sky_palette_filter = normalize_atmosphere_palette_filter(sky_palette_colour)
    sunset_palette_filter = normalize_atmosphere_palette_filter(sunset_palette_colour)
    night_palette_filter = normalize_atmosphere_palette_filter(night_palette_colour)
    cloud_palette_filter = normalize_atmosphere_palette_filter(cloud_palette_colour)
    economy_type_filter = normalize_economy_type_filter(economy_type)
    economy_tier_filter = normalize_economy_tier_filter(economy_tier)
    conflict_level_filter = normalize_conflict_level_filter(conflict_level)
    dominant_race_filter = normalize_dominant_race_filter(dominant_race)
    dominant_race_include_filter = normalize_dominant_race_list_filter(dominant_race_include_any)
    dominant_race_exclude_filter = normalize_dominant_race_list_filter(dominant_race_exclude_any)
    if dominant_race_filter and dominant_race_filter not in dominant_race_include_filter:
        dominant_race_include_filter = (*dominant_race_include_filter, dominant_race_filter)
    race_overlap = set(dominant_race_include_filter) & set(dominant_race_exclude_filter)
    if race_overlap:
        raise ValueError("Dominant races cannot be both allowed and excluded: " + ", ".join(sorted(race_overlap)))
    generated_water_colour_filter = normalize_atmosphere_palette_filter(
        generated_water_colour
    )
    deep_water_biolum_colour_filter = normalize_atmosphere_palette_filter(
        deep_water_biolum_colour
    )
    matches: list[dict[str, Any]] = []
    statistics_accumulator = new_scan_statistics_accumulator()
    tested_systems = 0
    tested_planets = 0
    cancelled = False

    parallel_engine = load_parallel_system_engine()
    worker_request = normalize_system_worker_request(system_workers)
    prediction_tasks = [
        (
            offset,
            validated_start + offset,
            portal_with_addressable_system_index(
                canonical,
                validated_start + offset,
                native_legacy_count,
            ),
            galaxy_index,
        )
        for offset in range(validated_count)
    ]
    prediction_stream = parallel_engine.open_ordered_prediction_stream(
        prediction_tasks,
        app_dir=HERE,
        requested_workers=worker_request,
    )
    worker_resolution = dict(prediction_stream.resolution)

    try:
        for prediction_task in prediction_stream:
            while pause and bool(pause()):
                if cancel and bool(cancel()):
                    cancelled = True
                    break
                time.sleep(0.05)
            if cancelled:
                break
            if cancel and bool(cancel()):
                cancelled = True
                break
            offset = int(prediction_task["ordinal"])
            system_index = int(prediction_task["system_index"])
            portal = str(prediction_task["portal"])
            prediction = prediction_task["prediction"]
            if progress:
                progress(offset + 1, validated_count, portal)
            else:
                print(
                    f"SCAN_SYSTEM={offset + 1}/{validated_count} PORTAL={portal}",
                    flush=True,
                )
            tested_systems += 1
            tested_planets += len(prediction["planet_rows"])
            update_scan_statistics(statistics_accumulator, prediction)
            if cancel and bool(cancel()):
                cancelled = True
                break
            for row in prediction["planet_rows"]:
                if planet_matches(
                    row,
                    prediction["system"],
                    paradise=paradise,
                    lush=lush,
                    water=water,
                    non_extreme=non_extreme,
                    max_sentinel=max_sentinel,
                    biome=biome_number,
                    star_colour=star_colour,
                    description_family=description_family,
                    weather_family=weather_family_filter,
                    resource_level=resource_level,
                    common_substance=common_substance,
                    uncommon_substance=uncommon_substance,
                    rare_substance=rare_substance,
                    fauna_level=fauna_level,
                    flora_level=flora_level,
                    in_empty_system=in_empty_system,
                    in_abandoned_system=in_abandoned_system,
                    in_gas_giant_system=in_gas_giant_system,
                    in_pirate_system=in_pirate_system,
                    infested=infested,
                    dissonant=dissonant,
                    native_sentinel_difficulty=native_sentinel_difficulty,
                    native_sentinel_enum=native_sentinel_enum,
                    literal_paradise=literal_paradise,
                    lush_biome=lush_biome,
                    water_active=water_active,
                    high_water=high_water,
                    world_size=world_size_filter,
                    native_size_class=native_size_class_filter,
                    moon_parent=moon_parent_filter,
                    moon_parent_rings=moon_parent_ring_filter,
                    moon_count=moon_count_filter,
                    ocean_type=ocean_type_filter,
                    allow_ocean_impossible=bool(allow_ocean_impossible),
                    terrain_record=terrain_record_filter,
                    terrain_setting=terrain_setting_filter,
                    ringed=ringed,
                    weather_extreme=weather_extreme,
                    weather_clear=weather_clear,
                    biome_variant=biome_variant_filter,
                    biome_variant_include_any=biome_variant_include_filter,
                    biome_variant_exclude_any=biome_variant_exclude_filter,
                    biome_source_contains=biome_source_contains,
                    functional_storm_frequency=storm_frequency_filter,
                    passive_hazard=passive_hazard_filter,
                    fauna_profile_text=fauna_profile_text,
                    fauna_archetype_signal=fauna_archetype_signal,
                    planet_classification=classification_filter,
                    grass_assets=grass_assets,
                    glowing_grass=glowing_grass,
                    mushroom_flora=mushroom_flora,
                    glowing_mushroom=glowing_mushroom,
                    salvageable_scrap=salvageable_scrap,
                    grass_colour=grass_colour_filter,
                    grass_alt_colour=grass_alt_colour_filter,
                    either_grass_colour=either_grass_colour_filter,
                    day_atmosphere=day_atmosphere_filter,
                    sky_palette_colour=sky_palette_filter,
                    sunset_palette_colour=sunset_palette_filter,
                    night_palette_colour=night_palette_filter,
                    cloud_palette_colour=cloud_palette_filter,
                    economy_type=economy_type_filter,
                    economy_tier=economy_tier_filter,
                    conflict_level=conflict_level_filter,
                    dominant_race=dominant_race_filter,
                    dominant_race_include_any=dominant_race_include_filter,
                    dominant_race_exclude_any=dominant_race_exclude_filter,
                    allow_unavailable_system_data=bool(allow_unavailable_system_data),
                    generated_water_colour=generated_water_colour_filter,
                    deep_water_biolum_colour=deep_water_biolum_colour_filter,
                ):
                    structured_filters = {
                        "literal_paradise": literal_paradise,
                        "lush_biome": lush_biome,
                        "water_active": water_active,
                        "high_water": high_water,
                        "world_size": world_size_filter,
                        "native_size_class": native_size_class_filter,
                        "moon_parent": moon_parent_filter,
                        "moon_parent_rings": moon_parent_ring_filter,
                        "moon_count": moon_count_filter,
                        "ocean_type": ocean_type_filter,
                        "allow_ocean_impossible": bool(allow_ocean_impossible),
                        "terrain_record": terrain_record_filter,
                        "terrain_setting": terrain_setting_filter,
                        "ringed": ringed,
                        "weather_extreme": weather_extreme,
                        "weather_clear": weather_clear,
                        "biome_variant": biome_variant_filter,
                        "biome_variant_include_any": biome_variant_include_filter,
                        "biome_variant_exclude_any": biome_variant_exclude_filter,
                        "biome_source_contains": biome_source_contains,
                        "functional_storm_frequency": storm_frequency_filter,
                        "passive_hazard": passive_hazard_filter,
                        "max_sentinel": max_sentinel,
                        "biome": biome_number,
                        "star_colour": star_colour,
                        "resource_level": resource_level,
                        "fauna_level": fauna_level,
                        "flora_level": flora_level,
                        "in_empty_system": in_empty_system,
                        "in_abandoned_system": in_abandoned_system,
                        "in_gas_giant_system": in_gas_giant_system,
                        "in_pirate_system": in_pirate_system,
                        "infested": infested,
                        "dissonant": dissonant,
                        "fauna_profile_text": fauna_profile_text,
                        "fauna_archetype_signal": fauna_archetype_signal,
                        "planet_classification": classification_filter,
                        "grass_assets": grass_assets,
                        "glowing_grass": glowing_grass,
                        "mushroom_flora": mushroom_flora,
                        "glowing_mushroom": glowing_mushroom,
                        "salvageable_scrap": salvageable_scrap,
                        "grass_colour": grass_colour_filter,
                        "grass_alt_colour": grass_alt_colour_filter,
                        "either_grass_colour": either_grass_colour_filter,
                        "day_atmosphere": day_atmosphere_filter,
                        "sky_palette_colour": sky_palette_filter,
                        "sunset_palette_colour": sunset_palette_filter,
                        "night_palette_colour": night_palette_filter,
                        "cloud_palette_colour": cloud_palette_filter,
                        "economy_type": economy_type_filter,
                        "economy_tier": economy_tier_filter,
                        "conflict_level": conflict_level_filter,
                        "dominant_race": dominant_race_filter,
                        "dominant_race_include_any": list(dominant_race_include_filter),
                        "dominant_race_exclude_any": list(dominant_race_exclude_filter),
                        "allow_unavailable_system_data": bool(allow_unavailable_system_data),
                        "generated_water_colour": generated_water_colour_filter,
                        "deep_water_biolum_colour": deep_water_biolum_colour_filter,
                        "native_sentinel_difficulty": native_sentinel_difficulty,
                        "native_sentinel_enum": native_sentinel_enum,
                    }
                    reasons = build_match_reasons(
                        row, prediction["system"], structured_filters
                    )
                    portal_accessible = is_portal_addressable_system_index(
                        system_index,
                        native_legacy_count,
                    )
                    exact_address = str(
                        row.get("exact_planet_portal_address", "")
                    )
                    matched_row = {
                        **row,
                        "system_portal": portal,
                        "planet_portal": exact_address,
                        "system_address": portal,
                        "planet_address": exact_address,
                        "galaxy_index": galaxy_index,
                        **galaxy_info,
                        "system_colour": prediction["system"]["colour"],
                        "system_planet_count": prediction["system"][
                            "planet_count"
                        ],
                        "match_reasons": reasons,
                        "match_summary": " • ".join(reasons),
                        "active_filter_count": len(reasons),
                        "portal_addressable": portal_accessible,
                        "portal_system_index": system_index,
                        "system_index_decimal": system_index,
                        "system_index_hex": f"0x{system_index:03X}",
                        "address_kind": finder_system_address_kind(system_index, native_legacy_count),
                        "travel_access": finder_travel_access(system_index, native_legacy_count),
                        "travel_guidance": finder_travel_guidance(system_index, native_legacy_count),
                        "glyph_portal_system_address": portal if portal_accessible else "",
                        "glyph_portal_planet_address": exact_address if portal_accessible else "",
                        "generated_planet_slot_code": row.get("generated_planet_slot_code", row.get("planet_portal", "")),
                        "recommended_portal_address": exact_address if portal_accessible else "",
                        "portal_target_scope": "exact_planet",
                        "exact_planet_portal_target_verified": bool(portal_accessible),
                        "planet_target_mapping_status": (
                            "validated_one_based_portal_planet_numbering_v20h14"
                        ),
                    }
                    matches.append(matched_row)
                    if match_callback:
                        match_callback(dict(matched_row))
                    if len(matches) >= int(result_limit):
                        break
            if cancelled or len(matches) >= int(result_limit):
                break
    finally:
        prediction_stream.close(
            terminate=bool(
                cancelled or len(matches) >= int(result_limit)
            )
        )


    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": (
            "PASS_CORE_V1_REGION_SEARCH_CANCELLED"
            if cancelled
            else "PASS_CORE_V1_REGION_SEARCH"
        ),
        "cancelled": cancelled,
        "completed_requested_scan": bool(
            not cancelled and tested_systems >= validated_count
        ),
        "scanned_fraction": (
            float(tested_systems) / float(validated_count)
            if validated_count > 0
            else 0.0
        ),
        "input": {
            "anchor_portal": canonical,
            "galaxy_index": galaxy_index,
            **galaxy_info,
            "start_system": validated_start,
            "requested_system_count": validated_count,
            "search_domain": domain,
            "search_domain_label": FINDER_SEARCH_DOMAIN_LABELS[domain],
            "search_domain_system_index_min": domain_minimum,
            "search_domain_system_index_max": domain_maximum,
            "search_domain_capacity": domain_capacity,
            "region_suffix": portal_region_suffix(canonical),
            "native_legacy_system_count": native_legacy_count,
            "native_legacy_system_count_hex": (
                f"0x{native_legacy_count:03X}"
                if native_legacy_count is not None
                else ""
            ),
            "native_occupancy_source": (
                native_occupancy.get("source", "")
                if native_occupancy
                else "validated_fixed_purple_interval"
            ),
            "native_occupancy_replayed_now": bool(
                native_occupancy and native_occupancy.get("replayed_now")
            ),
            "native_occupancy_live_boundary_validated": (
                native_occupancy.get("live_boundary_validated")
                if native_occupancy
                else True
            ),
            "portal_addressable_system_index_min": PORTAL_ADDRESSABLE_SYSTEM_INDEX_MIN,
            "portal_addressable_system_index_max": PORTAL_ADDRESSABLE_SYSTEM_INDEX_MAX,
            "portal_addressable_system_index_bands": [
                [
                    LEGACY_SYSTEM_INDEX_MIN,
                    (
                        native_legacy_count - 1
                        if native_legacy_count is not None
                        else LEGACY_SYSTEM_INDEX_MAX
                    ),
                ],
                [PURPLE_SYSTEM_INDEX_MIN, PURPLE_SYSTEM_INDEX_MAX],
            ],
            "portal_addressable_only": True,
            "purple_system_unlock_required": (
                domain == FINDER_SEARCH_DOMAIN_PURPLE
            ),
            "result_limit": int(result_limit),
            "system_workers_requested": worker_resolution["requested"],
            "system_worker_mode": worker_resolution["mode"],
            "system_workers_configured": worker_resolution["configured_workers"],
            "system_workers_effective": worker_resolution["effective_workers"],
            "system_worker_hardware": {"automatic_tuning": True, "hardware_details_included": False},
            "filters": {
                "paradise": paradise,
                "lush": lush,
                "water": water,
                "non_extreme": non_extreme,
                "max_sentinel": max_sentinel,
                "biome": biome_number,
                "star_colour": star_colour,
                "description_family": description_family,
                "weather_family": weather_family_filter,
                "weather_clear": weather_clear,
                "resource_level": resource_level,
                "common_substance": common_substance,
                "uncommon_substance": uncommon_substance,
                "rare_substance": rare_substance,
                "fauna_level": fauna_level,
                "flora_level": flora_level,
                "in_empty_system": in_empty_system,
                "in_abandoned_system": in_abandoned_system,
                "in_gas_giant_system": in_gas_giant_system,
                "in_pirate_system": in_pirate_system,
                "infested": infested,
                "dissonant": dissonant,
                "native_sentinel_difficulty": native_sentinel_difficulty,
                "native_sentinel_enum": native_sentinel_enum,
                "literal_paradise": literal_paradise,
                "lush_biome": lush_biome,
                "water_active": water_active,
                "weather_extreme": weather_extreme,
                "high_water": high_water,
                "world_size": world_size_filter,
                "native_size_class": native_size_class_filter,
                "moon_parent": moon_parent_filter,
                "moon_parent_rings": moon_parent_ring_filter,
                "moon_count": moon_count_filter,
                "ocean_type": ocean_type_filter,
                "allow_ocean_impossible": bool(allow_ocean_impossible),
                "terrain_record": terrain_record_filter,
                "terrain_setting": terrain_setting_filter,
                "ringed": ringed,
                "biome_variant": biome_variant_filter,
                "biome_variant_include_any": list(
                    biome_variant_include_filter
                ),
                "biome_variant_exclude_any": list(
                    biome_variant_exclude_filter
                ),
                "biome_source_contains": biome_source_contains,
                "fauna_profile_text": fauna_profile_text,
                "fauna_archetype_signal": fauna_archetype_signal,
                "planet_classification": classification_filter,
                "grass_assets": grass_assets,
                "glowing_grass": glowing_grass,
                "mushroom_flora": mushroom_flora,
                "glowing_mushroom": glowing_mushroom,
                "salvageable_scrap": salvageable_scrap,
                "grass_colour": grass_colour_filter,
                "grass_alt_colour": grass_alt_colour_filter,
                "either_grass_colour": either_grass_colour_filter,
                "day_atmosphere": day_atmosphere_filter,
                "sky_palette_colour": sky_palette_filter,
                "sunset_palette_colour": sunset_palette_filter,
                "night_palette_colour": night_palette_filter,
                "cloud_palette_colour": cloud_palette_filter,
                "economy_type": economy_type_filter,
                "economy_tier": economy_tier_filter,
                "conflict_level": conflict_level_filter,
                "dominant_race": dominant_race_filter,
                "dominant_race_include_any": list(dominant_race_include_filter),
                "dominant_race_exclude_any": list(dominant_race_exclude_filter),
                "allow_unavailable_system_data": bool(allow_unavailable_system_data),
                "generated_water_colour": generated_water_colour_filter,
                "deep_water_biolum_colour": deep_water_biolum_colour_filter,
            },
        },
        "tested_systems": tested_systems,
        "tested_planets": tested_planets,
        "match_count": len(matches),
        "matches": matches,
        "scan_statistics": finalise_scan_statistics(statistics_accumulator),
        "system_workers_requested": worker_resolution["requested"],
        "system_worker_mode": worker_resolution["mode"],
        "system_workers_configured": worker_resolution["configured_workers"],
        "system_workers_effective": worker_resolution["effective_workers"],
        "parallel_system_scan": worker_resolution["parallel"],
        "claim_boundary": {
            "searches_mapped_portal_system_bands_only": True,
            "legacy_portal_band": (
                f"0x000-0x{native_legacy_count - 1:03X}"
                if native_legacy_count is not None
                else "native region-specific contiguous prefix"
            ),
            "legacy_portal_predicate": (
                "SSI < GeneratedLegacySystemCount"
            ),
            "legacy_candidate_capacity_max": "0x300 / 768",
            "native_legacy_system_count_exact": (
                native_legacy_count is not None
            ),
            "native_legacy_system_count": native_legacy_count,
            "native_occupancy_source": (
                native_occupancy.get("source", "")
                if native_occupancy
                else "not_applicable_to_purple_domain"
            ),
            "native_occupancy_replayed_now": bool(
                native_occupancy and native_occupancy.get("replayed_now")
            ),
            "purple_portal_band": "0x3E9-0x428",
            "purple_portal_system_count": PURPLE_SYSTEM_COUNT,
            "selected_system_index_range": (
                f"0x{domain_minimum:03X}-0x{domain_maximum:03X}"
            ),
            "all_results_are_mapped_portal_addresses": True,
            "finder_ranges_do_not_wrap": True,
            "parallel_system_prediction_workers_complete": True,
            "parallel_system_prediction_engine": "multiprocessing spawn pool",
            "parallel_result_merge_order": "exact requested scan order",
            "parallel_result_limit_deterministic": True,
            "native_occupancy_resolution_workers": 1,
            "does_not_exhaust_entire_galaxy_automatically": True,
            "unmapped_system_index_gap_is_not_searchable": True,
            "unmapped_system_index_gap": "0x300-0x3E8",
            "indices_at_or_above_0x429_are_not_searchable": True,
            "generated_primary_surface_asset_capability_exact": True,
            "user_confirmed_bioluminescent_grass_variant_exact": True,
            "user_confirmed_large_glowing_mushroom_tree_variant_exact": True,
            "grass_and_grass_alt_palette_generation_exact": True,
            "atmosphere_palette_generation_exact": True,
            "native_day_dusk_night_sky_index_generation_exact": True,
            "native_sky_index_fresh_independent_outputs_exact": "54/54",
            "full_photometric_rendering_complete": False,
            "specific_visible_model_colour_channel_complete": False,
            "visual_surface_coverage_confirmed": False,
            "barren_heat_vs_nightly_cold_selector_complete": False,
            "rockbiome_floating_islands_false_mapping_removed": True,
        },
    }


def find_planets_across_regions(
    *,
    anchor_portal: str,
    galaxy: int = 0,
    start_system: int = 0,
    system_count: int = 64,
    result_limit: int = 25,
    search_domain: str = FINDER_SEARCH_DOMAIN_PORTAL,
    region_mode: str = FINDER_REGION_MODE_SINGLE,
    region_offset: int = 0,
    region_count: int = 1,
    region_order: str = "sequential",
    system_workers: int | str | None = 1,
    progress: Callable[[int, int, str], None] | None = None,
    cancel: Callable[[], bool] | None = None,
    pause: Callable[[], bool] | None = None,
    match_callback: Callable[[dict[str, Any]], None] | None = None,
    **filters: Any,
) -> dict[str, Any]:
    """Search one or many canonical regions with adaptive system workers.

    Region traversal and native legacy occupancy resolution remain ordered.
    Within each selected region, independent system predictions run in a
    deterministic multi-process pool and merge in exact requested scan order.
    """
    canonical = normalize_portal(anchor_portal)
    galaxy_index = normalize_internal_galaxy_index(galaxy)
    galaxy_info = galaxy_metadata(galaxy_index)
    domain = normalize_finder_search_domain(search_domain)
    mode = normalize_finder_region_mode(region_mode)
    traversal = load_region_traversal_engine()
    anchor_suffix = portal_region_suffix(canonical)
    traversal.decode_region_suffix(anchor_suffix, require_canonical=True)

    if not 0 <= int(galaxy) <= 255:
        raise ValueError("Galaxy index must be between 0 and 255.")
    if int(result_limit) < 1:
        raise ValueError("Result limit must be positive.")
    normalized_region_order = traversal.normalize_region_order(region_order)

    if mode == FINDER_REGION_MODE_SINGLE:
        result = find_planets(
            anchor_portal=canonical,
            galaxy=galaxy_index,
            start_system=int(start_system),
            system_count=int(system_count),
            result_limit=int(result_limit),
            search_domain=domain,
            system_workers=system_workers,
            progress=progress,
            cancel=cancel,
            pause=pause,
            match_callback=match_callback,
            **filters,
        )
        result["input"]["region_mode"] = mode
        result["input"]["region_mode_label"] = FINDER_REGION_MODE_LABELS[mode]
        result["input"]["region_offset"] = 0
        result["input"]["requested_region_count"] = 1
        result["input"]["region_order"] = normalized_region_order
        result["input"]["region_order_label"] = traversal.REGION_ORDER_LABELS[normalized_region_order]
        result["visited_regions"] = 1
        result["tested_regions"] = 1 if result.get("tested_systems", 0) else 0
        result["skipped_regions"] = 0
        result["region_summaries"] = [{
            "sequence_number": 1,
            "region_offset": 0,
            "region_suffix": anchor_suffix,
            "anchor_portal": canonical,
            "systems_tested": int(result.get("tested_systems", 0)),
            "planets_tested": int(result.get("tested_planets", 0)),
            "matches": int(result.get("match_count", 0)),
            "completed": bool(result.get("completed_requested_scan")),
        }]
        result["claim_boundary"]["multi_region_traversal_enabled"] = True
        result["claim_boundary"]["parallel_system_prediction_workers_complete"] = True
        result["claim_boundary"]["native_occupancy_resolution_workers"] = 1
        return result

    validated_offset, validated_regions = traversal.validate_region_window(
        int(region_offset),
        int(region_count),
    )

    requested_start = int(start_system)
    requested_count = int(system_count)
    if mode == FINDER_REGION_MODE_WINDOW:
        if requested_count < 1:
            raise ValueError("Systems to scan must be positive.")
        if domain == FINDER_SEARCH_DOMAIN_PURPLE:
            validate_finder_system_range(
                requested_start,
                requested_count,
                domain,
            )
        else:
            if not LEGACY_SYSTEM_INDEX_MIN <= requested_start <= LEGACY_SYSTEM_INDEX_MAX:
                raise ValueError(
                    "Legacy multi-region Start system must be between 0 and 767."
                )
            if requested_start + requested_count - 1 > LEGACY_SYSTEM_INDEX_MAX:
                raise ValueError(
                    "The selected legacy SSI window must stay within 0x000–0x2FF."
                )

    matches: list[dict[str, Any]] = []
    statistics_accumulator = new_scan_statistics_accumulator()
    region_summaries: list[dict[str, Any]] = []
    tested_systems = 0
    tested_planets = 0
    visited_regions = 0
    tested_regions = 0
    skipped_regions = 0
    cancelled = False
    stopped_by_result_limit = False
    all_subsearches_completed = True
    occupancy_replays = 0
    occupancy_cache_hits = 0
    worker_request = normalize_system_worker_request(system_workers)
    worker_profile = system_worker_profile()
    peak_effective_system_workers = 0
    parallel_regions = 0

    region_rows = traversal.iter_region_suffixes_ordered(
        anchor_suffix,
        region_offset=validated_offset,
        region_count=validated_regions,
        region_order=normalized_region_order,
    )

    for region_row in region_rows:
        while pause and bool(pause()):
            if cancel and bool(cancel()):
                cancelled = True
                break
            time.sleep(0.05)
        if cancelled:
            break
        if cancel and bool(cancel()):
            cancelled = True
            break
        visited_regions += 1
        sequence_number = int(region_row["sequence_number"])
        suffix = str(region_row["region_suffix"])
        region_anchor = portal_with_region_suffix(canonical, suffix)
        region_anchor = portal_with_system_index(region_anchor, 0)

        if progress:
            progress(
                sequence_number,
                validated_regions,
                f"Region {sequence_number}/{validated_regions} {suffix} — resolving range",
            )

        native_occupancy = None
        native_count = None
        if domain == FINDER_SEARCH_DOMAIN_PORTAL:
            native_occupancy = native_legacy_system_count_metadata(
                region_anchor,
                int(galaxy),
                allow_replay=True,
            )
            if not native_occupancy.get("resolved"):
                raise RuntimeError(
                    f"Native legacy-system count did not resolve for region {suffix}."
                )
            native_count = int(
                native_occupancy["generated_legacy_system_count"]
            )
            if native_occupancy.get("replayed_now"):
                occupancy_replays += 1
            else:
                occupancy_cache_hits += 1
            domain_minimum = LEGACY_SYSTEM_INDEX_MIN
            domain_maximum = native_count - 1
            domain_capacity = native_count
        else:
            domain_minimum = PURPLE_SYSTEM_INDEX_MIN
            domain_maximum = PURPLE_SYSTEM_INDEX_MAX
            domain_capacity = PURPLE_SYSTEM_COUNT

        if mode == FINDER_REGION_MODE_FULL:
            region_start = domain_minimum
            region_system_count = domain_capacity
        else:
            region_start = requested_start
            requested_end = requested_start + requested_count - 1
            intersection_start = max(region_start, domain_minimum)
            intersection_end = min(requested_end, domain_maximum)
            if intersection_start > intersection_end:
                skipped_regions += 1
                region_summaries.append({
                    **region_row,
                    "anchor_portal": region_anchor,
                    "domain_minimum": domain_minimum,
                    "domain_maximum": domain_maximum,
                    "domain_capacity": domain_capacity,
                    "native_legacy_system_count": native_count,
                    "occupancy_source": (
                        native_occupancy.get("source", "")
                        if native_occupancy
                        else "validated_fixed_purple_interval"
                    ),
                    "occupancy_replayed_now": bool(
                        native_occupancy
                        and native_occupancy.get("replayed_now")
                    ),
                    "skipped": True,
                    "skip_reason": (
                        "selected SSI window has no occupied systems in this region"
                    ),
                    "systems_tested": 0,
                    "planets_tested": 0,
                    "matches": 0,
                    "completed": True,
                })
                continue
            region_start = intersection_start
            region_system_count = intersection_end - intersection_start + 1

        remaining_limit = int(result_limit) - len(matches)
        if remaining_limit <= 0:
            stopped_by_result_limit = True
            break

        def region_progress(current: int, total: int, portal: str) -> None:
            if progress:
                progress(
                    sequence_number,
                    validated_regions,
                    (
                        f"Region {sequence_number}/{validated_regions} {suffix} · "
                        f"system {current}/{total} · {portal}"
                    ),
                )

        def region_match_callback(row: dict[str, Any]) -> None:
            if not match_callback:
                return
            enriched_live = dict(row)
            enriched_live.update({
                "region_sequence_number": sequence_number,
                "region_offset": int(region_row["region_offset"]),
                "region_suffix": suffix,
                "region_y": int(region_row["y"]),
                "region_z": int(region_row["z"]),
                "region_x": int(region_row["x"]),
            })
            match_callback(enriched_live)

        subresult = find_planets(
            anchor_portal=region_anchor,
            galaxy=galaxy_index,
            start_system=region_start,
            system_count=region_system_count,
            result_limit=remaining_limit,
            search_domain=domain,
            system_workers=system_workers,
            progress=region_progress,
            cancel=cancel,
            pause=pause,
            match_callback=region_match_callback,
            **filters,
        )
        merge_scan_statistics_payload(statistics_accumulator, dict(subresult.get("scan_statistics", {})))
        tested_regions += 1
        tested_systems += int(subresult.get("tested_systems", 0))
        tested_planets += int(subresult.get("tested_planets", 0))
        peak_effective_system_workers = max(
            peak_effective_system_workers,
            int(subresult.get("system_workers_effective", 1)),
        )
        if int(subresult.get("system_workers_effective", 1)) > 1:
            parallel_regions += 1
        for match in subresult.get("matches", []):
            enriched = dict(match)
            enriched.update({
                "region_sequence_number": sequence_number,
                "region_offset": int(region_row["region_offset"]),
                "region_ordinal": int(region_row["ordinal"]),
                "region_suffix": suffix,
                "region_y": int(region_row["y"]),
                "region_z": int(region_row["z"]),
                "region_x": int(region_row["x"]),
            })
            matches.append(enriched)

        subcompleted = bool(subresult.get("completed_requested_scan"))
        if not subcompleted:
            all_subsearches_completed = False
        region_summaries.append({
            **region_row,
            "anchor_portal": region_anchor,
            "domain_minimum": domain_minimum,
            "domain_maximum": domain_maximum,
            "domain_capacity": domain_capacity,
            "native_legacy_system_count": native_count,
            "occupancy_source": (
                native_occupancy.get("source", "")
                if native_occupancy
                else "validated_fixed_purple_interval"
            ),
            "occupancy_replayed_now": bool(
                native_occupancy
                and native_occupancy.get("replayed_now")
            ),
            "selected_start_system": region_start,
            "selected_system_count": region_system_count,
            "skipped": False,
            "systems_tested": int(subresult.get("tested_systems", 0)),
            "planets_tested": int(subresult.get("tested_planets", 0)),
            "matches": int(subresult.get("match_count", 0)),
            "system_workers_effective": int(
                subresult.get("system_workers_effective", 1)
            ),
            "parallel_system_scan": bool(
                subresult.get("parallel_system_scan", False)
            ),
            "completed": subcompleted,
        })

        if subresult.get("cancelled"):
            cancelled = True
            break
        if len(matches) >= int(result_limit):
            stopped_by_result_limit = True
            break

    completed = bool(
        not cancelled
        and not stopped_by_result_limit
        and visited_regions >= validated_regions
        and all_subsearches_completed
    )
    space = traversal.space_metadata(anchor_suffix)
    filters_payload = (
        region_summaries[0].get("filters", {})
        if region_summaries
        else {}
    )
    # The exact normalized filters are copied from the first successful
    # subsearch when available; otherwise the original arguments remain in
    # the public input object for diagnostic clarity.
    first_successful_input = None
    if tested_regions:
        # Match rows do not carry the full input. Re-run-free input metadata is
        # assembled from the explicit arguments below.
        first_successful_input = True

    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": (
            "PASS_CORE_V1_MULTI_REGION_SEARCH_CANCELLED"
            if cancelled
            else "PASS_CORE_V1_MULTI_REGION_SEARCH"
        ),
        "cancelled": cancelled,
        "stopped_by_result_limit": stopped_by_result_limit,
        "completed_requested_scan": completed,
        "scanned_fraction": (
            float(visited_regions) / float(validated_regions)
            if validated_regions > 0
            else 0.0
        ),
        "input": {
            "anchor_portal": canonical,
            "galaxy_index": galaxy_index,
            **galaxy_info,
            "start_system": requested_start,
            "requested_system_count": requested_count,
            "search_domain": domain,
            "search_domain_label": FINDER_SEARCH_DOMAIN_LABELS[domain],
            "search_domain_system_index_min": (
                PURPLE_SYSTEM_INDEX_MIN
                if domain == FINDER_SEARCH_DOMAIN_PURPLE
                else LEGACY_SYSTEM_INDEX_MIN
            ),
            "search_domain_system_index_max": (
                PURPLE_SYSTEM_INDEX_MAX
                if domain == FINDER_SEARCH_DOMAIN_PURPLE
                else LEGACY_SYSTEM_INDEX_MAX
            ),
            "search_domain_capacity": (
                PURPLE_SYSTEM_COUNT
                if domain == FINDER_SEARCH_DOMAIN_PURPLE
                else LEGACY_SYSTEM_CAPACITY_MAX
            ),
            "region_suffix": anchor_suffix,
            "region_mode": mode,
            "region_mode_label": FINDER_REGION_MODE_LABELS[mode],
            "region_offset": validated_offset,
            "requested_region_count": validated_regions,
            "region_order": normalized_region_order,
            "region_order_label": traversal.REGION_ORDER_LABELS[normalized_region_order],
            "region_traversal_order": space["coordinate_order"],
            "total_regions_per_galaxy": space["total_regions_per_galaxy"],
            "total_purple_systems_per_galaxy": (
                space["total_purple_systems_per_galaxy"]
            ),
            "maximum_legacy_candidate_systems_per_galaxy": (
                space["maximum_legacy_candidate_systems_per_galaxy"]
            ),
            "portal_addressable_only": True,
            "purple_system_unlock_required": (
                domain == FINDER_SEARCH_DOMAIN_PURPLE
            ),
            "result_limit": int(result_limit),
            "system_workers_requested": worker_request,
            "system_worker_hardware": {"automatic_tuning": True, "hardware_details_included": False},
            "system_workers_peak_effective": peak_effective_system_workers,
            "filters": dict(filters),
        },
        "visited_regions": visited_regions,
        "tested_regions": tested_regions,
        "skipped_regions": skipped_regions,
        "occupancy_replays": occupancy_replays,
        "occupancy_cache_hits": occupancy_cache_hits,
        "region_summaries": region_summaries,
        "tested_systems": tested_systems,
        "tested_planets": tested_planets,
        "match_count": len(matches),
        "matches": matches,
        "scan_statistics": finalise_scan_statistics(statistics_accumulator),
        "system_workers_requested": worker_request,
        "system_workers_peak_effective": peak_effective_system_workers,
        "parallel_regions": parallel_regions,
        "claim_boundary": {
            "searches_mapped_portal_system_bands_only": True,
            "legacy_portal_predicate": "SSI < GeneratedLegacySystemCount",
            "legacy_candidate_capacity_max": "0x300 / 768 per region",
            "purple_portal_band": "0x3E9-0x428",
            "purple_portal_system_count_per_region": PURPLE_SYSTEM_COUNT,
            "unmapped_system_index_gap": "0x300-0x3E8",
            "multi_region_traversal_enabled": True,
            "canonical_region_count_per_galaxy": (
                space["total_regions_per_galaxy"]
            ),
            "canonical_region_coordinate_ranges": {
                "x": [space["x_min"], space["x_max"]],
                "z": [space["z_min"], space["z_max"]],
                "y": [space["y_min"], space["y_max"]],
            },
            "region_traversal_order": space["coordinate_order"],
            "region_traversal_is_distance_sorted_sphere": False,
            "region_traversal_wraps_after_full_space": True,
            "region_sequence_is_unique_until_full_space_wrap": True,
            "region_traversal_workers": 1,
            "native_occupancy_resolution_workers": 1,
            "parallel_system_prediction_workers_complete": True,
            "parallel_system_worker_ceiling": "device dependent",
            "parallel_system_auto_recommendation": "automatic",
            "parallel_result_merge_order": "exact requested scan order",
            "parallel_region_workers_complete": False,
            "full_photometric_rendering_complete": False,
            "specific_visible_model_colour_channel_complete": False,
            "visual_surface_coverage_confirmed": False,
        },
    }


def search_report_text(result: dict[str, Any]) -> str:
    lines = [
        "ATLAS APF — CORE V1 SEARCH",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"TESTED_SYSTEMS={result['tested_systems']}",
        f"TESTED_PLANETS={result['tested_planets']}",
        f"MATCHES={result['match_count']}",
        f"CANCELLED={bool(result.get('cancelled'))}",
        f"COMPLETED_REQUESTED_SCAN={bool(result.get('completed_requested_scan'))}",
        f"SEARCH_DOMAIN={result.get('input', {}).get('search_domain', '')}",
        f"SEARCH_DOMAIN_LABEL={result.get('input', {}).get('search_domain_label', '')}",
        f"REGION_MODE={result.get('input', {}).get('region_mode', 'single')}",
        f"REGION_MODE_LABEL={result.get('input', {}).get('region_mode_label', FINDER_REGION_MODE_LABELS[FINDER_REGION_MODE_SINGLE])}",
        f"REGION_OFFSET={result.get('input', {}).get('region_offset', 0)}",
        f"REQUESTED_REGIONS={result.get('input', {}).get('requested_region_count', 1)}",
        f"VISITED_REGIONS={result.get('visited_regions', 1)}",
        f"TESTED_REGIONS={result.get('tested_regions', 1 if result.get('tested_systems') else 0)}",
        f"SKIPPED_REGIONS={result.get('skipped_regions', 0)}",
        f"OCCUPANCY_REPLAYS={result.get('occupancy_replays', 0)}",
        f"OCCUPANCY_CACHE_HITS={result.get('occupancy_cache_hits', 0)}",
        f"SYSTEM_WORKERS_REQUESTED={result.get('system_workers_requested', result.get('input', {}).get('system_workers_requested', 0))}",
        f"SYSTEM_WORKERS_CONFIGURED={result.get('system_workers_configured', result.get('input', {}).get('system_workers_configured', result.get('system_workers_peak_effective', 1)))}",
        f"SYSTEM_WORKERS_EFFECTIVE={result.get('system_workers_effective', result.get('system_workers_peak_effective', 1))}",
        f"PARALLEL_SYSTEM_SCAN={bool(result.get('parallel_system_scan', result.get('parallel_regions', 0)))}",
        f"SYSTEM_INDEX_RANGE=0x{int(result.get('input', {}).get('search_domain_system_index_min', 0)):03X}-0x{int(result.get('input', {}).get('search_domain_system_index_max', 0)):03X}",
        "",
        "MATCHES",
        "-------",
    ]
    if not result["matches"]:
        lines.append("No matching planets were found in the scanned range.")
    for row in result["matches"]:
        lines.append(
            f"SYSTEM={row['system_portal']} "
            f"EXACT_PLANET_PORTAL={row['planet_portal']} "
            f"INTERNAL_SLOT={row.get('internal_generated_slot', row.get('slot', ''))} "
            f"GAMEPLAY_PLANET={row.get('gameplay_planet_number', '')} "
            f"GENERATED_SLOT_CODE={row.get('generated_planet_slot_code', '')} "
            f"SYSTEM_INDEX={row.get('system_index_hex', '')} "
            f"PORTAL_ACCESSIBLE={row.get('portal_addressable', False)} "
            f"TRAVEL_ACCESS={row.get('travel_access', '')!r} "
            f"COLOUR={row['system_colour']} "
            f"BIOME_FAMILY={row['biome_name']} "
            f"BIOME_VARIANT={row.get('biome_variant_display', '')!r} "
        f"WORLD_TYPE={row.get('world_type_display', '')!r} "
            f"BIOME_SUBTYPE={row.get('biome_subtype_display', row.get('biome_subtype', ''))!r} "
            f"BIOME_SOURCE={row.get('surface_biome_source_file', '')!r} "
            f"WORLD_TYPE={row.get('world_type_display', '')!r} "
            f"PLANET_CLASSIFICATION={row.get('planet_classification_display') or row.get('description_token') or row.get('description_family_friendly')} "
            f"WEATHER={row.get('weather_display') or row.get('weather_token') or row.get('weather_family_friendly')} "
            f"FUNCTIONAL_WEATHER={row.get('weather_functional_display', '')!r} "
            f"RESOURCES={row.get('resources_display') or row.get('resources_token') or row.get('resource_abundance')} "
            f"RESOURCE_LEVEL={row['resource_level']} "
            f"COMMON={row['common_substance_id']} "
            f"UNCOMMON={row['uncommon_substance_id']} "
            f"RARE={row['rare_substance_id']} "
            f"FAUNA={row.get('fauna_display', row['fauna_abundance'])}/{row['fauna_token']} "
            f"FAUNA_PROFILE={row.get('fauna_descriptor_profile_summary', '')!r} "
            f"FAUNA_ARCHETYPE_SIGNALS={row.get('fauna_community_archetype_signal_summary', '')!r} "
            f"FLORA={row.get('flora_display', row['flora_abundance'])}/{row['flora_token']} "
            f"EMPTY_SYSTEM={row['in_empty_system']} "
            f"ABANDONED_SYSTEM={row['in_abandoned_system']} "
            f"GAS_GIANT_SYSTEM={row['in_gas_giant_system']} "
            f"PIRATE_SYSTEM={row['in_pirate_system']} "
            f"INFESTED={row['infested_planet']} "
            f"DISSONANT={row['dissonant_planet']} "
            f"PARADISE={row['literal_paradise']} "
            f"EXTREME={row['is_weather_extreme']} "
            f"DEFAULT_PLANET_NAME={row.get('default_procedural_planet_name', '')!r} "
        f"DEFAULT_SYSTEM_NAME={row.get('default_procedural_system_name', '')!r} "
        f"WATER={row['water_active']} "
            f"SALVAGEABLE_SCRAP={row.get('salvageable_scrap_available', row.get('has_scrap', False))} "
            f"GRASS_ASSET={row.get('explicit_grass_asset_available', False)} "
            f"BIOLUMINESCENT_GRASS_CARPET={row.get('glowing_grass_asset_available', False)} "
            f"ANY_EMISSIVE_GRASS={row.get('any_emissive_grass_asset_available', False)} "
            f"MUSHROOM_FLORA={row.get('mushroom_asset_available', False)} "
            f"LARGE_GLOWING_MUSHROOM_TREES={row.get('glowing_mushroom_asset_available', False)} "
            f"ANY_EMISSIVE_MUSHROOM={row.get('any_emissive_mushroom_asset_available', False)} "
            f"GRASS_SLOT0_DIAGNOSTIC={row.get('grass_colour_summary', '')!r} "
            f"GRASS_ALT_SLOT0_DIAGNOSTIC={row.get('grass_alt_colour_summary', '')!r} "
            f"VISIBLE_GRASS_COLOUR_EXACT={row.get('visible_grass_colour_exact', False)} "
            f"VISIBLE_GRASS_COLOUR_STATUS={row.get('visible_grass_colour_prediction_status', '')!r} "
            f"NATIVE_SENTINEL={row.get('sentinel_functional_activity_display', '')!r} "
            f"LEGACY_SENTINEL_LEVEL={row['sentinel_level']}"
        )
    return "\n".join(lines) + "\n"


def write_search_outputs(result: dict[str, Any]) -> dict[str, str]:
    output = OUTPUT_ROOT / f"search_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "planet_search_core_v1.json"
    csv_path = output / "planet_search_core_v1.csv"
    report_path = output / "OPEN_THIS_PLANET_SEARCH_CORE_V1.txt"
    safe_json(json_path, result)
    write_csv(csv_path, result["matches"])
    report_path.write_text(search_report_text(result), encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "csv": str(csv_path),
        "report": str(report_path),
    }


def compare_values(field: str, actual: Any, expected: Any) -> bool:
    if field in {
        "water_active_frequency",
        "high_water_active_frequency",
        "sea_level",
        "ground_combat_field_3440",
        "ground_combat_field_3444",
    }:
        return math.isclose(
            float(actual or 0.0),
            float(expected or 0.0),
            rel_tol=0.0,
            abs_tol=1e-5,
        )
    if field in {"water_active", "high_water", "has_scrap"}:
        return bool(actual) == bool(expected)
    return actual == expected


def verify_integrity() -> dict[str, Any]:
    manifest = load_json(INTEGRITY_PATH)
    rows = []
    for relative, expected in manifest.get("files", {}).items():
        path = PACKAGE_ROOT / relative
        exists = path.is_file()
        size = path.stat().st_size if exists else None
        observed_hash = sha256_file(path) if exists else ""
        expected_size = int(expected["size"])
        expected_hash = str(expected["sha256"]).upper()
        exact = bool(
            exists
            and size == expected_size
            and observed_hash == expected_hash
        )
        rows.append({
            "relative_path": relative,
            "exists": exists,
            "expected_size": expected_size,
            "observed_size": size,
            "expected_sha256": expected_hash,
            "observed_sha256": observed_hash,
            "exact": exact,
        })
    return {
        "manifest_version": manifest.get("version"),
        "file_count": len(rows),
        "exact_count": sum(row["exact"] for row in rows),
        "exact": all(row["exact"] for row in rows),
        "rows": rows,
    }



def run_selector_mapping_regression_v2() -> dict[str, Any]:
    payload = load_json(SELECTOR_MAPPING_REGRESSION_PATH)
    system_rows = list(payload.get("systems", []))
    planet_rows = list(payload.get("planet_rows", []))
    failures: list[dict[str, Any]] = []
    predicted: dict[str, dict[str, Any]] = {}
    counts = {
        "system_raw": 0, "economy": 0, "wealth": 0, "conflict": 0,
        "race": 0, "special_hidden": 0, "visible_race": 0,
        "visible_economy_stars": 0, "water": 0, "deep": 0,
    }
    ordinary_count = 0
    special_count = 0
    visible_count = 0
    for expected in system_rows:
        address = str(expected["system_address"]).upper()
        result = predict_system(address, 0)
        predicted[address] = result
        system = result["system"]
        ordinary = bool(expected.get("public_selectors_visible"))
        ordinary_count += int(ordinary)
        special_count += int(not ordinary)
        raw_ok = (
            int(system.get("economy_type_raw", -1)) == int(expected["system_kind_raw"])
            and int(system.get("economy_tier_raw", -1)) == int(expected["wealth_raw"])
            and int(system.get("conflict_level_raw", -1)) == int(expected["source_field8_raw"])
            and bool(system.get("in_empty_system")) == bool(expected["in_empty_system"])
            and bool(system.get("in_abandoned_system")) == bool(expected["in_abandoned_system"])
            and bool(system.get("in_pirate_system")) == bool(expected["in_pirate_system"])
        )
        counts["system_raw"] += int(raw_ok)
        economy_ok = str(system.get("economy_type_internal")) == str(expected["economy_type_display"])
        wealth_ok = int(system.get("economy_tier_raw", -1)) == int(expected["wealth_raw"])
        conflict_ok = int(system.get("conflict_level_raw", -1)) == int(expected["source_field8_raw"])
        counts["economy"] += int(economy_ok)
        counts["wealth"] += int(wealth_ok)
        counts["conflict"] += int(conflict_ok)
        if ordinary:
            race_ok = (
                int(system.get("dominant_race_raw", -1)) == int(expected["live_race_raw"])
                and str(system.get("dominant_race_internal")) == str(expected["dominant_race_display"])
                and bool(system.get("dominant_race_exact"))
                and bool(system.get("economy_tier_exact"))
            )
            counts["race"] += int(race_ok)
        else:
            hidden_ok = (
                bool(system.get("system_selector_data_unavailable"))
                and str(system.get("economy_tier_display")) == "Data unavailable"
                and str(system.get("dominant_race_display")) == "Data unavailable"
                and not bool(system.get("economy_tier_exact"))
                and not bool(system.get("dominant_race_exact"))
            )
            counts["special_hidden"] += int(hidden_ok)
            race_ok = hidden_ok
        visible = dict(expected.get("visible_observations", {}))
        if visible:
            visible_count += 1
            visible_race_ok = str(system.get("dominant_race_display")) == str(visible["visible_dominant_race"])
            expected_stars = int(str(visible["visible_economy_star_count"]))
            visible_star_ok = str(system.get("economy_tier_star_display", "")).count("★") == expected_stars
            counts["visible_race"] += int(visible_race_ok)
            counts["visible_economy_stars"] += int(visible_star_ok)
        else:
            visible_race_ok = visible_star_ok = True
        if not all((raw_ok, economy_ok, wealth_ok, conflict_ok, race_ok, visible_race_ok, visible_star_ok)):
            failures.append({"system": address, "expected": expected, "actual": system})
    for expected in planet_rows:
        address = str(expected["system_address"]).upper()
        result = predicted[address]
        actual = next(row for row in result["planet_rows"] if int(row["slot"]) == int(expected["slot"]))
        water_ok = (
            list(actual.get("generated_water_source_indices", [])) == list(expected["water_source_indices"])
            and [str(item.get("hex", "")).upper() for item in actual.get("generated_water_palette_colours", [])]
            == [str(value).upper() for value in expected["water_hex_values"]]
        )
        deep_ok = (
            list(actual.get("deep_water_biolum_source_indices", [])) == list(expected["deep_water_biolum_source_indices"])
            and [str(item.get("hex", "")).upper() for item in actual.get("deep_water_biolum_palette_colours", [])]
            == [str(value).upper() for value in expected["deep_water_biolum_hex_values"]]
        )
        counts["water"] += int(water_ok)
        counts["deep"] += int(deep_ok)
        if not (water_ok and deep_ok):
            failures.append({"planet": expected["planet_address"], "water_exact": water_ok, "deep_water_exact": deep_ok})
    ordinary_expected = next(row for row in system_rows if row.get("public_selectors_visible"))
    ordinary_result = predicted[str(ordinary_expected["system_address"]).upper()]
    ordinary_system = ordinary_result["system"]
    ordinary_planet = ordinary_result["planet_rows"][0]
    special_expected = next(row for row in system_rows if not row.get("public_selectors_visible"))
    special_result = predicted[str(special_expected["system_address"]).upper()]
    special_system = special_result["system"]
    special_planet = special_result["planet_rows"][0]
    filter_checks = {
        "economy": planet_matches(ordinary_planet, ordinary_system, economy_type=ordinary_system["economy_type_internal"]),
        "tier": planet_matches(ordinary_planet, ordinary_system, economy_tier=ordinary_system["economy_tier_internal"]),
        "conflict": planet_matches(ordinary_planet, ordinary_system, conflict_level=ordinary_system["conflict_level_internal"]),
        "race": planet_matches(ordinary_planet, ordinary_system, dominant_race=ordinary_system["dominant_race_internal"]),
        "special_rejected_without_bypass": not planet_matches(special_planet, special_system, economy_tier="High"),
        "special_allowed_with_bypass": planet_matches(special_planet, special_system, economy_tier="High", allow_unavailable_system_data=True),
        "explicit_exclusion_precedence": not planet_matches(special_planet, special_system, economy_tier="High", allow_unavailable_system_data=True, in_abandoned_system=False if special_system.get("in_abandoned_system") else None, in_empty_system=False if special_system.get("in_empty_system") else None, in_pirate_system=False if special_system.get("in_pirate_system") else None),
    }
    enum_values = dict(payload.get("native_wealth_enum", {}).get("values", {}))
    checks = {
        "systems_raw": counts["system_raw"] == len(system_rows),
        "economy_type": counts["economy"] == len(system_rows),
        "economy_tier": counts["wealth"] == len(system_rows),
        "conflict_level": counts["conflict"] == len(system_rows),
        "dominant_race_ordinary": counts["race"] == ordinary_count,
        "special_selector_hidden": counts["special_hidden"] == special_count,
        "visible_race_controls": counts["visible_race"] == visible_count,
        "visible_economy_star_controls": counts["visible_economy_stars"] == visible_count,
        "generated_water_palette": counts["water"] == len(planet_rows),
        "deep_water_biolum_palette": counts["deep"] == len(planet_rows),
        "economy_filter_normalization": all(normalize_economy_type_filter(value) == value for value in economy_type_filter_values()),
        "tier_filter_normalization": all(normalize_economy_tier_filter(value) == value for value in economy_tier_filter_values()),
        "conflict_filter_normalization": all(normalize_conflict_level_filter(value) == value for value in conflict_level_filter_values()),
        "race_filter_normalization": all(normalize_dominant_race_filter(value) == value for value in dominant_race_filter_values()),
        "native_wealth_enum": enum_values == {"0":"Poor","1":"Average","2":"Wealthy","3":"Pirate"},
        **{f"filter_{key}": bool(value) for key, value in filter_checks.items()},
    }
    return {
        "version": VERSION,
        "status": "PASS_PUBLIC_READINESS_SYSTEM_SELECTORS_V3_EXACT" if all(checks.values()) else "ERROR_PUBLIC_READINESS_SYSTEM_SELECTORS_V3",
        "exact": all(checks.values()),
        "checks": checks,
        "systems": len(system_rows),
        "ordinary_systems": ordinary_count,
        "special_systems": special_count,
        "planets": len(planet_rows),
        "counts": counts,
        "failures": failures,
    }


def run_grass_glow_regression() -> dict[str, Any]:
    """Replay the locked 47-planet V20A7/V20A8A grass-and-glow corpus."""
    payload = load_json(GRASS_GLOW_REGRESSION_PATH)
    rows = list(payload.get("rows", []))
    surface_rule = load_surface_objectlist_rule()
    colour_rule = load_grass_colour_rule()
    visual_rule = load_visual_flora_rule()

    metric_names = (
        "surface_source_file",
        "surface_main_index",
        "surface_main_path",
        "explicit_grass_asset",
        "glowing_grass_asset",
        "ground_foliage_candidate",
        "mushroom_asset",
        "glowing_mushroom_asset",
        "grass_indices",
        "grass_primary_hex",
        "grass_primary_family",
        "grass_alt_indices",
        "grass_alt_primary_hex",
        "grass_alt_primary_family",
    )
    metrics = {
        name: {"correct": 0, "total": len(rows)}
        for name in metric_names
    }
    failures: list[dict[str, Any]] = []

    for expected in rows:
        seed = int(str(expected["planet_seed_hex"]), 0)
        surface = surface_rule.predict(
            planet_seed=seed,
            biome=int(expected["biome"]),
            biome_subtype=int(expected["biome_subtype"]),
            life_level=int(expected["life_level"]),
        )
        colour = colour_rule.predict(
            planet_root_seed=seed,
            biome_source_file=str(surface["source_file"]),
        )
        main = surface["main"]
        flags = surface["surface_capability"]
        grass = colour["grass"]
        grass_alt = colour["grass_alt"]
        visual = visual_rule.classify_capability(
            surface.get("capability", {})
        )

        checks = {
            "surface_source_file": (
                str(surface["source_file"])
                == str(expected["source_file"])
            ),
            "surface_main_index": (
                int(main["selected_index"])
                == int(expected["main_selected_index"])
            ),
            "surface_main_path": (
                str(main["selected_path"])
                == str(expected["main_selected_path"])
            ),
            "explicit_grass_asset": (
                bool(flags["explicit_grass_asset_available"])
                == bool(expected["explicit_grass_asset_available"])
            ),
            "glowing_grass_asset": (
                bool(flags["glowing_grass_asset_available"])
                == bool(expected["glowing_grass_asset_available"])
            ),
            "ground_foliage_candidate": (
                bool(flags["ground_foliage_candidate_available"])
                == bool(expected["ground_foliage_candidate_available"])
            ),
            "mushroom_asset": (
                bool(flags["mushroom_asset_available"])
                == bool(expected["mushroom_asset_available"])
            ),
            "glowing_mushroom_asset": (
                bool(flags["glowing_mushroom_asset_available"])
                == bool(expected["glowing_mushroom_asset_available"])
            ),
            "grass_indices": (
                list(grass["source_indices"])
                == list(expected["grass_indices"])
            ),
            "grass_primary_hex": (
                str(grass["primary"]["hex"]).upper()
                == str(expected["grass_primary_hex"]).upper()
            ),
            "grass_primary_family": (
                str(grass["primary"]["colour_family"]).casefold()
                == str(expected["grass_primary_family"]).casefold()
            ),
            "grass_alt_indices": (
                list(grass_alt["source_indices"])
                == list(expected["grass_alt_indices"])
            ),
            "grass_alt_primary_hex": (
                str(grass_alt["primary"]["hex"]).upper()
                == str(expected["grass_alt_primary_hex"]).upper()
            ),
            "grass_alt_primary_family": (
                str(grass_alt["primary"]["colour_family"]).casefold()
                == str(expected["grass_alt_primary_family"]).casefold()
            ),
        }
        for name, passed in checks.items():
            metrics[name]["correct"] += int(passed)
            if not passed:
                failures.append({
                    "planet_key": expected.get("planet_key"),
                    "seed": expected["planet_seed_hex"],
                    "field": name,
                    "expected": expected.get(name),
                })

    for metric in metrics.values():
        metric["exact"] = bool(
            metric["total"] > 0
            and metric["correct"] == metric["total"]
        )

    # Directly prove the released filters against the fresh positive/negative
    # controls without requiring the numeric/Unicorn engine.
    fresh = [
        row for row in rows
        if str(row.get("provenance", "")).startswith("fresh_live")
    ]

    def expected_with_visual(
        expected: dict[str, Any],
    ) -> dict[str, Any]:
        capability = surface_rule.capabilities.get(
            str(expected["main_selected_path"]),
            {},
        )
        visual = visual_rule.classify_capability(capability)
        return {**expected, **visual}

    visual_rows = [
        expected_with_visual(row)
        for row in rows
    ]
    positive = next(
        row for row in visual_rows
        if bool(row["bioluminescent_grass_carpet_available"])
    )
    negative = next(
        row for row in visual_rows
        if not bool(row["bioluminescent_grass_carpet_available"])
    )

    def minimal_row(expected: dict[str, Any]) -> dict[str, Any]:
        return {
            "explicit_grass_asset_available": expected[
                "explicit_grass_asset_available"
            ],
            "glowing_grass_asset_available": expected[
                "bioluminescent_grass_carpet_available"
            ],
            "mushroom_asset_available": expected[
                "mushroom_asset_available"
            ],
            "glowing_mushroom_asset_available": expected[
                "large_glowing_mushroom_tree_available"
            ],
            "grass_primary_hex": expected["grass_primary_hex"],
            "grass_primary_colour_family": expected[
                "grass_primary_family"
            ],
            "grass_alt_primary_hex": expected[
                "grass_alt_primary_hex"
            ],
            "grass_alt_primary_colour_family": expected[
                "grass_alt_primary_family"
            ],
        }

    system_stub = {"colour": "Yellow"}
    filter_checks = {
        "glowing_grass_positive_include": planet_matches(
            minimal_row(positive),
            system_stub,
            glowing_grass=True,
        ),
        "glowing_grass_negative_excluded": not planet_matches(
            minimal_row(negative),
            system_stub,
            glowing_grass=True,
        ),
        "glowing_grass_negative_filter": planet_matches(
            minimal_row(negative),
            system_stub,
            glowing_grass=False,
        ),
        "grass_colour_family": planet_matches(
            minimal_row(positive),
            system_stub,
            grass_colour=positive["grass_primary_family"],
        ),
        "grass_colour_hex": planet_matches(
            minimal_row(positive),
            system_stub,
            grass_colour=positive["grass_primary_hex"],
        ),
        "grass_alt_colour_family": planet_matches(
            minimal_row(positive),
            system_stub,
            grass_alt_colour=positive["grass_alt_primary_family"],
        ),
        "grass_alt_colour_hex": planet_matches(
            minimal_row(positive),
            system_stub,
            grass_alt_colour=positive["grass_alt_primary_hex"],
        ),
        "grass_assets_include": planet_matches(
            minimal_row(positive),
            system_stub,
            grass_assets=True,
        ),
        "either_grass_colour_family": planet_matches(
            minimal_row(positive),
            system_stub,
            either_grass_colour=positive[
                "grass_alt_primary_family"
            ],
        ),
        "either_grass_colour_hex": planet_matches(
            minimal_row(positive),
            system_stub,
            either_grass_colour=positive[
                "grass_primary_hex"
            ],
        ),
    }

    exact = bool(
        len(rows) == 47
        and all(metric["exact"] for metric in metrics.values())
        and all(filter_checks.values())
        and not failures
    )
    return {
        "version": VERSION,
        "status": (
            "PASS_GRASS_GLOW_REGRESSION_V20A9_EXACT"
            if exact
            else "ERROR_GRASS_GLOW_REGRESSION_V20A9"
        ),
        "exact": exact,
        "planet_count": len(rows),
        "metrics": metrics,
        "filter_checks": filter_checks,
        "failure_count": len(failures),
        "failures": failures,
        "claim_boundary": payload.get("claim_boundary", {}),
    }



def run_portal_variant_weather_regression_v20h14() -> dict[str, Any]:
    checks: dict[str, bool] = {}

    six = predict_system("3079FC47FBFC", 0)
    checks["input_planet_3_maps_internal_slot_2"] = (
        six["input"]["requested_internal_slot"] == 2
    )
    checks["six_body_count"] = int(six["system"]["planet_count"]) == 6
    for row in six["planet_rows"]:
        slot = int(row["slot"])
        checks[f"portal_slot_{slot}"] = (
            row["exact_planet_portal_address"]
            == f"{slot + 1:X}{six['input']['canonical_system_portal'][1:]}"
        )
        checks[f"number_slot_{slot}"] = (
            int(row["gameplay_planet_number"]) == slot + 1
        )

    checks["glyph_6_accepted"] = parse_portal("6003239D7F56")[1] == 6
    bountiful = predict_system("0001239D7F59", 0)
    lush = next(row for row in bountiful["planet_rows"] if int(row["slot"]) == 4)
    checks["lushroom_a_variant"] = lush["biome_variant_display"] == "LushRoom A"
    checks["functional_extreme"] = lush["weather_storm_frequency"] == "Extreme storms"
    checks["biome_variant_filter"] = planet_matches(
        lush, bountiful["system"], biome_variant="LushRoom A"
    )
    checks["storm_filter"] = planet_matches(
        lush, bountiful["system"], functional_storm_frequency="Extreme storms"
    )

    paradise = predict_system("0056239D7F58", 0)
    p = next(row for row in paradise["planet_rows"] if int(row["slot"]) == 3)
    checks["paradise_planet"] = p["planet_classification_display"] == "Paradise Planet"
    checks["paradise_no_storms"] = p["weather_storm_frequency"] == "No storms"
    checks["paradise_rule"] = bool(p["literal_paradise"])

    giant = predict_system("1410FCA6CB8B", 0)
    g = next(row for row in giant["planet_rows"] if int(row["slot"]) == 0)
    checks["giant_lush_planet_type"] = g["planet_type"] == "DISC_TYPE_GIANT"
    checks["giant_lush_world_type"] = g["world_type_display"] == "Giant Planet"
    checks["giant_lush_no_storms"] = g["weather_storm_frequency"] == "No storms"
    checks["giant_lush_native_sentinel_low"] = (
        g["sentinel_functional_activity_display"] == "Low / Rare"
    )
    checks["giant_lush_paradise"] = bool(g["literal_paradise"])
    checks["giant_lush_classification"] = (
        g["planet_classification_display"] == "Paradise Giant"
    )
    checks["giant_lush_placeholder_resolved"] = (
        "%PLANETCLASS%" not in g["planet_classification_display"]
    )

    exact = bool(checks) and all(checks.values())
    return {
        "version": VERSION,
        "status": (
            "PASS_PORTAL_VARIANT_WEATHER_V20H14"
            if exact else "ERROR_PORTAL_VARIANT_WEATHER_V20H14"
        ),
        "exact": exact,
        "checks": checks,
        "correct": sum(checks.values()),
        "total": len(checks),
    }


def run_release_corrections_regression_v20h8() -> dict[str, Any]:
    """Validate live Paradise corrections and exact grass-colour catalogue."""
    controls = [
        {
            "system_portal": "0056239D7F58",
            "slot": 3,
            "classification": "Paradise Planet",
            "weather": "Blissful",
            "literal_paradise": True,
            "planet_count": 4,
        },
        {
            "system_portal": "0050239D7F57",
            "slot": 3,
            "classification": "Paradise Moon",
            "weather": "Temperate",
            "literal_paradise": True,
        },
        {
            "system_portal": "0079FC47FBFC",
            "slot": 2,
            "classification": "Humid Planet",
            "weather": "Dangerously Hot Fog",
            "literal_paradise": False,
        },
        {
            "system_portal": "0410FCA6CB8B",
            "slot": 0,
            "classification": "Paradise Giant",
            "weather": "Temperate",
            "literal_paradise": True,
            "planet_type": "DISC_TYPE_GIANT",
            "world_type": "Giant Planet",
            "native_sentinel": "Low / Rare",
        },
    ]
    checks: dict[str, bool] = {}
    observed: list[dict[str, Any]] = []
    for index, control in enumerate(controls, 1):
        prediction = predict_system(control["system_portal"], 0)
        row = next(
            item for item in prediction["planet_rows"]
            if int(item["slot"]) == int(control["slot"])
        )
        prefix = f"control_{index}"
        checks[f"{prefix}_classification"] = (
            str(row.get("planet_classification_display"))
            == str(control["classification"])
        )
        checks[f"{prefix}_weather"] = (
            str(row.get("weather_display")) == str(control["weather"])
        )
        checks[f"{prefix}_paradise"] = (
            bool(row.get("literal_paradise"))
            == bool(control["literal_paradise"])
        )
        if "planet_count" in control:
            checks[f"{prefix}_planet_count"] = (
                int(prediction["system"]["planet_count"])
                == int(control["planet_count"])
            )
        if "planet_type" in control:
            checks[f"{prefix}_planet_type"] = (
                str(row.get("planet_type")) == str(control["planet_type"])
            )
        if "world_type" in control:
            checks[f"{prefix}_world_type"] = (
                str(row.get("world_type_display"))
                == str(control["world_type"])
            )
        if "native_sentinel" in control:
            checks[f"{prefix}_native_sentinel"] = (
                str(row.get("sentinel_functional_activity_display"))
                == str(control["native_sentinel"])
            )
        checks[f"{prefix}_no_placeholder"] = (
            "%PLANETCLASS%" not in str(
                row.get("planet_classification_display", "")
            )
        )
        observed.append({
            "system_portal": control["system_portal"],
            "slot": control["slot"],
            "classification": row.get("planet_classification_display"),
            "weather": row.get("weather_display"),
            "planet_type": row.get("planet_type"),
            "world_type": row.get("world_type_display"),
            "native_sentinel": row.get(
                "sentinel_functional_activity_display"
            ),
            "legacy_sentinel_level": row.get("sentinel_level"),
            "literal_paradise": row.get("literal_paradise"),
            "planet_count": prediction["system"]["planet_count"],
        })

    import inspect
    checks["white_not_in_generated_filter_values"] = all(
        value not in {"White / pale neutral", "Black / very dark"}
        for value in GRASS_COLOUR_FILTER_VALUES
    )
    checks["white_search_parameter_removed"] = (
        "white_glowing_grass" not in inspect.signature(find_planets).parameters
        and "white_glowing_grass" not in inspect.signature(planet_matches).parameters
    )
    checks["bioluminescent_filter_retained"] = (
        "glowing_grass" in inspect.signature(find_planets).parameters
        and "glowing_grass" in inspect.signature(planet_matches).parameters
    )
    checks["nine_generated_families_retained"] = (
        len(GRASS_COLOUR_FILTER_VALUES) == 9
    )
    exact_catalog = grass_exact_colour_catalog("either_any_slot")
    checks["exact_grass_catalog_273"] = len(exact_catalog) == 273
    checks["exact_grass_primary_catalog_198"] = (
        grass_exact_colour_count("grass_primary") == 198
    )
    checks["exact_grass_alt_primary_catalog_80"] = (
        grass_exact_colour_count("grass_alt_primary") == 80
    )
    checks["white_grass_display_present"] = any(
        str(row.get("hex", "")).upper() == "#AD9284"
        and str(row.get("display", ""))
        == "White #AD9284"
        and bool(row.get("grass_primary"))
        for row in exact_catalog
    )
    checks["exact_display_normalizes_to_hex"] = (
        normalize_grass_colour_filter(
            "White #AD9284"
        )
        == "#AD9284"
    )
    checks["broad_family_label_normalizes"] = (
        normalize_grass_colour_filter("Family — Green (broad)")
        == "Green"
    )
    checks["exact_ad9284_filter_matches"] = planet_matches(
        {
            "grass_primary_hex": "#AD9284",
            "grass_primary_colour_family": "Orange",
        },
        {"colour": "Yellow"},
        grass_colour=(
            "White #AD9284"
        ),
    )
    checks["exact_ad9284_filter_rejects_other"] = not planet_matches(
        {
            "grass_primary_hex": "#AD9184",
            "grass_primary_colour_family": "Orange",
        },
        {"colour": "Yellow"},
        grass_colour=(
            "White #AD9284"
        ),
    )
    terrain_positive = predict_system("01F0239D6F69", 0)
    terrain_positive_row = next(
        item for item in terrain_positive["planet_rows"]
        if int(item["slot"]) == 5
    )
    checks["terrain_positive_family"] = (
        terrain_positive_row.get("terrain_family_display") == "Floating Islands (terrain)"
    )
    checks["terrain_positive_not_subtype_alias"] = (
        "Floating Islands" not in terrain_positive_row.get("biome_variant_filter_labels", [])
    )
    checks["terrain_positive_filter"] = planet_matches(
        terrain_positive_row,
        terrain_positive["system"],
        terrain_setting="Floating Islands (terrain)",
    )
    checks["terrain_positive_subtype_filter_rejected"] = not planet_matches(
        terrain_positive_row,
        terrain_positive["system"],
        biome_variant_include_any=("Floating Islands",),
    )
    terrain_negative = predict_system("0192239D7F6A", 0)
    terrain_negative_row = next(
        item for item in terrain_negative["planet_rows"]
        if int(item["slot"]) == 5
    )
    checks["terrain_negative_family"] = (
        terrain_negative_row.get("terrain_family_display") == "Caverns"
    )
    checks["terrain_negative_hydrogarden_subtype_present"] = (
        "Floating Islands (subbiome)"
        in terrain_negative_row.get("biome_variant_filter_labels", [])
        or "Floating Islands"
        in terrain_negative_row.get("biome_variant_filter_labels", [])
    )
    checks["terrain_negative_subtype_filter"] = planet_matches(
        terrain_negative_row,
        terrain_negative["system"],
        biome_variant_include_any=("Floating Islands (subbiome)",),
    )
    checks["terrain_negative_filter_rejected"] = not planet_matches(
        terrain_negative_row,
        terrain_negative["system"],
        terrain_setting="Floating Islands (terrain)",
    )
    swamp_control = predict_system("0192239D7F6A", 0)["planet_rows"][0]
    # Synthetic source conversion checks avoid inventing a new address claim.
    swamp_meta = apply_biome_weather_paradise_metadata(
        {**swamp_control, "biome": 0, "biome_name": "Lush",
         "surface_biome_source_file": "METADATA/SIMULATION/SOLARSYSTEM/BIOMES/SWAMP/SWAMPBIOME.MBIN"},
        family_catalog=load_family_catalog(),
    )
    lava_meta = apply_biome_weather_paradise_metadata(
        {**swamp_control, "biome": 2, "biome_name": "Scorched",
         "surface_biome_source_file": "METADATA/SIMULATION/SOLARSYSTEM/BIOMES/LAVA/LAVABIOME.MBIN"},
        family_catalog=load_family_catalog(),
    )
    checks["swamp_source_conversion"] = (
        swamp_meta.get("effective_biome") == 12
        and swamp_meta.get("effective_biome_name") == BIOME_NAMES[12]
        and not swamp_meta.get("literal_paradise")
    )
    checks["lava_source_conversion"] = (
        lava_meta.get("effective_biome") == 13
        and lava_meta.get("effective_biome_name") == BIOME_NAMES[13]
    )

    exact = bool(checks) and all(checks.values())
    return {
        "version": VERSION,
        "status": (
            "PASS_RELEASE_CORRECTIONS_V20H15"
            if exact else "ERROR_RELEASE_CORRECTIONS_V20H15"
        ),
        "exact": exact,
        "checks": checks,
        "controls": controls,
        "observed": observed,
        "claim_boundary": {
            "generated_grass_palette_filters_enabled": True,
            "bioluminescent_bubble_grass_filter_enabled": True,
            "white_rendered_colour_search_enabled": True,
            "white_rendered_colour_exact_input": "#AD9284",
            "paradise_uses_native_reference_sentinel_rare": True,
            "giant_lush_paradise_control": "1410FCA6CB8B",
            "native_paradise_selector_fully_recovered": False,
            "live_address_overrides_retained": True,
        },
    }

def run_visual_flora_regression() -> dict[str, Any]:
    """Replay live-confirmed exact visual flora controls."""
    payload = load_json(VISUAL_FLORA_REGRESSION_PATH)
    controls = list(payload.get("controls", []))
    surface_rule = load_surface_objectlist_rule()
    colour_rule = load_grass_colour_rule()
    visual_rule = load_visual_flora_rule()

    metric_names = (
        "surface_source_file",
        "surface_main_object_list",
        "bioluminescent_grass_carpet",
        "large_glowing_mushroom_tree",
        "small_glowing_mushroom_flora",
        "grass_primary_hex",
        "grass_alt_primary_hex",
    )
    metrics = {
        name: {"correct": 0, "total": len(controls)}
        for name in metric_names
    }
    failures: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []

    for expected in controls:
        seed = int(str(expected["planet_seed_hex"]), 0)
        surface = surface_rule.predict(
            planet_seed=seed,
            biome=int(expected["biome"]),
            biome_subtype=int(expected["biome_subtype"]),
            life_level=int(expected["life_level"]),
        )
        colour = colour_rule.predict(
            planet_root_seed=seed,
            biome_source_file=str(surface["source_file"]),
        )
        visual = visual_rule.classify_capability(
            surface.get("capability", {})
        )
        checks = {
            "surface_source_file": (
                str(surface["source_file"])
                == str(expected["source_file"])
            ),
            "surface_main_object_list": (
                str(surface["main"]["selected_path"])
                == str(expected["main_object_list"])
            ),
            "bioluminescent_grass_carpet": (
                bool(
                    visual[
                        "bioluminescent_grass_carpet_available"
                    ]
                )
                == bool(
                    expected[
                        "bioluminescent_grass_carpet_available"
                    ]
                )
            ),
            "large_glowing_mushroom_tree": (
                bool(
                    visual[
                        "large_glowing_mushroom_tree_available"
                    ]
                )
                == bool(
                    expected[
                        "large_glowing_mushroom_tree_available"
                    ]
                )
            ),
            "small_glowing_mushroom_flora": (
                bool(
                    visual[
                        "small_glowing_mushroom_flora_available"
                    ]
                )
                == bool(
                    expected[
                        "small_glowing_mushroom_flora_available"
                    ]
                )
            ),
            "grass_primary_hex": (
                str(colour["grass"]["primary"]["hex"]).upper()
                == str(expected["grass_primary_hex"]).upper()
            ),
            "grass_alt_primary_hex": (
                str(
                    colour["grass_alt"]["primary"]["hex"]
                ).upper()
                == str(expected["grass_alt_primary_hex"]).upper()
            ),
        }
        for name, passed in checks.items():
            metrics[name]["correct"] += int(passed)
            if not passed:
                failures.append({
                    "control": expected["label"],
                    "field": name,
                })

        rows.append({
            "label": expected["label"],
            "system_portal": expected["system_portal"],
            "planet_portal": expected["planet_portal"],
            "source_file": surface["source_file"],
            "main_object_list": surface["main"]["selected_path"],
            **visual,
            "grass_primary_hex": (
                colour["grass"]["primary"]["hex"]
            ),
            "grass_alt_primary_hex": (
                colour["grass_alt"]["primary"]["hex"]
            ),
            "exact": all(checks.values()),
        })

    for metric in metrics.values():
        metric["exact"] = bool(
            metric["total"] > 0
            and metric["correct"] == metric["total"]
        )

    false_control = payload["broad_false_positive_control"]
    false_capability = surface_rule.capabilities[
        false_control["object_list"]
    ]
    false_visual = visual_rule.classify_capability(
        false_capability
    )
    false_positive_separation = {
        "broad_emissive_grass_true": (
            bool(
                false_visual[
                    "any_emissive_grass_asset_available"
                ]
            )
            is True
        ),
        "exact_bioluminescent_carpet_false": (
            bool(
                false_visual[
                    "bioluminescent_grass_carpet_available"
                ]
            )
            is False
        ),
        "toxicgrass_not_exact_carpet": (
            "MODELS/PLANETS/BIOMES/TOXIC/SMALL/"
            "TOXICGRASS.SCENE.MBIN"
            in false_visual["any_emissive_grass_scenes"]
            and "MODELS/PLANETS/BIOMES/COMMON/GRASS/"
            "BUBBLELUSHGRASS.SCENE.MBIN"
            not in false_visual[
                "bioluminescent_grass_carpet_scenes"
            ]
        ),
    }

    hilbert = next(
        row for row in rows
        if row["system_portal"] == "00ADFFB0FB0B"
    )
    euclid = next(
        row for row in rows
        if row["system_portal"] == "0091FED95966"
    )
    filter_checks = {
        "hilbert_exact_grass_include": planet_matches(
            {
                "glowing_grass_asset_available": hilbert[
                    "bioluminescent_grass_carpet_available"
                ],
                "glowing_mushroom_asset_available": hilbert[
                    "large_glowing_mushroom_tree_available"
                ],
                "grass_primary_hex": hilbert["grass_primary_hex"],
                "grass_alt_primary_hex": hilbert[
                    "grass_alt_primary_hex"
                ],
                "grass_primary_colour_family": "Red",
                "grass_alt_primary_colour_family": "Red",
            },
            {"colour": "Yellow"},
            glowing_grass=True,
        ),
        "hilbert_large_tree_excluded": not planet_matches(
            {
                "glowing_grass_asset_available": True,
                "glowing_mushroom_asset_available": False,
                "grass_primary_hex": hilbert["grass_primary_hex"],
                "grass_alt_primary_hex": hilbert[
                    "grass_alt_primary_hex"
                ],
                "grass_primary_colour_family": "Red",
                "grass_alt_primary_colour_family": "Red",
            },
            {"colour": "Yellow"},
            glowing_mushroom=True,
        ),
        "euclid_combined_exact_include": planet_matches(
            {
                "glowing_grass_asset_available": euclid[
                    "bioluminescent_grass_carpet_available"
                ],
                "glowing_mushroom_asset_available": euclid[
                    "large_glowing_mushroom_tree_available"
                ],
                "grass_primary_hex": euclid["grass_primary_hex"],
                "grass_alt_primary_hex": euclid[
                    "grass_alt_primary_hex"
                ],
                "grass_primary_colour_family": "Orange",
                "grass_alt_primary_colour_family": "Orange",
            },
            {"colour": "Yellow"},
            glowing_grass=True,
            glowing_mushroom=True,
        ),
        "either_colour_primary_match": planet_matches(
            {
                "glowing_grass_asset_available": True,
                "glowing_mushroom_asset_available": True,
                "grass_primary_hex": euclid["grass_primary_hex"],
                "grass_alt_primary_hex": euclid[
                    "grass_alt_primary_hex"
                ],
                "grass_primary_colour_family": "Orange",
                "grass_alt_primary_colour_family": "Orange",
            },
            {"colour": "Yellow"},
            either_grass_colour=euclid[
                "grass_primary_hex"
            ],
        ),
        "either_colour_alt_match": planet_matches(
            {
                "glowing_grass_asset_available": True,
                "glowing_mushroom_asset_available": True,
                "grass_primary_hex": euclid["grass_primary_hex"],
                "grass_alt_primary_hex": euclid[
                    "grass_alt_primary_hex"
                ],
                "grass_primary_colour_family": "Orange",
                "grass_alt_primary_colour_family": "Orange",
            },
            {"colour": "Yellow"},
            either_grass_colour=euclid[
                "grass_alt_primary_hex"
            ],
        ),
    }

    exact = bool(
        len(controls) == 2
        and all(metric["exact"] for metric in metrics.values())
        and all(false_positive_separation.values())
        and all(filter_checks.values())
        and not failures
    )
    return {
        "version": VERSION,
        "status": (
            "PASS_VISUAL_FLORA_REGRESSION_V20B2_EXACT"
            if exact
            else "ERROR_VISUAL_FLORA_REGRESSION_V20B2"
        ),
        "exact": exact,
        "control_count": len(controls),
        "metrics": metrics,
        "controls": rows,
        "false_positive_separation": false_positive_separation,
        "filter_checks": filter_checks,
        "failure_count": len(failures),
        "failures": failures,
        "claim_boundary": payload.get("claim_boundary", {}),
    }


def write_visual_flora_proof_outputs(
    result: dict[str, Any],
) -> dict[str, str]:
    output = OUTPUT_ROOT / f"visual_flora_proof_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "visual_flora_proof_v20b2.json"
    report_path = output / "OPEN_THIS_VISUAL_FLORA_PROOF_V20B2.txt"
    safe_json(json_path, result)

    lines = [
        "ATLAS APF — VISUAL FLORA PROOF V20B2",
        f"Timestamp={now_iso()}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"EXACT={result['exact']}",
        f"CONTROLS={result['control_count']}",
        f"FAILURES={result['failure_count']}",
        "",
        "LIVE-CONFIRMED CONTROLS",
        "-----------------------",
    ]
    for row in result["controls"]:
        lines.extend([
            f"CONTROL={row['label']}",
            f"SYSTEM_PORTAL={row['system_portal']}",
            f"PLANET_PORTAL={row['planet_portal']}",
            "BIOLUMINESCENT_GRASS_CARPET="
            f"{row['bioluminescent_grass_carpet_available']}",
            "LARGE_GLOWING_MUSHROOM_TREES="
            f"{row['large_glowing_mushroom_tree_available']}",
            "SMALL_GLOWING_MUSHROOM_FLORA="
            f"{row['small_glowing_mushroom_flora_available']}",
            f"GRASS_PRIMARY_HEX={row['grass_primary_hex']}",
            f"GRASS_ALT_PRIMARY_HEX={row['grass_alt_primary_hex']}",
            f"EXACT={row['exact']}",
            "",
        ])
    lines.extend([
        "FALSE-POSITIVE SEPARATION",
        "-------------------------",
    ])
    for name, passed in result[
        "false_positive_separation"
    ].items():
        lines.append(f"{name.upper()}={passed}")
    lines.extend(["", "FILTER CHECKS", "-------------"])
    for name, passed in result["filter_checks"].items():
        lines.append(f"{name.upper()}={passed}")
    report_path.write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }


def write_grass_glow_proof_outputs(
    result: dict[str, Any],
) -> dict[str, str]:
    output = OUTPUT_ROOT / f"grass_glow_proof_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "grass_glow_proof_v20a9.json"
    report_path = output / "OPEN_THIS_GRASS_GLOW_PROOF_V20A9.txt"
    safe_json(json_path, result)

    lines = [
        "ATLAS APF — GRASS / GLOW PROOF V20A9",
        f"Timestamp={now_iso()}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"EXACT={result['exact']}",
        f"PLANETS={result['planet_count']}",
        f"FAILURES={result['failure_count']}",
        "",
        "METRICS",
        "-------",
    ]
    for name, metric in result["metrics"].items():
        lines.append(
            f"{name.upper()}={metric['correct']}/{metric['total']} "
            f"EXACT={metric['exact']}"
        )
    lines.extend(["", "FILTER CHECKS", "-------------"])
    for name, passed in result["filter_checks"].items():
        lines.append(f"{name.upper()}={passed}")
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }



def run_atmosphere_regression() -> dict[str, Any]:
    return load_atmosphere_colour_rule().verify_regression(
        ATMOSPHERE_REGRESSION_PATH
    )


def write_atmosphere_proof_outputs(result: dict[str, Any]) -> dict[str, str]:
    output = OUTPUT_ROOT / f"atmosphere_proof_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "atmosphere_proof_v20d3r8.json"
    report_path = output / "OPEN_THIS_ATMOSPHERE_PROOF_V20D3R8.txt"
    safe_json(json_path, result)
    report_path.write_text(
        "\n".join([
            "ATLAS APF — ATMOSPHERE + NATIVE SKY PROOF V20D3R8",
            f"Timestamp={now_iso()}",
            f"Version={VERSION}",
            "",
            "RESULT",
            "------",
            f"STATUS={result['status']}",
            f"EXACT={result['exact']}",
            f"PLANETS={result['planet_count']}",
            f"CHECKS={result['correct']}/{result['total']}",
            f"FAILURES={len(result['failures'])}",
            "",
            f"CLAIM={result['claim']}",
        ]) + "\n",
        encoding="utf-8",
    )
    return {"folder": str(output), "json": str(json_path), "report": str(report_path)}


def run_names_water_regression_v1059() -> dict[str, Any]:
    failures: list[dict[str, Any]] = []
    planet_payload = load_json(PLANET_NAME_REGRESSION_PATH)
    planet_exact = 0
    for row in planet_payload.get("rows", []):
        actual = load_planet_name_engine().predict_planet_name(int(str(row["root"]), 0))
        ok = actual["default_procedural_name"] == row["name"]
        planet_exact += int(ok)
        if not ok:
            failures.append({"kind": "planet_name", "portal": row.get("portal")})
    system_payload = load_json(SYSTEM_NAME_REGRESSION_PATH)
    live = system_payload["live_control"]
    system_actual = load_system_name_engine().predict_system_name_from_portal(
        live["portal"], int(live["galaxy_index"])
    )
    system_live_exact = (
        system_actual["default_procedural_name"] == live["expected_default_name"]
    )
    summary_exact = bool(
        int(system_payload.get("native_differential_exact", 0))
        == int(system_payload.get("native_differential_total", -1))
        == 1_000_000
    )
    water_payload = load_json(WATER_PROFILE_REGRESSION_PATH)
    water_rows = list(water_payload.get("rows", []))
    water_exact = 0
    for row in water_rows:
        actual = load_water_profile_engine().predict(
            int(str(row["root_seed_hex"]), 0),
            int(row["biome"]),
            int(row["subtype"]),
        )
        expected = row["runtime"]
        ok = bool(
            int(actual["style"]["index"]) == int(expected.get("style_index", expected.get("style")))
            and int(actual["WaterEmission"]["enum"]) == int(expected.get("water_emission_enum", expected.get("water")))
            and int(actual["FoamEmission"]["enum"]) == int(expected.get("foam_emission_enum", expected.get("foam")))
            and str(actual["murkyness"]["bits_hex"]).casefold()
            == str(expected.get("murkyness_bits_hex", row.get("predicted", {}).get("murkyness", {}).get("bits_hex", ""))).casefold()
        )
        water_exact += int(ok)
        if not ok:
            failures.append({"kind": "water_profile", "portal": row.get("portal")})
    integrated = predict_system("00ABD05B73B8", 0)
    integrated_names = [row["default_procedural_planet_name"] for row in integrated["planet_rows"]]
    expected_names = [
        "Piyxisra Omega", "Joanneyro Ingu", "Bishenic XVIII",
        "Mere A2", "Tetri E43", "Toniane U8",
    ]
    integration_exact = bool(
        integrated["system"]["default_procedural_system_name"] == "Akeosc"
        and integrated_names == expected_names
        and integrated["system"]["economy_type_display"] == "Mercantile"
        and integrated["system"]["economy_tier_display"] == "Pirate"
        and integrated["system"]["conflict_level_display"] == "Pirate Controlled"
        and integrated["system"]["dominant_race_display"] == "Gek"
        and all(row.get("water_profile_exact") for row in integrated["planet_rows"])
    )
    exact = bool(
        planet_exact == 25
        and system_live_exact
        and summary_exact
        and water_exact == 25
        and integration_exact
        and not failures
    )
    return {
        "status": "PASS_NAMES_WATER_INTEGRATION_V1059" if exact else "ERROR_NAMES_WATER_INTEGRATION_V1059",
        "exact": exact,
        "planet_names_exact": f"{planet_exact}/25",
        "system_live_exact": f"{int(system_live_exact)}/1",
        "system_native_differential": "1000000/1000000" if summary_exact else "FAILED",
        "water_profiles_exact": f"{water_exact}/25",
        "outlaw_semantics_exact": integration_exact,
        "failures": failures,
    }


def run_doctor() -> dict[str, Any]:
    integrity = verify_integrity()
    life_creature_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        life_creature_static = (
            load_life_creature_engine().verify_static()
        )
        life_creature_static["error"] = ""
    except Exception as exc:
        life_creature_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )
    special_system_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        special_system_static = (
            load_special_system_engine().verify_static(
                SPECIAL_SYSTEM_REGRESSION_PATH
            )
        )
        special_system_static["error"] = ""
    except Exception as exc:
        special_system_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )
    special_planet_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        special_planet_static = (
            load_special_planet_engine().verify_static(
                SPECIAL_PLANET_REGRESSION_PATH
            )
        )
        special_planet_static["error"] = ""
    except Exception as exc:
        special_planet_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    sentinel_difficulty_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        sentinel_difficulty_static = (
            load_sentinel_difficulty_engine().verify_static(
                Path(),
                SENTINEL_DIFFICULTY_REGRESSION_PATH,
            )
        )
        sentinel_difficulty_static["error"] = ""
    except Exception as exc:
        sentinel_difficulty_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    terminology_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        terminology_static = (
            load_terminology_engine().verify_static(
                TERMINOLOGY_CATALOG_PATH,
                SENTINEL_DIFFICULTY_REGRESSION_PATH,
            )
        )
        terminology_static["error"] = ""
    except Exception as exc:
        terminology_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    fauna_taxonomy_static = {
        "exact": False,
        "checks": {},
        "error": "",
    }
    try:
        fauna_taxonomy_static = (
            load_fauna_taxonomy_engine().verify_static(
                FAUNA_TAXONOMY_CATALOG_PATH,
                FAUNA_DESCRIPTOR_CATALOG_PATH,
            )
        )
        fauna_taxonomy_static["error"] = ""
    except Exception as exc:
        fauna_taxonomy_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    grass_glow_static = {
        "exact": False,
        "status": "ERROR_GRASS_GLOW_STATIC_NOT_RUN",
        "error": "",
    }
    try:
        grass_glow_static = run_grass_glow_regression()
        grass_glow_static["error"] = ""
    except Exception as exc:
        grass_glow_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    visual_flora_static = {
        "exact": False,
        "status": "ERROR_VISUAL_FLORA_STATIC_NOT_RUN",
        "error": "",
    }
    try:
        visual_flora_static = run_visual_flora_regression()
        visual_flora_static["error"] = ""
    except Exception as exc:
        visual_flora_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )


    atmosphere_static = {
        "exact": False,
        "status": "ERROR_ATMOSPHERE_STATIC_NOT_RUN",
        "error": "",
    }
    try:
        atmosphere_static = run_atmosphere_regression()
        atmosphere_static["error"] = ""
    except Exception as exc:
        atmosphere_static["error"] = f"{type(exc).__name__}: {exc}"

    release_corrections_static = {
        "exact": False,
        "status": "ERROR_RELEASE_CORRECTIONS_V20H8_NOT_RUN",
        "error": "",
    }
    try:
        release_corrections_static = run_release_corrections_regression_v20h8()
        release_corrections_static["error"] = ""
    except Exception as exc:
        release_corrections_static["error"] = f"{type(exc).__name__}: {exc}"

    selector_mapping_static = {
        "exact": False,
        "status": "ERROR_SELECTOR_MAPPING_REGRESSION_V2_NOT_RUN",
        "error": "",
    }
    try:
        selector_mapping_static = run_selector_mapping_regression_v2()
        selector_mapping_static["error"] = ""
    except Exception as exc:
        selector_mapping_static["error"] = f"{type(exc).__name__}: {exc}"

    rendered_ring_static = {
        "exact": False,
        "status": "ERROR_RENDERED_RING_SELECTOR_V20J_NOT_RUN",
        "error": "",
    }
    try:
        rendered_ring_static = run_rendered_ring_regression_v20j()
        rendered_ring_static["error"] = ""
    except Exception as exc:
        rendered_ring_static["error"] = f"{type(exc).__name__}: {exc}"

    terrain_selector_static = {
        "exact": False,
        "status": "ERROR_TERRAIN_SETTING_SELECTOR_V20H20_NOT_RUN",
        "error": "",
    }
    try:
        terrain_selector_static = run_terrain_setting_selector_regression_v20h20()
        terrain_selector_static["error"] = ""
    except Exception as exc:
        terrain_selector_static["error"] = f"{type(exc).__name__}: {exc}"

    names_water_static = {
        "exact": False,
        "status": "ERROR_NAMES_WATER_INTEGRATION_V1059_NOT_RUN",
        "error": "",
    }
    try:
        names_water_static = run_names_water_regression_v1059()
        names_water_static["error"] = ""
    except Exception as exc:
        names_water_static["error"] = f"{type(exc).__name__}: {exc}"

    native_legacy_count_static = {
        "exact": False,
        "status": "ERROR_NATIVE_LEGACY_SYSTEM_COUNT_STATIC_NOT_RUN",
        "error": "",
    }
    try:
        native_legacy_count_static = (
            run_native_legacy_count_static_regression()
        )
        native_legacy_count_static["error"] = ""
    except Exception as exc:
        native_legacy_count_static["error"] = (
            f"{type(exc).__name__}: {exc}"
        )

    # The standalone runtime does not import or require Unicorn.
    unicorn_ready = False
    unicorn_version = "not required"
    unicorn_error = ""
    standalone_runtime_ready = True

    python_ready = sys.version_info >= (3, 10)
    ready = bool(
        integrity["exact"]
        and standalone_runtime_ready
        and python_ready
        and V4Y_PATH.is_file()
        and MODEL_PATH.is_file()
        and RESOURCE_LEVEL_REGRESSION_PATH.is_file()
        and SUBSTANCE_REGRESSION_PATH.is_file()
        and LIFE_CREATURE_ENGINE_PATH.is_file()
        and LIFE_REGRESSION_PATH.is_file()
        and CREATURE_DESCRIPTOR_REGRESSION_PATH.is_file()
        and SYSTEM_STATE_REGRESSION_PATH.is_file()
        and SPECIAL_SYSTEM_ENGINE_PATH.is_file()
        and SPECIAL_SYSTEM_REGRESSION_PATH.is_file()
        and SPECIAL_PLANET_REGRESSION_PATH.is_file()
        and SPECIAL_PLANET_ENGINE_PATH.is_file()
        and SENTINEL_DIFFICULTY_ENGINE_PATH.is_file()
        and SENTINEL_DIFFICULTY_REGRESSION_PATH.is_file()
        and TERMINOLOGY_ENGINE_PATH.is_file()
        and TERMINOLOGY_CATALOG_PATH.is_file()
        and FAUNA_TAXONOMY_ENGINE_PATH.is_file()
        and FAUNA_TAXONOMY_CATALOG_PATH.is_file()
        and FAUNA_DESCRIPTOR_CATALOG_PATH.is_file()
        and FAUNA_TAXONOMY_PROVENANCE_PATH.is_file()
        and CREATURE_TABLE_PATH.is_file()
        and SURFACE_OBJECTLIST_ENGINE_PATH.is_file()
        and SURFACE_OBJECTLIST_RULE_DATA_PATH.is_file()
        and OBJECTLIST_CAPABILITIES_PATH.is_file()
        and GRASS_COLOUR_ENGINE_PATH.is_file()
        and GRASS_COLOUR_RULE_DATA_PATH.is_file()
        and GRASS_GLOW_REGRESSION_PATH.is_file()
        and VISUAL_FLORA_ENGINE_PATH.is_file()
        and VISUAL_FLORA_RULE_DATA_PATH.is_file()
                and VISUAL_FLORA_REGRESSION_PATH.is_file()
        and ATMOSPHERE_COLOUR_ENGINE_PATH.is_file()
        and ATMOSPHERE_REGRESSION_PATH.is_file()
        and NATIVE_LEGACY_COUNT_ENGINE_PATH.is_file()
        and NATIVE_LEGACY_COUNT_CONTROLS_PATH.is_file()
        and SELECTOR_MAPPING_REGRESSION_PATH.is_file()
        and RING_SELECTOR_ENGINE_PATH.is_file()
        and RING_SELECTOR_LIVE_CORPUS_PATH.is_file()
        and atmosphere_static.get("exact", False)
        and selector_mapping_static.get("exact", False)
        and rendered_ring_static.get("exact", False)
        and native_legacy_count_static.get("exact", False)
        and life_creature_static.get("exact", False)
        and special_system_static.get("exact", False)
        and special_planet_static.get("exact", False)
        and sentinel_difficulty_static.get("exact", False)
        and terminology_static.get("exact", False)
        and fauna_taxonomy_static.get("exact", False)
        and grass_glow_static.get("exact", False)
        and visual_flora_static.get("exact", False)
        and release_corrections_static.get("exact", False)
        and terrain_selector_static.get("exact", False)
        and names_water_static.get("exact", False)
    )
    return {
        "version": VERSION,
        "timestamp": now_iso(),
        "status": (
            "PASS_CORE_V1_DOCTOR"
            if ready
            else "ERROR_CORE_V1_DOCTOR"
        ),
        "ready": ready,
        "python": {
            "version": sys.version,
            "ready": python_ready,
        },
        "unicorn": {
            "ready": unicorn_ready,
            "required": False,
            "version": unicorn_version,
            "error": unicorn_error,
        },
        "standalone_runtime": {
            "ready": standalone_runtime_ready,
            "nms_exe_required": False,
            "module_dump_required": False,
            "process_access": False,
            "admin_required": False,
        },
        "grass_colour_capability": {
            "universal_visible_colour_exact": False,
            "public_generated_palette_filters_enabled": True,
            "grass_primary_filter_scope": "slot_0",
            "grass_alt_primary_filter_scope": "slot_0",
            "combined_filter_scope": "all_ten_generated_slots",
            "reachable_generated_families": list(GRASS_COLOUR_FILTER_VALUES),
            "exact_unique_either_any_slot": grass_exact_colour_count(
                "either_any_slot"
            ),
            "exact_unique_grass_primary": grass_exact_colour_count(
                "grass_primary"
            ),
            "exact_unique_grass_alt_primary": grass_exact_colour_count(
                "grass_alt_primary"
            ),
            "white_rendered_colour_search_enabled": True,
            "white_rendered_colour_exact_input": "#AD9284",
            "white_rendered_colour_display": (
                "White #AD9284"
            ),
            "white_rendered_colour_reason": (
                "community_and_live_validated_exact_generated_input"
            ),
            "bioluminescent_bubble_grass_filter_enabled": True,
            "removed_unreachable_generated_families": [
                "White / pale neutral",
                "Black / very dark",
            ],
        },
        "planet_portal_target_hotfix": {
            "exact_planet_target_verified": False,
            "public_copy_scope": "canonical_system_address_only",
            "generated_slot_to_portal_planet_mapping_complete": True,
        },
        "integrity": integrity,
        "life_creature_static": life_creature_static,
        "special_system_static": special_system_static,
        "special_planet_static": special_planet_static,
        "sentinel_difficulty_static": sentinel_difficulty_static,
        "terminology_static": terminology_static,
        "fauna_taxonomy_static": fauna_taxonomy_static,
        "grass_glow_static": grass_glow_static,
        "visual_flora_static": visual_flora_static,
        "release_corrections_static": release_corrections_static,
        "terrain_selector_static": terrain_selector_static,
        "selector_mapping_static": selector_mapping_static,
        "rendered_ring_static": rendered_ring_static,
        "atmosphere_static": atmosphere_static,
        "native_legacy_count_static": native_legacy_count_static,
        "names_water_static": names_water_static,
        "paths": {
            "package_root": str(PACKAGE_ROOT),
            "engine": str(V4Y_PATH),
            "model": str(MODEL_PATH),
            "resource_level_regression": str(
                RESOURCE_LEVEL_REGRESSION_PATH
            ),
            "substance_regression": str(SUBSTANCE_REGRESSION_PATH),
            "life_creature_engine": str(LIFE_CREATURE_ENGINE_PATH),
            "life_regression": str(LIFE_REGRESSION_PATH),
            "creature_descriptor_regression": str(
                CREATURE_DESCRIPTOR_REGRESSION_PATH
            ),
            "system_state_regression": str(
                SYSTEM_STATE_REGRESSION_PATH
            ),
            "special_system_engine": str(
                SPECIAL_SYSTEM_ENGINE_PATH
            ),
            "special_system_regression": str(
                SPECIAL_SYSTEM_REGRESSION_PATH
            ),
            "special_planet_regression": str(
                SPECIAL_PLANET_REGRESSION_PATH
            ),
            "special_planet_engine": str(
                SPECIAL_PLANET_ENGINE_PATH
            ),
            "sentinel_difficulty_engine": str(
                SENTINEL_DIFFICULTY_ENGINE_PATH
            ),
            "sentinel_difficulty_regression": str(
                SENTINEL_DIFFICULTY_REGRESSION_PATH
            ),
            "terminology_engine": str(TERMINOLOGY_ENGINE_PATH),
            "terminology_catalog": str(TERMINOLOGY_CATALOG_PATH),
            "fauna_taxonomy_engine": str(FAUNA_TAXONOMY_ENGINE_PATH),
            "fauna_taxonomy_catalog": str(FAUNA_TAXONOMY_CATALOG_PATH),
            "fauna_descriptor_catalog": str(FAUNA_DESCRIPTOR_CATALOG_PATH),
            "fauna_taxonomy_provenance": str(FAUNA_TAXONOMY_PROVENANCE_PATH),
            "surface_objectlist_engine": str(SURFACE_OBJECTLIST_ENGINE_PATH),
            "surface_objectlist_rule_data": str(SURFACE_OBJECTLIST_RULE_DATA_PATH),
            "objectlist_capabilities": str(OBJECTLIST_CAPABILITIES_PATH),
            "grass_colour_engine": str(GRASS_COLOUR_ENGINE_PATH),
            "grass_colour_rule_data": str(GRASS_COLOUR_RULE_DATA_PATH),
            "grass_glow_regression": str(GRASS_GLOW_REGRESSION_PATH),
            "visual_flora_engine": str(VISUAL_FLORA_ENGINE_PATH),
            "visual_flora_rule_data": str(VISUAL_FLORA_RULE_DATA_PATH),
            "visual_flora_regression": str(VISUAL_FLORA_REGRESSION_PATH),
            "atmosphere_colour_engine": str(ATMOSPHERE_COLOUR_ENGINE_PATH),
            "atmosphere_regression": str(ATMOSPHERE_REGRESSION_PATH),
            "native_sky_tables": str(NATIVE_SKY_TABLES_PATH),
            "native_sky_index_regression": str(NATIVE_SKY_INDEX_REGRESSION_PATH),
            "native_legacy_count_engine": str(NATIVE_LEGACY_COUNT_ENGINE_PATH),
            "native_legacy_count_controls": str(NATIVE_LEGACY_COUNT_CONTROLS_PATH),
            "native_legacy_count_cache": str(NATIVE_LEGACY_COUNT_CACHE_PATH),
            "planet_name_engine": str(PLANET_NAME_ENGINE_PATH),
            "system_name_engine": str(SYSTEM_NAME_ENGINE_PATH),
            "water_profile_engine": str(WATER_PROFILE_ENGINE_PATH),
            "planet_name_regression": str(PLANET_NAME_REGRESSION_PATH),
            "system_name_regression": str(SYSTEM_NAME_REGRESSION_PATH),
            "water_profile_regression": str(WATER_PROFILE_REGRESSION_PATH),
            "rendered_ring_engine": str(RING_SELECTOR_ENGINE_PATH),
            "rendered_ring_live_corpus": str(RING_SELECTOR_LIVE_CORPUS_PATH),
            "output_root": str(OUTPUT_ROOT),
        },
    }


def write_doctor_outputs(result: dict[str, Any]) -> dict[str, str]:
    output = OUTPUT_ROOT / f"doctor_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "doctor_core_v1.json"
    report_path = output / "OPEN_THIS_DOCTOR_CORE_V1.txt"
    safe_json(json_path, result)

    lines = [
        "ATLAS APF — CORE V1 DOCTOR",
        f"Timestamp={result['timestamp']}",
        f"STATUS={result['status']}",
        f"READY={result['ready']}",
        f"PYTHON_READY={result['python']['ready']}",
        f"PYTHON_VERSION={result['python']['version']}",
        f"UNICORN_READY={result['unicorn']['ready']}",
        f"UNICORN_VERSION={result['unicorn']['version']}",
        f"UNICORN_ERROR={result['unicorn']['error']}",
        f"INTEGRITY_EXACT={result['integrity']['exact']}",
        f"INTEGRITY_FILES={result['integrity']['exact_count']}/{result['integrity']['file_count']}",
        f"NAMES_WATER_EXACT={result['names_water_static'].get('exact', False)}",
        f"NAMES_WATER_STATUS={result['names_water_static'].get('status', '')}",
        (
            "RELEASE_CORRECTIONS_EXACT="
            f"{result['release_corrections_static'].get('exact', False)}"
        ),
        (
            "RENDERED_RING_SELECTOR_EXACT="
            f"{result['rendered_ring_static'].get('exact', False)}"
        ),
        (
            "RENDERED_RING_SELECTOR_STATUS="
            f"{result['rendered_ring_static'].get('status', '')}"
        ),
        (
            "LIFE_CREATURE_STATIC_EXACT="
            f"{result['life_creature_static'].get('exact', False)}"
        ),
        (
            "LIFE_CREATURE_STATIC_ERROR="
            f"{result['life_creature_static'].get('error', '')}"
        ),
        (
            "SPECIAL_SYSTEM_STATIC_EXACT="
            f"{result['special_system_static'].get('exact', False)}"
        ),
        (
            "SPECIAL_SYSTEM_STATIC_ERROR="
            f"{result['special_system_static'].get('error', '')}"
        ),
        (
            "SPECIAL_PLANET_STATIC_EXACT="
            f"{result['special_planet_static'].get('exact', False)}"
        ),
        (
            "SPECIAL_PLANET_STATIC_ERROR="
            f"{result['special_planet_static'].get('error', '')}"
        ),
        (
            "SENTINEL_DIFFICULTY_STATIC_EXACT="
            f"{result['sentinel_difficulty_static'].get('exact', False)}"
        ),
        (
            "SENTINEL_DIFFICULTY_STATIC_ERROR="
            f"{result['sentinel_difficulty_static'].get('error', '')}"
        ),
        (
            "EXACT_TERMINOLOGY_STATIC_EXACT="
            f"{result['terminology_static'].get('exact', False)}"
        ),
        (
            "EXACT_TERMINOLOGY_STATIC_ERROR="
            f"{result['terminology_static'].get('error', '')}"
        ),
        (
            "FAUNA_TAXONOMY_STATIC_EXACT="
            f"{result['fauna_taxonomy_static'].get('exact', False)}"
        ),
        (
            "FAUNA_TAXONOMY_STATIC_ERROR="
            f"{result['fauna_taxonomy_static'].get('error', '')}"
        ),
        (
            "GRASS_GLOW_STATIC_EXACT="
            f"{result['grass_glow_static'].get('exact', False)}"
        ),
        (
            "GRASS_GLOW_STATIC_STATUS="
            f"{result['grass_glow_static'].get('status', '')}"
        ),
        (
            "GRASS_GLOW_STATIC_ERROR="
            f"{result['grass_glow_static'].get('error', '')}"
        ),
        (
            "VISUAL_FLORA_STATIC_EXACT="
            f"{result['visual_flora_static'].get('exact', False)}"
        ),
        (
            "VISUAL_FLORA_STATIC_STATUS="
            f"{result['visual_flora_static'].get('status', '')}"
        ),
        (
            "VISUAL_FLORA_STATIC_ERROR="
            f"{result['visual_flora_static'].get('error', '')}"
        ),
        (
            "ATMOSPHERE_STATIC_EXACT="
            f"{result['atmosphere_static'].get('exact', False)}"
        ),
        (
            "ATMOSPHERE_STATIC_ERROR="
            f"{result['atmosphere_static'].get('error', '')}"
        ),
        (
            "SELECTOR_MAPPING_STATIC_EXACT="
            f"{result['selector_mapping_static'].get('exact', False)}"
        ),
        (
            "SELECTOR_MAPPING_STATIC_STATUS="
            f"{result['selector_mapping_static'].get('status', '')}"
        ),
        (
            "SELECTOR_MAPPING_STATIC_SYSTEMS="
            f"{result['selector_mapping_static'].get('systems', 0)}/30"
        ),
        (
            "SELECTOR_MAPPING_STATIC_PLANETS="
            f"{result['selector_mapping_static'].get('planets', 0)}/149"
        ),
        (
            "SELECTOR_MAPPING_STATIC_ERROR="
            f"{result['selector_mapping_static'].get('error', '')}"
        ),
        (
            "NATIVE_LEGACY_COUNT_STATIC_EXACT="
            f"{result['native_legacy_count_static'].get('exact', False)}"
        ),
        (
            "NATIVE_LEGACY_COUNT_STATIC_STATUS="
            f"{result['native_legacy_count_static'].get('status', '')}"
        ),
        (
            "NATIVE_LEGACY_COUNT_STATIC_ERROR="
            f"{result['native_legacy_count_static'].get('error', '')}"
        ),
        "",
        "FAILED FILES",
        "------------",
    ]
    failed = [
        row for row in result["integrity"]["rows"]
        if not row["exact"]
    ]
    if not failed:
        lines.append("NONE")
    else:
        for row in failed:
            lines.append(
                f"{row['relative_path']} "
                f"EXISTS={row['exists']} "
                f"SIZE={row['observed_size']}/{row['expected_size']} "
                f"HASH={row['observed_sha256']}/{row['expected_sha256']}"
            )
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }


def run_live_hardening_regression_v1045() -> dict[str, Any]:
    """Replay the live-tested systems and visual controls used by the current release."""
    systems = {
        portal: predict_system(portal, 0)
        for portal in ("0072239D7F56", "01F0239D6F69")
    }
    rows = {
        str(row.get("exact_planet_portal_address", "")).upper(): row
        for result in systems.values()
        for row in result.get("planet_rows", [])
    }
    checks: dict[str, bool] = {}

    sentinel_expected = {
        "1072239D7F56": "Low",
        "2072239D7F56": "Isolated",
        "3072239D7F56": "Low",
        "4072239D7F56": "Sparse",
        "5072239D7F56": "Irregular Patrols",
        "6072239D7F56": "Intermittent",
        "11F0239D6F69": "Spread Thin",
        "21F0239D6F69": "Minimal",
        "31F0239D6F69": "Spread Thin",
        "41F0239D6F69": "Sparse",
        "51F0239D6F69": "Low",
        "61F0239D6F69": "Sparse",
    }
    for portal, expected in sentinel_expected.items():
        row = rows.get(portal, {})
        checks[f"sentinel_{portal}"] = bool(
            row.get("sentinel_discovery_exact")
            and row.get("sentinel_discovery_display") == expected
        )

    field_controls = {
        "flora_4072239D7F56": ("4072239D7F56", "flora_display", "Between Worlds"),
        "flora_51F0239D6F69": ("51F0239D6F69", "flora_display", "Lost"),
        "weather_61F0239D6F69": ("61F0239D6F69", "weather_display", "All-Consuming Fog"),
        "weather_21F0239D6F69": ("21F0239D6F69", "weather_display", "Thermonuclear Fog"),
        "severity_61F0239D6F69": ("61F0239D6F69", "weather_severity_display", "Extreme"),
        "severity_21F0239D6F69": ("21F0239D6F69", "weather_severity_display", "Extreme"),
        "severity_11F0239D6F69": ("11F0239D6F69", "weather_severity_display", "Extreme"),
        "water_21F0239D6F69": ("21F0239D6F69", "water_active", True),
        "water_41F0239D6F69": ("41F0239D6F69", "water_active", True),
        "terrain_11F0239D6F69": ("11F0239D6F69", "terrain_family_display", "Craters"),
        "terrain_31F0239D6F69": ("31F0239D6F69", "terrain_family_display", "Alien"),
        "terrain_61F0239D6F69": ("61F0239D6F69", "terrain_family_display", "Floating Islands (terrain)"),
        "terrain_2072239D7F56": ("2072239D7F56", "terrain_family_display", "Lily Pad"),
        "filter_51F0239D6F69": (
            "51F0239D6F69",
            "visual_filter_display",
            "Monochrome / selective-colour exotic filter",
        ),
    }
    for name, (portal, field, expected) in field_controls.items():
        checks[name] = rows.get(portal, {}).get(field) == expected

    # Static optional-object compatibility exposed in the Resources tab.
    biome_intelligence = load_biome_table_intelligence()
    optional_groups = dict(biome_intelligence.get("optional_object_groups", {}))
    valuable_group = dict(optional_groups.get("VALUABLE_STUFF", {}))
    new_scrap_group = dict(optional_groups.get("NEW_SCRAP", {}))
    valuable_names = {
        str(item.get("name", ""))
        for item in valuable_group.get("object_files", [])
        if isinstance(item, dict)
    }
    checks["resources_bones_old_salvage_one_of_two"] = bool(
        {"PROC_BONES", "PROC_SALVAGE"}.issubset(valuable_names)
        and str(valuable_group.get("min_files", "")) == "1"
        and str(valuable_group.get("max_files", "")) == "1"
    )
    checks["resources_bones_excluded_on_current_scrap"] = bool(
        str(valuable_group.get("not_on_scrap_worlds", "")).casefold() == "true"
        and str(new_scrap_group.get("only_on_scrap_worlds", "")).casefold() == "true"
    )

    # V20H23 comprehensive mapping corrections.
    weather_replay_source = COMPLETE_WEATHER_ENGINE_PATH.read_text(encoding="utf-8")
    checks.update({
        "special_weather_state3_demotion_removed": (
            "reference_state_demoted_2" not in weather_replay_source
        ),
        "special_weather_native_index_override_present": (
            "index2_special_state3_to_13"
            in (ENGINE_DIR / "fibonacci_nms_live_weather_index_replay_validator_v4c.py").read_text(encoding="utf-8")
        ),
        "ruined_native_family_map_exact": (
            RUINED_DESCRIPTION_FAMILY_BY_BIOME_V20H23
            == {
                0: "RUINEDLUSH", 1: "RUINEDTOX", 2: "RUINEDHOT",
                3: "RUINEDRAD", 4: "RUINEDCOLD", 5: "RUINEDDUST",
            }
        ),
        "rgb_functional_storm_state_exact": (
            functional_weather_metadata({
                "biome": 8, "weather_active": 0, "weather_mode": 1,
            })["weather_storm_frequency"] == "Occasional storms"
        ),
        "waterworld_functional_storm_state_exact": (
            functional_weather_metadata({
                "biome": 14, "weather_active": 1, "weather_mode": 0,
            })["weather_storm_frequency"] == "Extreme storms"
        ),
    })

    # V20H23 locked 27-system / 149-planet read-only mapping corpus.
    mapping_payload = load_json(COMPREHENSIVE_MAPPING_WEATHER_REGRESSION_PATH)
    mapping_rows = list(mapping_payload.get("rows", []))
    mapping_systems = {
        str(row.get("system_address", "")).upper()
        for row in mapping_rows
    }
    mapping_predictions = {
        portal: {
            int(row.get("slot", -1)): row
            for row in predict_system(portal, 0).get("planet_rows", [])
        }
        for portal in sorted(mapping_systems)
    }
    mapping_fields = (
        "biome", "biome_subtype", "weather_index", "weather_active",
        "weather_mode", "weather_flag", "weather_intensity",
        "special_weather_state",
    )
    mapping_exact_rows = 0
    mapping_diagnostic_exact_rows = 0
    for expected in mapping_rows:
        portal = str(expected.get("system_address", "")).upper()
        slot = int(expected.get("slot", -1))
        actual = mapping_predictions.get(portal, {}).get(slot, {})
        row_exact = all(
            actual.get(field) == expected.get(field)
            for field in mapping_fields
        )
        mapping_exact_rows += int(row_exact)
        if expected.get("capture_kind") == "retained_diagnostic":
            mapping_diagnostic_exact_rows += int(row_exact)
    mapping_metrics = dict(mapping_payload.get("metrics", {}))
    checks.update({
        "mapping_corpus_27_systems": (
            len(mapping_systems) == 27
            and mapping_metrics.get("systems_total") == 27
        ),
        "mapping_corpus_149_planets_exact": (
            len(mapping_rows) == 149
            and mapping_exact_rows == 149
            and mapping_metrics.get("planets_exact") == 149
        ),
        "mapping_four_diagnostic_systems_recovered": (
            mapping_metrics.get("retained_diagnostic_systems") == 4
            and mapping_diagnostic_exact_rows
            == mapping_metrics.get("retained_diagnostic_planets")
            == 22
        ),
        "mapping_claim_boundary_preserved": (
            "economy_tier"
            in mapping_payload.get("claim_boundary", {}).get("not_claimed", [])
            and "screen_filter_selected_index"
            in mapping_payload.get("claim_boundary", {}).get("not_claimed", [])
        ),
    })

    # UI and dropdown hardening: one authoritative field per public control,
    # with raw/legacy options confined to the Expert tab.
    gui_source = (HERE / "any_planet_finder_gui.py").read_text(encoding="utf-8")
    checks.update({
        "ui_exact_sentinel_heading": "Sentinel category / in-game wording" in gui_source,
        "ui_weather_semantics_heading": "Storms / passive hazard" in gui_source,
        "ui_major_mushroom_label": "Major mushroom-style flora set" in gui_source,
        "ui_legacy_sentinel_raw_expert": "Maximum legacy Sentinel level (raw)" in gui_source,
        "ui_sentinel_dependency_guard": "def _on_sentinel_difficulty_changed" in gui_source,
        "ui_no_old_standard_sentinel_heading": (
            "Sentinel activity (Standard combat)" not in gui_source
        ),
        "ui_no_old_functional_weather_heading": (
            '"functional_weather": "Functional weather"' not in gui_source
        ),
        "ui_resources_tab_present": 'text="Resources"' in gui_source,
        "ui_portal_address_heading": '"planet": "Portal Address"' in gui_source,
        "ui_export_complete_find_table": "self.export_tree_columns = columns" in gui_source,
        "ui_unexported_close_warning": "Unexported search results" in gui_source,
        "ui_hidden_vbs_launcher": (
            (
                (HERE.parent / "start_finder.cmd").is_file()
                and "start_finder.vbs" in (
                    HERE.parent / "start_finder.cmd"
                ).read_text(encoding="utf-8")
            )
            or (
                (PACKAGE_ROOT / "START_HERE.cmd").is_file()
                and "ATLAS_APF.exe" in (
                    PACKAGE_ROOT / "START_HERE.cmd"
                ).read_text(encoding="utf-8")
            )
        ),
        "ui_anchor_glyph_explicit_binding": (
            "command=self._open_find_anchor_glyph_keypad" in gui_source
            and "self.find_anchor_glyph_button" in gui_source
            and "self.find_anchor_var" in gui_source
        ),
        "ui_selected_portal_single_authority": (
            'selectmode="browse"' in gui_source
            and 'self.find_tree.focus()' in gui_source
            and 'Portal Address: {planet_address}' in gui_source
        ),
        "ui_nms_running_worker_guard": (
            "def _nms_process_running" in gui_source
            and "tasklist.exe" in gui_source
            and "automatic // 2" in gui_source
            and "No Man's Sky is running" in gui_source
        ),
        "ui_screen_filter_not_guessed": (
            'text="Planet screen filter"' in gui_source
            and "Unavailable until the exact screen-filter selector is recovered" in gui_source
        ),
        "ui_exact_economy_conflict_filters": (
            '"Economy type"' in gui_source
            and '"Economy tier"' in gui_source
            and '"Conflict level"' in gui_source
            and "core.economy_type_filter_values()" in gui_source
            and "core.economy_tier_filter_values()" in gui_source
            and "core.conflict_level_filter_values()" in gui_source
            and "Choose an exact economy tier or use ★★ or higher" in gui_source
            and "core.dominant_race_filter_values()" in gui_source
            and "core.ECONOMY_TIER_AT_LEAST_MEDIUM" in gui_source
            and "core.CONFLICT_LEVEL_AT_MOST_MEDIUM" in gui_source
        ),
        "ui_exact_generated_water_filters": (
            "Generated Water palette contains" in gui_source
            and "Deep-water biolum palette contains" in gui_source
        ),
    })

    dropdown_sets = {
        "planet_classification": planet_classification_filter_values(),
        "terrain_family": terrain_family_filter_values(),
        "weather_family": weather_family_filter_values(),
        "grass_colour": grass_colour_filter_values(),
        "atmosphere_colour": day_atmosphere_filter_values(),
        "sentinel_activity": sentinel_activity_filter_values(),
        "on_foot_combat": on_foot_combat_difficulty_values(),
    }
    for name, values in dropdown_sets.items():
        checks[f"dropdown_{name}_nonempty"] = bool(values)
        checks[f"dropdown_{name}_unique"] = len(values) == len(set(values))
        checks[f"dropdown_{name}_strings"] = all(
            isinstance(value, str) and bool(value.strip()) for value in values
        )

    return {
        "version": VERSION,
        "status": (
            "PASS_LIVE_HARDENING_REGRESSION_V1_0_45"
            if all(checks.values())
            else "ERROR_LIVE_HARDENING_REGRESSION_V1_0_45"
        ),
        "exact": all(checks.values()),
        "checks": checks,
        "correct": sum(bool(value) for value in checks.values()),
        "total": len(checks),
        "systems": list(systems),
        "planet_controls": len(rows),
    }


def run_self_test(
    progress: Callable[[int, int, str], None] | None = None,
) -> dict[str, Any]:
    doctor = run_doctor()
    if not doctor["ready"]:
        return {
            "version": VERSION,
            "timestamp": now_iso(),
            "status": "ERROR_CORE_V1_SELF_TEST_DOCTOR_FAILED",
            "doctor": doctor,
            "ready": False,
        }

    plan = load_json(V5J_PLAN_PATH)
    targets = list(plan.get("targets", []))
    expected_system_count = len(targets)
    negative_y_plan = load_json(NEGATIVE_Y_REGRESSION_PATH)
    negative_y_targets = list(negative_y_plan.get("targets", []))
    resource_regression = load_json(RESOURCE_LEVEL_REGRESSION_PATH)
    resource_rows = list(resource_regression.get("rows", []))
    substance_regression = load_json(SUBSTANCE_REGRESSION_PATH)
    substance_rows = list(substance_regression.get("rows", []))
    substance_systems = sorted({str(row["system_portal"]).upper() for row in substance_rows})
    resource_static = verify_resource_writer_static()
    progress_system_count = expected_system_count + len(negative_y_targets) + len(substance_systems)

    metrics = {
        "systems": {"correct": 0, "total": expected_system_count},
        "numeric": {"correct": 0, "total": 0},
        "description_family": {"correct": 0, "total": 0},
        "description_token": {"correct": 0, "total": 0},
        "weather_family": {"correct": 0, "total": 0},
        "weather_token": {"correct": 0, "total": 0},
        "is_weather_extreme": {"correct": 0, "total": 0},
        "weather_clear_family": {"correct": 0, "total": 0},
        "weather_extreme_family": {"correct": 0, "total": 0},
        "literal_paradise": {"correct": 0, "total": 0},
        "negative_y_systems": {"correct": 0, "total": len(negative_y_targets)},
        "negative_y_planets": {"correct": 0, "total": 0},
        "negative_y_description_token": {"correct": 0, "total": 0},
        "negative_y_weather_token": {"correct": 0, "total": 0},
        "negative_y_branches": {"correct": 0, "total": 0},
        "resource_writer_static": {
            "correct": sum(resource_static["checks"].values()),
            "total": len(resource_static["checks"]),
        },
        "resource_level": {"correct": 0, "total": 0},
        "resources_family": {"correct": 0, "total": 0},
        "resources_token": {"correct": 0, "total": 0},
        "substance_weather_active_gate": {"correct": 0, "total": 0},
        "common_substance_id": {"correct": 0, "total": 0},
        "uncommon_substance_id": {"correct": 0, "total": 0},
        "rare_substance_id": {"correct": 0, "total": 0},
        "life_numeric": {"correct": 0, "total": 0},
        "flora_token": {"correct": 0, "total": 0},
        "fauna_standard_token": {"correct": 0, "total": 0},
        "fauna_weird_token": {"correct": 0, "total": 0},
        "fauna_robot_token": {"correct": 0, "total": 0},
        "source_system_kind": {"correct": 0, "total": 0},
        "in_empty_system": {"correct": 0, "total": 0},
        "special_system_controls": {"correct": 0, "total": 0},
        "special_system_fields": {"correct": 0, "total": 0},
        "special_planet_index": {"correct": 0, "total": 0},
        "special_planet_infested": {"correct": 0, "total": 0},
        "special_planet_dissonant": {"correct": 0, "total": 0},
        "special_planet_pattern": {"correct": 0, "total": 0},
        "special_planet_existing_sentinel": {"correct": 0, "total": 0},
        "special_planet_dissonant_filter": {"correct": 0, "total": 0},
        "special_planet_infested_filter": {"correct": 0, "total": 0},
        "sentinel_difficulty_patterns": {"correct": 0, "total": 0},
        "sentinel_difficulty_enums": {"correct": 0, "total": 0},
        "sentinel_difficulty_non_dissonant": {"correct": 0, "total": 0},
        "sentinel_difficulty_dissonance": {"correct": 0, "total": 0},
        "sentinel_difficulty_existing_level": {"correct": 0, "total": 0},
        "sentinel_difficulty_filter": {"correct": 0, "total": 0},
        "terminology_catalog_tokens": {"correct": 0, "total": 0},
        "terminology_planet_classification": {"correct": 0, "total": 0},
        "terminology_weather": {"correct": 0, "total": 0},
        "terminology_resources": {"correct": 0, "total": 0},
        "terminology_fauna": {"correct": 0, "total": 0},
        "terminology_flora": {"correct": 0, "total": 0},
        "terminology_placeholder_expansion": {"correct": 0, "total": 0},
        "terminology_observed_planet_text": {"correct": 0, "total": 0},
        "terminology_observed_weather_text": {"correct": 0, "total": 0},
        "terminology_internal_tokens_preserved": {"correct": 0, "total": 0},
        "fauna_taxonomy_descriptor_tokens": {"correct": 0, "total": 0},
        "fauna_taxonomy_profile_labels": {"correct": 0, "total": 0},
        "fauna_taxonomy_profile_rows": {"correct": 0, "total": 0},
        "fauna_taxonomy_claim_boundary": {"correct": 0, "total": 0},
        "fauna_taxonomy_snake_worm_separation": {"correct": 0, "total": 0},
        "hardening_portal_validation": {"correct": 0, "total": 0},
        "hardening_integer_validation": {"correct": 0, "total": 0},
        "hardening_profile_roundtrip": {"correct": 0, "total": 0},
        "hardening_profile_corruption_recovery": {"correct": 0, "total": 0},
        "hardening_state_roundtrip": {"correct": 0, "total": 0},
        "hardening_export_bundle": {"correct": 0, "total": 0},
        "hardening_comparison": {"correct": 0, "total": 0},
        "hardening_error_bundle": {"correct": 0, "total": 0},
        "address_descriptor_primary": {"correct": 0, "total": 0},
        "address_descriptor_aux_1": {"correct": 0, "total": 0},
        "address_descriptor_aux_2": {"correct": 0, "total": 0},
        "address_descriptor_aux_3": {"correct": 0, "total": 0},
        "address_creature_life": {"correct": 0, "total": 0},
        "life_creature_static": {"correct": 0, "total": 0},
        "classification_filter_catalog": {"correct": 0, "total": 0},
        "classification_filter_match": {"correct": 0, "total": 0},
        "classification_filter_catalog_coverage": {"correct": 0, "total": 0},
        "classification_filter_normalization": {"correct": 0, "total": 0},
        "filter_proof_v19i1b": {"correct": 0, "total": 0},
        "grass_glow_regression_v20a9": {"correct": 0, "total": 0},
        "visual_flora_regression_v20b2": {"correct": 0, "total": 0},
        "release_corrections_v20h15": {"correct": 0, "total": 0},
        "terrain_setting_selector_v20h20": {"correct": 0, "total": 0},
        "live_hardening_v1_0_45": {"correct": 0, "total": 0},
        "selector_mapping_v2": {"correct": 0, "total": 0},
        "rendered_rings_v20j": {"correct": 0, "total": 0},
    }
    failures: list[dict[str, Any]] = []

    for index, target in enumerate(targets, start=1):
        portal = target["portal"]
        if progress:
            progress(index, progress_system_count, portal)
        print(
            f"SELF_TEST_SYSTEM={index}/{progress_system_count} "
            f"PORTAL={portal}",
            flush=True,
        )
        prediction = predict_system(
            portal,
            int(target.get("galaxy_index", 0)),
        )
        actual_by_slot = {
            int(row["slot"]): row
            for row in prediction["planet_rows"]
        }
        expected_rows = list(target["planet_rows"])
        system_ok = (
            int(prediction["system"]["planet_count"])
            == int(target["system"]["planet_count"])
            and int(prediction["system"]["star_type"])
            == int(target["system"]["star_type"])
            and set(actual_by_slot)
            == {int(row["slot"]) for row in expected_rows}
        )
        metrics["systems"]["correct"] += int(system_ok)
        if not system_ok:
            failures.append({
                "portal": portal,
                "field": "system",
                "actual": prediction["system"],
                "expected": target["system"],
            })

        for expected in expected_rows:
            slot = int(expected["slot"])
            actual = actual_by_slot.get(slot)
            if actual is None:
                failures.append({
                    "portal": portal,
                    "slot": slot,
                    "field": "missing_slot",
                })
                continue

            numeric_ok = True
            numeric_mismatches = []
            for field in NUMERIC_VALIDATION_FIELDS:
                metrics["numeric"]["total"] += 0  # counted once per row below
                if field not in expected:
                    continue
                if not compare_values(
                    field,
                    actual.get(field),
                    expected.get(field),
                ):
                    numeric_ok = False
                    numeric_mismatches.append({
                        "field": field,
                        "actual": actual.get(field),
                        "expected": expected.get(field),
                    })
            metrics["numeric"]["total"] += 1
            metrics["numeric"]["correct"] += int(numeric_ok)
            if not numeric_ok:
                failures.append({
                    "portal": portal,
                    "slot": slot,
                    "field": "numeric",
                    "mismatches": numeric_mismatches,
                })

            expected_branches = expected["branch_prediction"]
            for field in (
                "is_weather_extreme",
                "weather_clear_family",
                "weather_extreme_family",
                "literal_paradise",
            ):
                metrics[field]["total"] += 1
                exact = bool(actual[field]) == bool(
                    expected_branches[field]
                )
                metrics[field]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": field,
                        "actual": actual[field],
                        "expected": expected_branches[field],
                    })

            expected_description = expected["description_prediction"]
            if expected_description.get("family"):
                metrics["description_family"]["total"] += 1
                exact = (
                    actual["description_family"]
                    == expected_description["family"]
                )
                metrics["description_family"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "description_family",
                        "actual": actual["description_family"],
                        "expected": expected_description["family"],
                    })
            if expected_description.get("predicted_token"):
                metrics["description_token"]["total"] += 1
                exact = (
                    actual["description_token"]
                    == expected_description["predicted_token"]
                )
                metrics["description_token"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "description_token",
                        "actual": actual["description_token"],
                        "expected": expected_description[
                            "predicted_token"
                        ],
                    })

            expected_weather = expected["weather_prediction"]
            if expected_weather.get("family"):
                metrics["weather_family"]["total"] += 1
                exact = (
                    actual["weather_family"]
                    == expected_weather["family"]
                )
                metrics["weather_family"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "weather_family",
                        "actual": actual["weather_family"],
                        "expected": expected_weather["family"],
                    })
            if expected_weather.get("predicted_token"):
                metrics["weather_token"]["total"] += 1
                exact = (
                    actual["weather_token"]
                    == expected_weather["predicted_token"]
                )
                metrics["weather_token"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "weather_token",
                        "actual": actual["weather_token"],
                        "expected": expected_weather[
                            "predicted_token"
                        ],
                    })


    for negative_index, target in enumerate(negative_y_targets, start=1):
        portal = target["portal"]
        progress_index = expected_system_count + negative_index
        if progress:
            progress(progress_index, progress_system_count, portal)
        print(
            f"SELF_TEST_NEGATIVE_Y_SYSTEM={progress_index}/"
            f"{progress_system_count} PORTAL={portal}",
            flush=True,
        )
        prediction = predict_system(
            portal,
            int(target.get("galaxy_index", 0)),
        )
        actual_by_slot = {
            int(row["slot"]): row
            for row in prediction["planet_rows"]
        }
        system_ok = (
            int(prediction["system"]["planet_count"])
            == int(target["system"]["planet_count"])
            and int(prediction["system"]["star_type"])
            == int(target["system"]["star_type"])
            and set(actual_by_slot)
            == {int(row["slot"]) for row in target["planet_rows"]}
        )
        metrics["negative_y_systems"]["correct"] += int(system_ok)
        if not system_ok:
            failures.append({
                "portal": portal,
                "field": "negative_y_system",
                "actual": prediction["system"],
                "expected": target["system"],
            })

        for expected in target["planet_rows"]:
            slot = int(expected["slot"])
            actual = actual_by_slot.get(slot)
            metrics["negative_y_planets"]["total"] += 1
            if actual is None:
                failures.append({
                    "portal": portal,
                    "slot": slot,
                    "field": "negative_y_missing_slot",
                })
                continue

            subset_checks = {
                field: actual.get(field) == expected.get(field)
                for field in (
                    "biome",
                    "biome_subtype",
                    "planet_class",
                    "planet_size",
                )
            }
            planet_ok = all(subset_checks.values())
            metrics["negative_y_planets"]["correct"] += int(planet_ok)
            if not planet_ok:
                failures.append({
                    "portal": portal,
                    "slot": slot,
                    "field": "negative_y_numeric_subset",
                    "checks": subset_checks,
                })

            expected_description = str(
                expected.get("description_token", "")
            )
            if expected_description:
                metrics["negative_y_description_token"]["total"] += 1
                exact = (
                    actual.get("description_token")
                    == expected_description
                )
                metrics["negative_y_description_token"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "negative_y_description_token",
                        "actual": actual.get("description_token"),
                        "expected": expected_description,
                    })

            expected_weather = str(expected.get("weather_token", ""))
            if expected_weather:
                metrics["negative_y_weather_token"]["total"] += 1
                exact = actual.get("weather_token") == expected_weather
                metrics["negative_y_weather_token"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "portal": portal,
                        "slot": slot,
                        "field": "negative_y_weather_token",
                        "actual": actual.get("weather_token"),
                        "expected": expected_weather,
                    })

            expected_branches = expected["branch"]
            branch_checks = {
                field: bool(actual.get(field)) == bool(expected_branches[field])
                for field in (
                    "is_weather_extreme",
                    "weather_clear_family",
                    "weather_extreme_family",
                    "literal_paradise",
                )
            }
            metrics["negative_y_branches"]["total"] += 1
            branch_ok = all(branch_checks.values())
            metrics["negative_y_branches"]["correct"] += int(branch_ok)
            if not branch_ok:
                failures.append({
                    "portal": portal,
                    "slot": slot,
                    "field": "negative_y_branches",
                    "checks": branch_checks,
                })


    family_catalog = load_family_catalog()
    for expected in resource_rows:
        root_seed = int(str(expected["root_seed_hex"]), 0)
        predicted_resource = predict_resource_level(
            root_seed,
            biome=int(expected["biome"]),
            planet_class=int(expected["planet_class"]),
        )
        suffix_word = stream_words(root_seed, 22, 3)[2]
        predicted_token = token_prediction(
            predicted_resource["resources_family"],
            word=suffix_word,
            catalog=family_catalog,
        )["token"]

        metrics["resource_level"]["total"] += 1
        level_exact = (
            int(predicted_resource["resource_level"])
            == int(expected["resource_level"])
        )
        metrics["resource_level"]["correct"] += int(level_exact)

        metrics["resources_family"]["total"] += 1
        family_exact = (
            predicted_resource["resources_family"]
            == expected["resources_family"]
        )
        metrics["resources_family"]["correct"] += int(family_exact)

        metrics["resources_token"]["total"] += 1
        token_exact = predicted_token == expected["resources_token"]
        metrics["resources_token"]["correct"] += int(token_exact)

        if not (level_exact and family_exact and token_exact):
            failures.append({
                "portal": expected["planet_portal"],
                "field": "resource_level_or_token",
                "actual": {
                    "resource_level": predicted_resource[
                        "resource_level"
                    ],
                    "resources_family": predicted_resource[
                        "resources_family"
                    ],
                    "resources_token": predicted_token,
                },
                "expected": {
                    "resource_level": expected["resource_level"],
                    "resources_family": expected["resources_family"],
                    "resources_token": expected["resources_token"],
                },
            })

    substance_by_system: dict[str, list[dict[str, Any]]] = {}
    for expected in substance_rows:
        substance_by_system.setdefault(str(expected["system_portal"]).upper(), []).append(expected)
    substance_progress_start = expected_system_count + len(negative_y_targets)
    for substance_index, portal in enumerate(substance_systems, start=1):
        progress_index = substance_progress_start + substance_index
        if progress:
            progress(progress_index, progress_system_count, portal)
        print(f"SELF_TEST_SUBSTANCE_SYSTEM={progress_index}/{progress_system_count} PORTAL={portal}", flush=True)
        prediction = predict_system(portal, 0)
        actual_by_slot = {int(row["slot"]): row for row in prediction["planet_rows"]}
        for expected in substance_by_system[portal]:
            slot = int(expected["slot"])
            actual = actual_by_slot.get(slot)
            if actual is None:
                failures.append({"portal": portal, "slot": slot, "field": "substance_missing_slot"})
                continue
            checks = {
                "gate": int(actual["weather_active"]) == int(expected["expected_weather_active"]),
                "common": actual["common_substance_id"] == expected["common_substance_id"],
                "uncommon": actual["uncommon_substance_id"] == expected["uncommon_substance_id"],
                "rare": actual["rare_substance_id"] == expected["rare_substance_id"],
            }
            for metric_name, check_name in (("substance_weather_active_gate", "gate"), ("common_substance_id", "common"), ("uncommon_substance_id", "uncommon"), ("rare_substance_id", "rare")):
                metrics[metric_name]["total"] += 1
                metrics[metric_name]["correct"] += int(checks[check_name])
            if not all(checks.values()):
                failures.append({"portal": portal, "slot": slot, "field": "substance_ids", "checks": checks, "actual": {"weather_active": actual["weather_active"], "common_substance_id": actual["common_substance_id"], "uncommon_substance_id": actual["uncommon_substance_id"], "rare_substance_id": actual["rare_substance_id"]}, "expected": expected})

    print("SELF_TEST_LIFE_CREATURE_FULL_REGRESSION", flush=True)
    life_creature_regression = (
        load_life_creature_engine().run_full_regression(
            sys.modules[__name__]
        )
    )
    for name in (
        "life_numeric",
        "flora_token",
        "fauna_standard_token",
        "fauna_weird_token",
        "fauna_robot_token",
        "source_system_kind",
        "in_empty_system",
        "address_descriptor_primary",
        "address_descriptor_aux_1",
        "address_descriptor_aux_2",
        "address_descriptor_aux_3",
        "address_creature_life",
        "life_creature_static",
    ):
        source_metric = life_creature_regression["metrics"][name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "life_creature_full_regression",
                "metric": source_metric,
            })


    print("SELF_TEST_SPECIAL_SYSTEM_FULL_REGRESSION", flush=True)
    special_system_regression = (
        load_special_system_engine().run_regression(
            load_life_creature_engine(),
            SPECIAL_SYSTEM_REGRESSION_PATH,
        )
    )
    for name, source_name in (
        ("special_system_controls", "controls"),
        ("special_system_fields", "fields"),
    ):
        source_metric = special_system_regression["metrics"][
            source_name
        ]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "special_system_full_regression",
                "metric": source_metric,
            })

    print("SELF_TEST_SPECIAL_PLANET_FULL_REGRESSION", flush=True)
    special_planet_regression = (
        load_special_planet_engine().run_regression(
            sys.modules[__name__],
            SPECIAL_PLANET_REGRESSION_PATH,
        )
    )
    for name, source_name in (
        ("special_planet_index", "planet_index"),
        ("special_planet_infested", "infested_predicate"),
        ("special_planet_dissonant", "direct_dissonance"),
        ("special_planet_pattern", "direct_dissonance_pattern"),
        (
            "special_planet_existing_sentinel",
            "existing_sentinel_level_unchanged",
        ),
        ("special_planet_infested_filter", "infested_filter"),
    ):
        source_metric = special_planet_regression["metrics"][
            source_name
        ]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "special_planet_full_regression",
                "metric": source_metric,
            })

    # Preserve the exact legacy direct-Corrupt branch regression separately
    # from the user-facing portal-safe Dissonance filter.
    direct_filter_correct = 0
    direct_filter_total = 0
    direct_regression = load_json(SPECIAL_PLANET_REGRESSION_PATH)
    direct_by_system: dict[str, list[dict[str, Any]]] = {}
    for expected in direct_regression.get("rows", []):
        direct_by_system.setdefault(
            str(expected["system_portal"]).upper(),
            [],
        ).append(expected)
    for system_portal, expected_rows in direct_by_system.items():
        prediction = predict_system(system_portal, 0)
        actual_by_slot = {
            int(row["slot"]): row
            for row in prediction["planet_rows"]
        }
        for expected in expected_rows:
            actual = actual_by_slot[int(expected["slot"])]
            expected_direct = bool(
                expected["expected_dissonant_planet"]
            )
            actual_direct = bool(
                actual.get(
                    "legacy_direct_corrupt_branch",
                    actual.get("dissonant_planet"),
                )
            )
            for requested in (True, False):
                direct_filter_total += 1
                direct_filter_correct += int(
                    (actual_direct == requested)
                    == (expected_direct == requested)
                )
    metrics["special_planet_dissonant_filter"]["correct"] = (
        direct_filter_correct
    )
    metrics["special_planet_dissonant_filter"]["total"] = (
        direct_filter_total
    )
    if direct_filter_correct != direct_filter_total:
        failures.append({
            "field": "special_planet_dissonant_filter",
            "source": "legacy_direct_corrupt_compatibility_v19i1b",
            "correct": direct_filter_correct,
            "total": direct_filter_total,
        })

    print("SELF_TEST_SENTINEL_DIFFICULTY_FULL_REGRESSION", flush=True)
    sentinel_difficulty_regression = (
        load_sentinel_difficulty_engine().run_integrated_regression(
            sys.modules[__name__],
            SENTINEL_DIFFICULTY_REGRESSION_PATH,
        )
    )
    for name, source_name in (
        ("sentinel_difficulty_patterns", "planet_patterns"),
        ("sentinel_difficulty_enums", "per_difficulty_enums"),
        ("sentinel_difficulty_non_dissonant", "non_dissonant_enums"),
        ("sentinel_difficulty_dissonance", "direct_dissonance_preserved"),
        ("sentinel_difficulty_existing_level", "existing_sentinel_level_unchanged"),
        ("sentinel_difficulty_filter", "native_difficulty_filter"),
    ):
        source_metric = sentinel_difficulty_regression["metrics"][source_name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "sentinel_difficulty_full_regression",
                "metric": source_metric,
            })

    print("SELF_TEST_EXACT_TERMINOLOGY_PRESENTATION_V19B", flush=True)
    terminology_regression = (
        load_terminology_engine().run_regression(
            TERMINOLOGY_CATALOG_PATH,
            SENTINEL_DIFFICULTY_REGRESSION_PATH,
        )
    )
    for name, source_name in (
        ("terminology_catalog_tokens", "catalog_dynamic_tokens"),
        ("terminology_planet_classification", "planet_classification"),
        ("terminology_weather", "weather"),
        ("terminology_resources", "resources"),
        ("terminology_fauna", "fauna"),
        ("terminology_flora", "flora"),
        ("terminology_placeholder_expansion", "planetclass_placeholder_expansion"),
        ("terminology_observed_planet_text", "observed_planet_text"),
        ("terminology_observed_weather_text", "observed_weather_text"),
        ("terminology_internal_tokens_preserved", "internal_tokens_preserved"),
    ):
        source_metric = terminology_regression["metrics"][source_name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "exact_terminology_presentation_v19b",
                "metric": source_metric,
            })

    print("SELF_TEST_PROFESSIONAL_FAUNA_TAXONOMY_V19C1", flush=True)
    fauna_taxonomy_regression = (
        load_fauna_taxonomy_engine().run_regression(
            FAUNA_TAXONOMY_CATALOG_PATH,
            FAUNA_DESCRIPTOR_CATALOG_PATH,
            CREATURE_DESCRIPTOR_REGRESSION_PATH,
        )
    )
    for name, source_name in (
        ("fauna_taxonomy_descriptor_tokens", "descriptor_tokens_preserved"),
        ("fauna_taxonomy_profile_labels", "descriptor_profile_labels"),
        ("fauna_taxonomy_profile_rows", "descriptor_profile_rows"),
        ("fauna_taxonomy_claim_boundary", "individual_prediction_boundary"),
        (
            "fauna_taxonomy_snake_worm_separation",
            "flying_snake_titan_worm_separation",
        ),
    ):
        source_metric = fauna_taxonomy_regression["metrics"][source_name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "professional_fauna_taxonomy_v19c1",
                "metric": source_metric,
            })

    print("SELF_TEST_PROFESSIONAL_HARDENING_V19E", flush=True)
    hardening_regression = load_professional_hardening_engine().run_regression()
    for name, source_name in (
        ("hardening_portal_validation", "portal_validation"),
        ("hardening_integer_validation", "integer_validation"),
        ("hardening_profile_roundtrip", "profile_roundtrip"),
        ("hardening_profile_corruption_recovery", "profile_corruption_recovery"),
        ("hardening_state_roundtrip", "state_roundtrip"),
        ("hardening_export_bundle", "export_bundle"),
        ("hardening_comparison", "comparison"),
        ("hardening_error_bundle", "error_bundle"),
    ):
        source_metric = hardening_regression["metrics"][source_name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "professional_hardening_v19e",
                "metric": source_metric,
            })

    print("SELF_TEST_EXACT_PLANET_CLASSIFICATION_FILTER_V19G", flush=True)
    classification_filter_regression = run_planet_classification_filter_regression()
    for name, source_name in (
        ("classification_filter_catalog", "classification_catalog"),
        ("classification_filter_match", "classification_filter_match"),
        ("classification_filter_catalog_coverage", "classification_catalog_coverage"),
        ("classification_filter_normalization", "classification_filter_normalization"),
    ):
        source_metric = classification_filter_regression["metrics"][source_name]
        metrics[name]["correct"] = int(source_metric["correct"])
        metrics[name]["total"] = int(source_metric["total"])
        if not source_metric["exact"]:
            failures.append({
                "field": name,
                "source": "exact_planet_classification_filter_v19g",
                "metric": source_metric,
            })

    print("SELF_TEST_FILTER_PROOF_V19I1B", flush=True)
    filter_proof = run_filter_proof()
    proof_checks = dict(filter_proof.get("checks", {}))
    metrics["filter_proof_v19i1b"]["correct"] = sum(
        bool(value) for value in proof_checks.values()
    )
    metrics["filter_proof_v19i1b"]["total"] = len(proof_checks)
    if not filter_proof.get("exact"):
        failures.append({
            "field": "filter_proof_v19i1b",
            "source": "portal_safe_filter_proof_v19i1b",
            "checks": proof_checks,
        })

    print("SELF_TEST_GRASS_GLOW_V20A9", flush=True)
    grass_glow_regression = run_grass_glow_regression()
    grass_glow_checks = {
        **{
            f"metric_{name}": bool(metric.get("exact"))
            for name, metric in grass_glow_regression.get(
                "metrics", {}
            ).items()
        },
        **{
            f"filter_{name}": bool(value)
            for name, value in grass_glow_regression.get(
                "filter_checks", {}
            ).items()
        },
    }
    metrics["grass_glow_regression_v20a9"]["correct"] = sum(
        grass_glow_checks.values()
    )
    metrics["grass_glow_regression_v20a9"]["total"] = len(
        grass_glow_checks
    )
    if not grass_glow_regression.get("exact"):
        failures.append({
            "field": "grass_glow_regression_v20a9",
            "source": "v20a7_v20a8a_47_planet_regression",
            "checks": grass_glow_checks,
            "failures": grass_glow_regression.get("failures", []),
        })

    print("SELF_TEST_RELEASE_CORRECTIONS_V20H15", flush=True)
    release_correction_checks = dict(
        doctor.get("release_corrections_static", {}).get("checks", {})
    )
    metrics["release_corrections_v20h15"]["correct"] = sum(
        bool(value) for value in release_correction_checks.values()
    )
    metrics["release_corrections_v20h15"]["total"] = len(
        release_correction_checks
    )
    if not doctor.get("release_corrections_static", {}).get("exact"):
        failures.append({
            "field": "release_corrections_v20h15",
            "source": "native_sentinel_paradise_and_giant_lush_control_v20h15",
            "checks": release_correction_checks,
        })

    print("SELF_TEST_TERRAIN_SETTING_SELECTOR_V20H20", flush=True)
    terrain_selector_regression = run_terrain_setting_selector_regression_v20h20()
    terrain_selector_checks = dict(terrain_selector_regression.get("checks", {}))
    metrics["terrain_setting_selector_v20h20"]["correct"] = sum(
        bool(value) for value in terrain_selector_checks.values()
    )
    metrics["terrain_setting_selector_v20h20"]["total"] = len(
        terrain_selector_checks
    )
    if not terrain_selector_regression.get("exact"):
        failures.append({
            "field": "terrain_setting_selector_v20h20",
            "source": "live_terrain_setting_index_campaign_v20h20",
            "checks": terrain_selector_checks,
        })

    print("SELF_TEST_LIVE_HARDENING_V1_0_45", flush=True)
    live_hardening_regression = run_live_hardening_regression_v1045()
    live_hardening_checks = dict(live_hardening_regression.get("checks", {}))
    metrics["live_hardening_v1_0_45"]["correct"] = sum(
        bool(value) for value in live_hardening_checks.values()
    )
    metrics["live_hardening_v1_0_45"]["total"] = len(
        live_hardening_checks
    )
    if not live_hardening_regression.get("exact"):
        failures.append({
            "field": "live_hardening_v1_0_45",
            "source": "two_complete_live_tested_systems_and_ui_integrity",
            "checks": live_hardening_checks,
        })

    print("SELF_TEST_SELECTOR_MAPPING_V2", flush=True)
    selector_mapping_regression = dict(doctor.get("selector_mapping_static", {}))
    selector_mapping_checks = dict(selector_mapping_regression.get("checks", {}))
    metrics["selector_mapping_v2"]["correct"] = sum(
        bool(value) for value in selector_mapping_checks.values()
    )
    metrics["selector_mapping_v2"]["total"] = len(selector_mapping_checks)
    if not selector_mapping_regression.get("exact"):
        failures.append({
            "field": "selector_mapping_v2",
            "source": "27_system_149_planet_selector_campaign_v2",
            "checks": selector_mapping_checks,
            "failures": selector_mapping_regression.get("failures", []),
        })

    print("SELF_TEST_RENDERED_RINGS_V20J", flush=True)
    rendered_ring_regression = dict(doctor.get("rendered_ring_static", {}))
    rendered_ring_checks = dict(rendered_ring_regression.get("checks", {}))
    metrics["rendered_rings_v20j"]["correct"] = sum(
        bool(value) for value in rendered_ring_checks.values()
    )
    metrics["rendered_rings_v20j"]["total"] = len(rendered_ring_checks)
    if not rendered_ring_regression.get("exact"):
        failures.append({
            "field": "rendered_rings_v20j",
            "source": "27_system_149_planet_runtime_plus_8_manual_ring_controls",
            "checks": rendered_ring_checks,
        })

    print("SELF_TEST_VISUAL_FLORA_V20B2", flush=True)
    visual_flora_regression = run_visual_flora_regression()
    visual_flora_checks = {
        **{
            f"metric_{name}": bool(metric.get("exact"))
            for name, metric in visual_flora_regression.get(
                "metrics", {}
            ).items()
        },
        **{
            f"separation_{name}": bool(value)
            for name, value in visual_flora_regression.get(
                "false_positive_separation", {}
            ).items()
        },
        **{
            f"filter_{name}": bool(value)
            for name, value in visual_flora_regression.get(
                "filter_checks", {}
            ).items()
        },
    }
    metrics["visual_flora_regression_v20b2"]["correct"] = sum(
        visual_flora_checks.values()
    )
    metrics["visual_flora_regression_v20b2"]["total"] = len(
        visual_flora_checks
    )
    if not visual_flora_regression.get("exact"):
        failures.append({
            "field": "visual_flora_regression_v20b2",
            "source": "user_confirmed_visual_controls_v20b1",
            "checks": visual_flora_checks,
            "failures": visual_flora_regression.get(
                "failures", []
            ),
        })

    for metric in metrics.values():
        metric["exact"] = bool(
            metric["total"] > 0
            and metric["correct"] == metric["total"]
        )

    required = (
        metrics["systems"]["exact"]
        and metrics["numeric"]["correct"] == 20
        and metrics["numeric"]["total"] == 20
        and metrics["description_family"]["exact"]
        and metrics["description_token"]["correct"] == 14
        and metrics["description_token"]["total"] == 14
        and metrics["weather_family"]["exact"]
        and metrics["weather_token"]["correct"] == 19
        and metrics["weather_token"]["total"] == 19
        and metrics["is_weather_extreme"]["exact"]
        and metrics["weather_clear_family"]["exact"]
        and metrics["weather_extreme_family"]["exact"]
        and metrics["literal_paradise"]["exact"]
        and metrics["negative_y_systems"]["correct"] == 3
        and metrics["negative_y_systems"]["total"] == 3
        and metrics["negative_y_planets"]["correct"] == 18
        and metrics["negative_y_planets"]["total"] == 18
        and metrics["negative_y_description_token"]["correct"] == 17
        and metrics["negative_y_description_token"]["total"] == 17
        and metrics["negative_y_weather_token"]["correct"] == 16
        and metrics["negative_y_weather_token"]["total"] == 16
        and metrics["negative_y_branches"]["correct"] == 18
        and metrics["negative_y_branches"]["total"] == 18
        and metrics["resource_writer_static"]["correct"] == 5
        and metrics["resource_writer_static"]["total"] == 5
        and metrics["resource_level"]["correct"] == 71
        and metrics["resource_level"]["total"] == 71
        and metrics["resources_family"]["correct"] == 71
        and metrics["resources_family"]["total"] == 71
        and metrics["resources_token"]["correct"] == 71
        and metrics["resources_token"]["total"] == 71
        and metrics["substance_weather_active_gate"]["correct"] == 89
        and metrics["substance_weather_active_gate"]["total"] == 89
        and metrics["common_substance_id"]["correct"] == 89
        and metrics["common_substance_id"]["total"] == 89
        and metrics["uncommon_substance_id"]["correct"] == 89
        and metrics["uncommon_substance_id"]["total"] == 89
        and metrics["rare_substance_id"]["correct"] == 89
        and metrics["rare_substance_id"]["total"] == 89
        and metrics["life_numeric"]["correct"] == 71
        and metrics["life_numeric"]["total"] == 71
        and metrics["flora_token"]["correct"] == 47
        and metrics["flora_token"]["total"] == 47
        and metrics["fauna_standard_token"]["correct"] == 60
        and metrics["fauna_standard_token"]["total"] == 60
        and metrics["fauna_weird_token"]["correct"] == 8
        and metrics["fauna_weird_token"]["total"] == 8
        and metrics["fauna_robot_token"]["correct"] == 3
        and metrics["fauna_robot_token"]["total"] == 3
        and metrics["source_system_kind"]["correct"] == 4
        and metrics["source_system_kind"]["total"] == 4
        and metrics["in_empty_system"]["correct"] == 8
        and metrics["in_empty_system"]["total"] == 8
        and metrics["special_system_controls"]["correct"] == 9
        and metrics["special_system_controls"]["total"] == 9
        and metrics["special_system_fields"]["correct"] == 36
        and metrics["special_system_fields"]["total"] == 36
        and metrics["special_planet_index"]["correct"] == 71
        and metrics["special_planet_index"]["total"] == 71
        and metrics["special_planet_infested"]["correct"] == 71
        and metrics["special_planet_infested"]["total"] == 71
        and metrics["special_planet_dissonant"]["correct"] == 71
        and metrics["special_planet_dissonant"]["total"] == 71
        and metrics["special_planet_pattern"]["correct"] == 71
        and metrics["special_planet_pattern"]["total"] == 71
        and metrics["special_planet_existing_sentinel"]["correct"] == 71
        and metrics["special_planet_existing_sentinel"]["total"] == 71
        and metrics["special_planet_dissonant_filter"]["correct"] == 142
        and metrics["special_planet_dissonant_filter"]["total"] == 142
        and metrics["special_planet_infested_filter"]["correct"] == 142
        and metrics["special_planet_infested_filter"]["total"] == 142
        and metrics["sentinel_difficulty_patterns"]["correct"] == 71
        and metrics["sentinel_difficulty_patterns"]["total"] == 71
        and metrics["sentinel_difficulty_enums"]["correct"] == 284
        and metrics["sentinel_difficulty_enums"]["total"] == 284
        and metrics["sentinel_difficulty_non_dissonant"]["correct"] == 264
        and metrics["sentinel_difficulty_non_dissonant"]["total"] == 264
        and metrics["sentinel_difficulty_dissonance"]["correct"] == 5
        and metrics["sentinel_difficulty_dissonance"]["total"] == 5
        and metrics["sentinel_difficulty_existing_level"]["correct"] == 71
        and metrics["sentinel_difficulty_existing_level"]["total"] == 71
        and metrics["sentinel_difficulty_filter"]["correct"] == 568
        and metrics["sentinel_difficulty_filter"]["total"] == 568
        and metrics["terminology_catalog_tokens"]["correct"] == 457
        and metrics["terminology_catalog_tokens"]["total"] == 457
        and metrics["terminology_planet_classification"]["correct"] == 71
        and metrics["terminology_planet_classification"]["total"] == 71
        and metrics["terminology_weather"]["correct"] == 71
        and metrics["terminology_weather"]["total"] == 71
        and metrics["terminology_resources"]["correct"] == 71
        and metrics["terminology_resources"]["total"] == 71
        and metrics["terminology_fauna"]["correct"] == 71
        and metrics["terminology_fauna"]["total"] == 71
        and metrics["terminology_flora"]["correct"] == 71
        and metrics["terminology_flora"]["total"] == 71
        and metrics["terminology_placeholder_expansion"]["correct"] == 71
        and metrics["terminology_placeholder_expansion"]["total"] == 71
        and metrics["terminology_observed_planet_text"]["correct"] == 53
        and metrics["terminology_observed_planet_text"]["total"] == 53
        and metrics["terminology_observed_weather_text"]["correct"] == 50
        and metrics["terminology_observed_weather_text"]["total"] == 50
        and metrics["terminology_internal_tokens_preserved"]["correct"] == 426
        and metrics["terminology_internal_tokens_preserved"]["total"] == 426
        and metrics["fauna_taxonomy_descriptor_tokens"]["correct"] == 72
        and metrics["fauna_taxonomy_descriptor_tokens"]["total"] == 72
        and metrics["fauna_taxonomy_profile_labels"]["correct"] == 72
        and metrics["fauna_taxonomy_profile_labels"]["total"] == 72
        and metrics["fauna_taxonomy_profile_rows"]["correct"] == 18
        and metrics["fauna_taxonomy_profile_rows"]["total"] == 18
        and metrics["fauna_taxonomy_claim_boundary"]["correct"] == 18
        and metrics["fauna_taxonomy_claim_boundary"]["total"] == 18
        and metrics["fauna_taxonomy_snake_worm_separation"]["correct"] == 2
        and metrics["fauna_taxonomy_snake_worm_separation"]["total"] == 2
        and metrics["hardening_portal_validation"]["correct"] == 4
        and metrics["hardening_portal_validation"]["total"] == 4
        and metrics["hardening_integer_validation"]["correct"] == 6
        and metrics["hardening_integer_validation"]["total"] == 6
        and metrics["hardening_profile_roundtrip"]["correct"] == 5
        and metrics["hardening_profile_roundtrip"]["total"] == 5
        and metrics["hardening_profile_corruption_recovery"]["correct"] == 2
        and metrics["hardening_profile_corruption_recovery"]["total"] == 2
        and metrics["hardening_state_roundtrip"]["correct"] == 2
        and metrics["hardening_state_roundtrip"]["total"] == 2
        and metrics["hardening_export_bundle"]["correct"]
        == metrics["hardening_export_bundle"]["total"]
        and metrics["hardening_export_bundle"]["total"] >= 26
        and metrics["hardening_comparison"]["correct"] == 4
        and metrics["hardening_comparison"]["total"] == 4
        and metrics["hardening_error_bundle"]["correct"] == 3
        and metrics["hardening_error_bundle"]["total"] == 3
        and metrics["classification_filter_catalog"]["correct"]
        == metrics["classification_filter_catalog"]["total"]
        and metrics["classification_filter_catalog"]["total"]
        == len(planet_classification_filter_values())
        and metrics["classification_filter_match"]["correct"] == 142
        and metrics["classification_filter_match"]["total"] == 142
        and metrics["classification_filter_catalog_coverage"]["correct"] == 71
        and metrics["classification_filter_catalog_coverage"]["total"] == 71
        and metrics["classification_filter_normalization"]["correct"] == 3
        and metrics["classification_filter_normalization"]["total"] == 3
        and metrics["filter_proof_v19i1b"]["correct"] == 13
        and metrics["filter_proof_v19i1b"]["total"] == 13
        and metrics["grass_glow_regression_v20a9"]["correct"] == 24
        and metrics["grass_glow_regression_v20a9"]["total"] == 24
        and metrics["live_hardening_v1_0_45"]["exact"]
        and metrics["selector_mapping_v2"]["correct"]
        == metrics["selector_mapping_v2"]["total"]
        and metrics["selector_mapping_v2"]["total"] >= 22
        and metrics["rendered_rings_v20j"]["correct"]
        == metrics["rendered_rings_v20j"]["total"]
        and metrics["rendered_rings_v20j"]["total"] == 35
        and metrics["visual_flora_regression_v20b2"]["correct"] == 15
        and metrics["visual_flora_regression_v20b2"]["total"] == 15
        and metrics["address_descriptor_primary"]["correct"] == 18
        and metrics["address_descriptor_primary"]["total"] == 18
        and metrics["address_descriptor_aux_1"]["correct"] == 18
        and metrics["address_descriptor_aux_1"]["total"] == 18
        and metrics["address_descriptor_aux_2"]["correct"] == 18
        and metrics["address_descriptor_aux_2"]["total"] == 18
        and metrics["address_descriptor_aux_3"]["correct"] == 18
        and metrics["address_descriptor_aux_3"]["total"] == 18
        and metrics["address_creature_life"]["correct"] == 18
        and metrics["address_creature_life"]["total"] == 18
        and metrics["life_creature_static"]["correct"] == 4
        and metrics["life_creature_static"]["total"] == 4
    )
    return {
        "version": VERSION,
        "timestamp": now_iso(),
        "status": (
            "PASS_CORE_V1_SELF_TEST_EXACT"
            if required
            else "ERROR_CORE_V1_SELF_TEST_MISMATCH"
        ),
        "ready": required,
        "doctor": doctor,
        "metrics": metrics,
        "failure_count": len(failures),
        "failures": failures,
        "grass_glow_regression": grass_glow_regression,
        "visual_flora_regression": visual_flora_regression,
        "live_hardening_regression": live_hardening_regression,
        "selector_mapping_regression": selector_mapping_regression,
        "claim": {
            "replays_the_same_4_v5j_independent_systems": True,
            "replays_3_fresh_negative_y_independent_systems": True,
            "systems": 7,
            "planets": 38,
            "negative_y_full_live_numeric_result": "18/18",
            "resource_level_native_writer_replay": "71/71",
            "resources_family_replay": "71/71",
            "resources_token_replay": "71/71",
            "resource_writer_static_checks": "5/5",
            "substance_validation_systems": 16,
            "substance_validation_planets": 89,
            "substance_weather_active_gate": "89/89",
            "common_substance_ids": "89/89",
            "uncommon_substance_ids": "89/89",
            "rare_substance_ids": "89/89",
            "life_numeric": "71/71",
            "flora_abundance_tokens": "47/47",
            "fauna_standard_tokens": "60/60",
            "fauna_weird_tokens": "8/8",
            "fauna_robot_tokens": "3/3",
            "source_system_kind": "4/4",
            "in_empty_system": "8/8",
            "special_system_controls": "9/9",
            "special_system_boolean_fields": "36/36",
            "special_planet_index": "71/71",
            "infested_planet": "71/71",
            "direct_dissonance": "71/71",
            "direct_dissonance_pattern": "71/71",
            "existing_sentinel_level_unchanged": "71/71",
            "dissonant_filter": "142/142",
            "infested_filter": "142/142",
            "native_sentinel_planet_patterns": "71/71",
            "native_sentinel_per_difficulty_enums": "284/284",
            "native_sentinel_non_dissonant_enums": "264/264",
            "native_sentinel_direct_dissonance_planets": "5/5",
            "native_sentinel_filter": "568/568",
            "exact_current_game_planet_classification": "71/71",
            "exact_current_game_weather_wording": "71/71",
            "exact_current_game_resource_wording": "71/71",
            "exact_current_game_fauna_wording": "71/71",
            "exact_current_game_flora_wording": "71/71",
            "observed_planet_text_crosscheck": "53/53",
            "observed_weather_text_crosscheck": "50/50",
            "terminology_dynamic_tokens": "457/457",
            "terminology_locale": "en_GB",
            "fauna_taxonomy_descriptor_tokens": "72/72",
            "fauna_taxonomy_profile_labels": "72/72",
            "fauna_taxonomy_profile_rows": "18/18",
            "fauna_taxonomy_claim_boundary": "18/18",
            "flying_snake_titan_worm_separation": "2/2",
            "professional_hardening_portal_validation": "4/4",
            "professional_hardening_integer_validation": "6/6",
            "professional_hardening_profile_roundtrip": "5/5",
            "professional_hardening_profile_corruption_recovery": "2/2",
            "professional_hardening_state_roundtrip": "2/2",
            "professional_hardening_export_bundle": (
                f"{metrics['hardening_export_bundle']['correct']}/"
                f"{metrics['hardening_export_bundle']['total']}"
            ),
            "professional_hardening_comparison": "4/4",
            "professional_hardening_error_bundle": "3/3",
            "search_cancellation_supported": True,
            "exact_planet_classification_dropdown_values": (
                f"{len(planet_classification_filter_values())}/"
                f"{len(planet_classification_filter_values())}"
            ),
            "exact_planet_classification_filter_match": "142/142",
            "exact_planet_classification_catalog_coverage": "71/71",
            "planet_and_moon_classifications_separate": True,
            "individual_fauna_archetype_prediction_complete": False,
            "titan_worm_filter_enabled": False,
            "diplo_filter_enabled": False,
            "address_only_full_sentinel_difficulty_replay": True,
            "address_derived_creature_descriptors": "18/18",
            "address_derived_creature_life": "18/18",
            "live_hardening_controls": (
                f"{live_hardening_regression.get('correct', 0)}/"
                f"{live_hardening_regression.get('total', 0)}"
            ),
            "two_complete_live_tested_systems": True,
            "selector_mapping_systems": "30/30",
            "selector_mapping_planets": "149/149",
            "economy_type_selector": "30/30",
            "economy_tier_selector": "30/30 raw; public 1/2/3 stars on ordinary inhabited systems",
            "conflict_level_selector": "30/30 raw; public only on ordinary inhabited systems",
            "dominant_race_selector": "25/25 ordinary raw plus 3/3 visible race labels",
            "generated_water_palette": "149/149",
            "deep_water_biolum_palette": "149/149",
            "no_nms_process_required": True,
        },
    }


def write_self_test_outputs(result: dict[str, Any]) -> dict[str, str]:
    output = OUTPUT_ROOT / f"self_test_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "self_test_core_v1.json"
    report_path = output / "ATLAS_APF_RESULT_CORE_V1_SELF_TEST.txt"
    safe_json(json_path, result)

    lines = [
        "ATLAS APF — CORE V1 SELF-TEST",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"READY={result.get('ready', False)}",
        f"FAILURES={result.get('failure_count', 0)}",
        "",
        "METRICS",
        "-------",
    ]
    for name, metric in result.get("metrics", {}).items():
        lines.append(
            f"OUTPUT={name} EXACT={metric['exact']} "
            f"CORRECT={metric['correct']}/{metric['total']}"
        )
    if result.get("failures"):
        lines.extend(["", "FAILURE DETAILS", "---------------"])
        for failure in result["failures"][:100]:
            lines.append(json.dumps(failure, ensure_ascii=False))
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }



def run_galaxy_generation_proof() -> dict[str, Any]:
    """Validate that the selected galaxy reaches physical generation.

    This checks packed-seed injection, differential physical output, and the
    native yellow-star reality-weight record mapping.
    """
    controls = (
        "00163947E840",
        "0001FB38537B",
        "020B239D7F56",
        "03EED05B73B8",
    )
    galaxies = (0, 2, 6, 9)
    galaxy_labels = {
        0: "Euclid / Normal",
        2: "Calypso / Harsh",
        6: "Budullangr / Empty",
        9: "Eissentam / Lush",
    }
    expected_reality_classes = {0: 4, 2: 2, 6: 1, 9: 3}
    expected_yellow_weight_entries = {0: 0, 2: 0, 6: 5, 9: 6}

    matrix: list[dict[str, Any]] = []
    checks: dict[str, bool] = {}
    for portal in controls:
        signatures: list[tuple[Any, ...]] = []
        for galaxy_index in galaxies:
            result = predict_system(portal, galaxy_index)
            rows = list(result.get("planet_rows", []))
            if not rows:
                raise RuntimeError(
                    f"Galaxy validation returned no planets for {portal} galaxy {galaxy_index}."
                )
            packed_values = {str(row.get("packed_input", "")) for row in rows}
            # The V4J1 packed value is copied through the later layers. Fall
            # back to the generation metadata when a presentation layer omits it.
            generation_packed = str(
                rows[0].get(
                    "packed_input",
                    rows[0].get("source_packed_input", ""),
                )
            )
            seeds = tuple(str(row.get("planet_seed_hex", "")) for row in rows)
            biomes = tuple(int(row.get("biome", -1)) for row in rows)
            rings = tuple(bool(row.get("has_rings", False)) for row in rows)
            signature = (len(rows), seeds, biomes, rings)
            signatures.append(signature)

            engine = load_v4y()
            layers = engine.run_layers(portal, galaxy_index)
            count_layer = layers["count_colour_biome_size_water"]
            input_data = dict(count_layer.get("input", {}))
            packed_input = str(input_data.get("packed_input", generation_packed))
            reality_class = int(input_data.get("reality_class", -1))
            star_type = int(
                count_layer.get("system", {}).get("star_type_raw", -1)
            )
            if star_type == 0:
                weight_entry = (
                    5 if reality_class == 1
                    else 6 if reality_class == 3
                    else 0
                )
            else:
                weight_entry = star_type

            expected_byte = f"{galaxy_index:02X}"
            actual_byte = (
                f"{(int(packed_input, 16) >> 32) & 0xFF:02X}"
                if packed_input
                else ""
            )
            prefix = f"{portal}_G{galaxy_index}"
            checks[f"{prefix}_galaxy_seed_byte"] = actual_byte == expected_byte
            checks[f"{prefix}_row_metadata"] = all(
                int(row.get("generation_galaxy_index", -1)) == galaxy_index
                and bool(row.get("galaxy_seed_applied", False))
                for row in rows
            )
            checks[f"{prefix}_reality_class"] = (
                reality_class == expected_reality_classes[galaxy_index]
            )
            if star_type == 0:
                checks[f"{prefix}_yellow_weight_entry"] = (
                    weight_entry == expected_yellow_weight_entries[galaxy_index]
                )

            matrix.append({
                "portal": portal,
                "galaxy_index": galaxy_index,
                "galaxy_label": galaxy_labels[galaxy_index],
                "packed_input": packed_input,
                "packed_galaxy_byte_hex": actual_byte,
                "reality_class": reality_class,
                "star_type_raw": star_type,
                "biome_weight_entry_index": weight_entry,
                "planet_count": len(rows),
                "planet_seed_hex": list(seeds),
                "biomes": list(biomes),
                "rings": list(rings),
            })

        checks[f"{portal}_four_distinct_physical_signatures"] = (
            len(set(signatures)) == len(galaxies)
        )

    # Locked public Euclid control: this exact address must remain unchanged.
    euclid = predict_system("00163947E840", 0)
    euclid_rows = list(euclid["planet_rows"])
    checks["euclid_locked_planet_count"] = len(euclid_rows) == 6
    checks["euclid_locked_biomes"] = [
        int(row["biome"]) for row in euclid_rows
    ] == [7, 0, 4, 0, 2, 0]
    checks["euclid_locked_ring_slot"] = [
        int(row["slot"]) for row in euclid_rows if bool(row.get("has_rings"))
    ] == [4]

    exact = all(checks.values())
    return {
        "version": VERSION,
        "timestamp": now_iso(),
        "status": (
            "PASS_GALAXY_GENERATION_VALIDATION"
            if exact
            else "ERROR_GALAXY_GENERATION_VALIDATION"
        ),
        "generation_validated": exact,
        "checks": checks,
        "matrix": matrix,
        "claim_boundary": {
            "galaxy_byte_packed_into_tkseed_bits_32_39": True,
            "native_reality_class_table_applied": True,
            "yellow_star_reality_weight_overrides_applied": True,
            "euclid_regression_locked": True,
            "random_non_euclid_live_controls_reported_matching": True,
        },
    }


def write_galaxy_generation_proof_outputs(
    result: dict[str, Any],
) -> dict[str, str]:
    output = OUTPUT_ROOT / f"galaxy_generation_validation_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "galaxy_generation_validation.json"
    report_path = output / "ATLAS_APF_GALAXY_GENERATION_VALIDATION.txt"
    safe_json(json_path, result)
    lines = [
        "ATLAS APF — GALAXY GENERATION VALIDATION",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"GENERATION_VALIDATED={result['generation_validated']}",
        "",
        "SCOPE",
        "-----",
        "This validates that the selected galaxy reaches the packed physical",
        "generation seed and native reality-class biome weight route.",
        "",
        "MATRIX",
        "------",
    ]
    for row in result.get("matrix", []):
        lines.append(
            f"PORTAL={row['portal']} GALAXY={row['galaxy_index']} "
            f"LABEL={row['galaxy_label']} PACKED={row['packed_input']} "
            f"REALITY_CLASS={row['reality_class']} STAR={row['star_type_raw']} "
            f"WEIGHT_ENTRY={row['biome_weight_entry_index']} "
            f"PLANETS={row['planet_count']} BIOMES={row['biomes']}"
        )
    lines.extend(["", "CHECKS", "------"])
    for name, exact in result.get("checks", {}).items():
        lines.append(f"{name.upper()}={exact}")
    lines.extend([
        "",
        "CLAIM BOUNDARY",
        "--------------",
        json.dumps(result.get("claim_boundary", {}), indent=2),
    ])
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }


def run_filter_proof() -> dict[str, Any]:
    """Fast deterministic proof for released user-facing filters."""
    paradise = predict_system("020B239D7F56", 0)
    dissonant_positive = predict_system("0045239D7F55", 0)
    dissonant_negative = predict_system("00BE219D7F52", 0)
    ring_control = predict_system("0002D05B73B8", 0)
    purple_ring_control = predict_system("03EED05B73B8", 0)

    paradise_rows = list(paradise["planet_rows"])
    positive_rows = list(dissonant_positive["planet_rows"])
    negative_rows = list(dissonant_negative["planet_rows"])
    ring_rows = list(ring_control["planet_rows"])
    purple_ring_rows = list(purple_ring_control["planet_rows"])

    no_filter_rows = [
        row
        for row in paradise_rows
        if planet_matches(row, paradise["system"])
    ]
    paradise_only = [
        row
        for row in paradise_rows
        if planet_matches(
            row,
            paradise["system"],
            literal_paradise=True,
        )
    ]
    lush_only = [
        row
        for row in paradise_rows
        if planet_matches(
            row,
            paradise["system"],
            lush_biome=True,
        )
    ]
    clear_only = [
        row
        for row in paradise_rows
        if planet_matches(
            row,
            paradise["system"],
            weather_clear=True,
        )
    ]
    combined = [
        row
        for row in paradise_rows
        if planet_matches(
            row,
            paradise["system"],
            literal_paradise=True,
            lush_biome=True,
            weather_clear=True,
            weather_extreme=False,
        )
    ]
    positive_dissonant = [
        row
        for row in positive_rows
        if planet_matches(
            row,
            dissonant_positive["system"],
            dissonant=True,
        )
    ]
    negative_dissonant = [
        row
        for row in negative_rows
        if planet_matches(
            row,
            dissonant_negative["system"],
            dissonant=True,
        )
    ]
    paradise_dissonant_negative = [
        row
        for row in paradise_rows
        if planet_matches(
            row,
            paradise["system"],
            dissonant=True,
        )
    ]

    ring_positive = [
        row for row in ring_rows
        if planet_matches(row, ring_control["system"], ringed=True)
    ]
    ring_negative = [
        row for row in ring_rows
        if planet_matches(row, ring_control["system"], ringed=False)
    ]
    purple_ring_positive = [
        row for row in purple_ring_rows
        if planet_matches(row, purple_ring_control["system"], ringed=True)
    ]

    expected_positive_portal = "1045239D7F55"
    checks = {
        "unfiltered_three_planets": len(no_filter_rows) == 3,
        "literal_paradise_one": len(paradise_only) == 1,
        "lush_one": len(lush_only) == 1,
        "clear_weather_one": len(clear_only) == 1,
        "paradise_lush_clear_nonextreme_one": len(combined) == 1,
        "portal_safe_dissonant_positive_one": (
            len(positive_dissonant) == 1
            and str(positive_dissonant[0].get("planet_portal", "")).upper()
            == expected_positive_portal
        ),
        "portal_safe_dissonant_nonpurple_negative_zero": (
            len(negative_dissonant) == 0
        ),
        "portal_safe_dissonant_paradise_negative_zero": (
            len(paradise_dissonant_negative) == 0
        ),
        "rendered_ring_positive_exact": (
            len(ring_positive) == 1
            and ring_positive[0].get("gameplay_planet_number") == 3
            and ring_positive[0].get("exact_planet_portal_address")
            == "3002D05B73B8"
        ),
        "rendered_ring_negative_exact": len(ring_negative) == 5,
        "purple_rendered_ring_positive_zero": len(purple_ring_positive) == 0,
        "paradise_classification_clean": (
            paradise_only
            and paradise_only[0].get("planet_classification_display")
            == "Paradise Planet"
            and "%PLANETCLASS%" not in str(
                paradise_only[0].get("planet_classification_display", "")
            )
        ),
        "planet_body_type_inference_exact": all(
            str(row.get("planet_body_type_token", ""))
            in {"PLANETCLASS1", "PLANETCLASS2", "DISC_TYPE_GIANT"}
            for row in paradise_rows + positive_rows + negative_rows
        ),
    }
    exact = all(bool(value) for value in checks.values())
    return {
        "status": (
            "PASS_FILTER_PROOF_V19I1B_EXACT"
            if exact
            else "ERROR_FILTER_PROOF_V19I1B"
        ),
        "ready": exact,
        "exact": exact,
        "timestamp": datetime.now().astimezone().isoformat(),
        "version": VERSION,
        "checks": checks,
        "controls": {
            "paradise_system": "020B239D7F56",
            "portal_safe_dissonant_positive_system": "0045239D7F55",
            "portal_safe_dissonant_positive_planet": expected_positive_portal,
            "nonpurple_negative_system": "00BE219D7F52",
            "rendered_ring_system": "0002D05B73B8",
            "rendered_ring_planet": "3002D05B73B8",
            "purple_no_rendered_ring_system": "03EED05B73B8",
        },
        "observed": {
            "unfiltered_planets": len(no_filter_rows),
            "literal_paradise_matches": [
                row.get("planet_portal") for row in paradise_only
            ],
            "lush_matches": [
                row.get("planet_portal") for row in lush_only
            ],
            "clear_weather_matches": [
                row.get("planet_portal") for row in clear_only
            ],
            "combined_matches": [
                row.get("planet_portal") for row in combined
            ],
            "dissonant_positive_matches": [
                row.get("planet_portal") for row in positive_dissonant
            ],
            "dissonant_nonpurple_negative_matches": [
                row.get("planet_portal") for row in negative_dissonant
            ],
            "dissonant_paradise_negative_matches": [
                row.get("planet_portal")
                for row in paradise_dissonant_negative
            ],
            "rendered_ring_matches": [
                row.get("exact_planet_portal_address") for row in ring_positive
            ],
            "rendered_no_ring_count": len(ring_negative),
            "purple_rendered_ring_matches": [
                row.get("exact_planet_portal_address")
                for row in purple_ring_positive
            ],
            "paradise_classification": (
                paradise_only[0].get("planet_classification_display")
                if paradise_only
                else ""
            ),
        },
        "claim_boundary": {
            "dissonant_semantics": (
                "Native reference-difficulty Sentinel enum 3 (Corrupt)"
            ),
            "reference_difficulty_index": 2,
            "legacy_direct_corrupt_branch_preserved_separately": True,
            "portal_safe_positive_control": True,
            "portal_safe_negative_controls": 2,
        },
    }


def write_filter_proof_outputs(
    result: dict[str, Any],
) -> dict[str, str]:
    output = OUTPUT_ROOT / f"filter_proof_v19i1b_{stamp()}"
    output.mkdir(parents=True, exist_ok=False)
    json_path = output / "filter_proof_v19i1b.json"
    report_path = output / "ATLAS_APF_RESULT_FILTER_PROOF_V19I1B.txt"
    safe_json(json_path, result)

    lines = [
        "ATLAS APF — FILTER PROOF V19I1B",
        f"Timestamp={result['timestamp']}",
        f"Version={VERSION}",
        "",
        "RESULT",
        "------",
        f"STATUS={result['status']}",
        f"READY={result['ready']}",
        "",
        "CHECKS",
        "------",
    ]
    for name, exact in result.get("checks", {}).items():
        lines.append(f"{name.upper()}={exact}")
    lines.extend([
        "",
        "OBSERVED",
        "--------",
        json.dumps(result.get("observed", {}), indent=2),
        "",
        "CLAIM BOUNDARY",
        "--------------",
        json.dumps(result.get("claim_boundary", {}), indent=2),
    ])
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "folder": str(output),
        "json": str(json_path),
        "report": str(report_path),
    }


def run_mock_model_test() -> dict[str, Any]:
    """Pure-Python packaging test that does not load Unicorn."""
    plan = load_json(V5J_PLAN_PATH)
    model = load_model()
    family_catalog = load_family_catalog()
    metrics = {
        "rows": 0,
        "description_family": 0,
        "description_token": 0,
        "weather_family": 0,
        "weather_token": 0,
        "branches": 0,
    }
    expected_counts = {
        "description_family": 0,
        "description_token": 0,
        "weather_family": 0,
        "weather_token": 0,
    }
    failures = []

    for target in plan["targets"]:
        for expected in target["planet_rows"]:
            actual = enrich_planet_row(
                expected,
                model=model,
                family_catalog=family_catalog,
            )
            metrics["rows"] += 1
            expected_branches = expected["branch_prediction"]
            if all(
                bool(actual[field]) == bool(expected_branches[field])
                for field in expected_branches
            ):
                metrics["branches"] += 1
            else:
                failures.append((target["portal"], expected["slot"], "branches"))

            desc = expected["description_prediction"]
            if desc.get("family"):
                expected_counts["description_family"] += 1
                if actual["description_family"] == desc["family"]:
                    metrics["description_family"] += 1
                else:
                    failures.append((target["portal"], expected["slot"], "description_family"))
            if desc.get("predicted_token"):
                expected_counts["description_token"] += 1
                if actual["description_token"] == desc["predicted_token"]:
                    metrics["description_token"] += 1
                else:
                    failures.append((target["portal"], expected["slot"], "description_token"))

            weather = expected["weather_prediction"]
            if weather.get("family"):
                expected_counts["weather_family"] += 1
                if actual["weather_family"] == weather["family"]:
                    metrics["weather_family"] += 1
                else:
                    failures.append((target["portal"], expected["slot"], "weather_family"))
            if weather.get("predicted_token"):
                expected_counts["weather_token"] += 1
                if actual["weather_token"] == weather["predicted_token"]:
                    metrics["weather_token"] += 1
                else:
                    failures.append((target["portal"], expected["slot"], "weather_token"))

    exact = (
        metrics["rows"] == 20
        and metrics["branches"] == 20
        and metrics["description_family"] == expected_counts["description_family"]
        and metrics["description_token"] == 14
        and metrics["weather_family"] == expected_counts["weather_family"]
        and metrics["weather_token"] == 19
        and not failures
    )
    return {
        "status": (
            "PASS_CORE_V1_MOCK_MODEL_TEST"
            if exact
            else "ERROR_CORE_V1_MOCK_MODEL_TEST"
        ),
        "exact": exact,
        "metrics": metrics,
        "expected_counts": expected_counts,
        "failures": failures,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="ATLAS APF"
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="{predict,find,gui}")

    predict_parser = sub.add_parser(
        "predict",
        help="Predict every planet in one system.",
    )
    predict_parser.add_argument("--portal", required=True)
    predict_parser.add_argument("--galaxy", type=int, default=0)
    predict_parser.add_argument("--open-report", action="store_true")

    find_parser = sub.add_parser(
        "find",
        help="Scan one or many canonical galactic regions across the legacy or purple portal domain.",
    )
    find_parser.add_argument("--anchor", required=True)
    find_parser.add_argument("--galaxy", type=int, default=0)
    find_parser.add_argument("--start-system", type=int, default=0)
    find_parser.add_argument("--count", type=int, default=64)
    find_parser.add_argument("--limit", type=int, default=25)
    find_parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help=(
            "Search speed: 0=automatic, -1=maximum speed, or a positive worker count."
        ),
    )
    find_parser.add_argument(
        "--region-mode",
        choices=("single", "window", "full"),
        default="single",
        help=(
            "single=anchor region only; window=repeat the selected system range "
            "across nearby regions; full=scan every system in each selected region."
        ),
    )
    find_parser.add_argument(
        "--region-offset",
        type=int,
        default=0,
        help="Zero-based canonical region offset from the anchor region.",
    )
    find_parser.add_argument(
        "--regions",
        type=int,
        default=1,
        help="Number of canonical regions to scan sequentially.",
    )
    find_parser.add_argument(
        "--search-domain",
        choices=("portal", "purple"),
        default="portal",
        help=(
            "portal=standard systems with an exact region-specific count; "
            "purple=64 purple systems per region."
        ),
    )
    find_parser.add_argument("--paradise", action=argparse.BooleanOptionalAction, default=None)
    find_parser.add_argument("--lush", action=argparse.BooleanOptionalAction, default=None)
    find_parser.add_argument("--water", action=argparse.BooleanOptionalAction, default=None)
    find_parser.add_argument(
        "--high-water",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--world-size",
        choices=world_size_filter_values(),
    )
    find_parser.add_argument(
        "--moon-count",
        choices=moon_count_filter_values()[1:],
        help="Require a parent body with the exact generated moon count.",
    )
    find_parser.add_argument(
        "--ocean-type",
        choices=ocean_type_filter_values()[1:],
        help="Require an exact ocean-presence/depth branch.",
    )
    find_parser.add_argument(
        "--allow-ocean-impossible",
        action="store_true",
        help="Let bodies that structurally cannot have oceans pass an ocean requirement.",
    )
    find_parser.add_argument(
        "--terrain-record",
        type=int,
        choices=range(98),
    )
    find_parser.add_argument(
        "--terrain-setting",
        choices=terrain_family_filter_values(),
        help="Exact 10-way terrain type, such as Floating Islands (terrain) or Caverns.",
    )
    find_parser.add_argument(
        "--ringed",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument("--non-extreme", action="store_true")
    find_parser.add_argument(
        "--extreme",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Require or exclude extreme weather.",
    )
    find_parser.add_argument(
        "--clear-weather",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Require or exclude the native clear-weather branch.",
    )
    find_parser.add_argument(
        "--fauna-profile",
        help="Case-insensitive text contained in the exact native fauna profile.",
    )
    find_parser.add_argument(
        "--fauna-signal",
        help="Community archetype signal label or ID; this is not a species guarantee.",
    )
    find_parser.add_argument("--max-sentinel", type=int)
    find_parser.add_argument("--biome")
    find_parser.add_argument("--biome-variant", choices=biome_variant_filter_values())
    find_parser.add_argument(
        "--biome-variant-include-any",
        action="append",
        choices=biome_variant_filter_values(),
        help="Repeat to match any one of several internal biome variants.",
    )
    find_parser.add_argument(
        "--biome-variant-exclude-any",
        action="append",
        choices=biome_variant_filter_values(),
        help="Repeat to reject any listed internal biome variant.",
    )
    find_parser.add_argument("--biome-source-contains")
    find_parser.add_argument("--storm-frequency", choices=FUNCTIONAL_STORM_FREQUENCY_VALUES)
    find_parser.add_argument("--passive-hazard", choices=PASSIVE_HAZARD_VALUES)
    find_parser.add_argument(
        "--planet-classification",
        help="Exact current-game scanned planet type, for example 'Arctic Planet'.",
    )
    find_parser.add_argument("--star-colour")
    find_parser.add_argument("--economy-type", choices=economy_type_filter_values())
    find_parser.add_argument("--economy-tier", choices=economy_tier_filter_values())
    find_parser.add_argument("--conflict-level", choices=conflict_level_filter_values())
    find_parser.add_argument("--dominant-race")
    find_parser.add_argument(
        "--allow-unavailable-system-data",
        action="store_true",
        help=(
            "Allow uncharted and abandoned systems to pass active "
            "Economy, Conflict and Dominant-race filters when those labels are unavailable."
        ),
    )
    find_parser.add_argument("--description-family")
    find_parser.add_argument(
        "--weather-family",
        help="Exact internal weather-family token; use --clear-weather for semantic clear weather.",
    )
    find_parser.add_argument(
        "--resource-level", type=int, choices=(0, 1)
    )
    find_parser.add_argument("--common-substance")
    find_parser.add_argument("--uncommon-substance")
    find_parser.add_argument("--rare-substance")
    find_parser.add_argument(
        "--fauna-level", type=int, choices=(0, 1, 2, 3)
    )
    find_parser.add_argument(
        "--flora-level", type=int, choices=(0, 1, 2, 3)
    )
    find_parser.add_argument(
        "--empty-system",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--abandoned-system",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--gas-giant-system",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--pirate-system",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--infested",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--dissonant",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    find_parser.add_argument(
        "--grass-assets",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require or exclude generated explicit-grass assets in the "
            "primary surface object list."
        ),
    )
    find_parser.add_argument(
        "--glowing-grass",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require or exclude the exact BUBBLELUSHGRASS "
            "bioluminescent grass-carpet variant."
        ),
    )
    find_parser.add_argument(
        "--mushroom-flora",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require or exclude generated mushroom-style flora assets in "
            "the primary surface object list."
        ),
    )
    find_parser.add_argument(
        "--glowing-mushroom",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require or exclude the exact large fan/blue glowing "
            "mushroom-tree variants."
        ),
    )
    find_parser.add_argument(
        "--salvageable-scrap",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require or exclude exact Salvageable Scrap worlds from the "
            "address-only HasScrap replay."
        ),
    )
    find_parser.add_argument(
        "--grass-colour",
        help=(
            "Required generated Grass slot-0 broad family, exact catalogue "
            "display ending in #RRGGBB, or exact #RRGGBB value."
        ),
    )
    find_parser.add_argument(
        "--grass-alt-colour",
        help=(
            "Required generated GrassAlt slot-0 broad family, exact catalogue "
            "display ending in #RRGGBB, or exact #RRGGBB value."
        ),
    )
    find_parser.add_argument(
        "--either-grass-colour",
        help=(
            "Required broad family, exact catalogue display ending in "
            "#RRGGBB, or exact #RRGGBB accepted when any of the ten generated "
            "Grass or GrassAlt palette slots matches."
        ),
    )
    find_parser.add_argument("--day-atmosphere", choices=DAY_ATMOSPHERE_FILTER_VALUES)
    find_parser.add_argument("--sky-palette-colour")
    find_parser.add_argument("--sunset-palette-colour")
    find_parser.add_argument("--night-palette-colour")
    find_parser.add_argument("--cloud-palette-colour")
    find_parser.add_argument("--generated-water-colour")
    find_parser.add_argument("--deep-water-biolum-colour")
    find_parser.add_argument(
        "--sentinel-difficulty",
        type=int,
        choices=(0, 1, 2, 3),
        help="Native Sentinel difficulty index to inspect.",
    )
    sentinel_group = find_parser.add_mutually_exclusive_group()
    sentinel_group.add_argument(
        "--sentinel-category",
        choices=("rare", "default", "aggressive", "corrupt"),
        help="Required native Sentinel category at --sentinel-difficulty.",
    )
    sentinel_group.add_argument(
        "--sentinel-enum",
        type=int,
        choices=(0, 1, 2, 3),
        help="Required native Sentinel enum at --sentinel-difficulty.",
    )
    find_parser.add_argument("--open-report", action="store_true")

    doctor_parser = sub.add_parser("doctor", help=argparse.SUPPRESS)
    doctor_parser.add_argument("--open-report", action="store_true")

    self_parser = sub.add_parser("self-test", help=argparse.SUPPRESS)
    self_parser.add_argument("--open-report", action="store_true")

    galaxy_proof_parser = sub.add_parser(
        "galaxy-proof",
        help=argparse.SUPPRESS,
    )
    galaxy_proof_parser.add_argument("--open-report", action="store_true")

    proof_parser = sub.add_parser(
        "filter-proof",
        help=argparse.SUPPRESS,
    )
    proof_parser.add_argument("--open-report", action="store_true")

    grass_proof_parser = sub.add_parser(
        "grass-proof",
        help=argparse.SUPPRESS,
    )
    grass_proof_parser.add_argument("--open-report", action="store_true")

    visual_proof_parser = sub.add_parser(
        "visual-proof",
        help=argparse.SUPPRESS,
    )
    visual_proof_parser.add_argument("--open-report", action="store_true")

    atmosphere_proof_parser = sub.add_parser(
        "atmosphere-proof",
        help=argparse.SUPPRESS,
    )
    atmosphere_proof_parser.add_argument("--open-report", action="store_true")

    sub.add_parser("mock-model-test", help=argparse.SUPPRESS)

    gui_parser = sub.add_parser("gui")

    # Keep maintenance and validation commands functional without
    # presenting them in the public command list.
    sub._choices_actions = [
        action
        for action in sub._choices_actions
        if action.dest in {"predict", "find", "gui"}
    ]

    args = parser.parse_args()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    try:
        if args.command == "predict":
            result = predict_system(args.portal, args.galaxy)
            paths = write_prediction_outputs(result)
            print(f"STATUS={result['status']}")
            print(
                "CANONICAL_SYSTEM_PORTAL="
                f"{result['input']['canonical_system_portal']}"
            )
            print(f"PLANETS={len(result['planet_rows'])}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0

        if args.command == "galaxy-proof":
            result = run_galaxy_generation_proof()
            paths = write_galaxy_generation_proof_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"GENERATION_VALIDATED={result['generation_validated']}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result["generation_validated"] else 1

        if args.command == "find":
            result = find_planets_across_regions(
                anchor_portal=args.anchor,
                galaxy=args.galaxy,
                start_system=args.start_system,
                system_count=args.count,
                result_limit=args.limit,
                search_domain=args.search_domain,
                region_mode=args.region_mode,
                region_offset=args.region_offset,
                region_count=args.regions,
                system_workers=args.workers,
                paradise=False,
                lush=False,
                water=False,
                non_extreme=args.non_extreme,
                literal_paradise=args.paradise,
                lush_biome=args.lush,
                water_active=args.water,
                high_water=args.high_water,
                world_size=args.world_size,
                moon_count=args.moon_count,
                ocean_type=args.ocean_type,
                allow_ocean_impossible=args.allow_ocean_impossible,
                terrain_record=args.terrain_record,
                terrain_setting=args.terrain_setting,
                ringed=args.ringed,
                weather_extreme=(False if args.non_extreme else args.extreme),
                weather_clear=args.clear_weather,
                fauna_profile_text=args.fauna_profile,
                fauna_archetype_signal=args.fauna_signal,
                max_sentinel=args.max_sentinel,
                biome=args.biome,
                biome_variant=args.biome_variant,
                biome_variant_include_any=args.biome_variant_include_any,
                biome_variant_exclude_any=args.biome_variant_exclude_any,
                biome_source_contains=args.biome_source_contains,
                functional_storm_frequency=args.storm_frequency,
                passive_hazard=args.passive_hazard,
                planet_classification=args.planet_classification,
                star_colour=args.star_colour,
                economy_type=args.economy_type,
                economy_tier=args.economy_tier,
                conflict_level=args.conflict_level,
                dominant_race=args.dominant_race,
                allow_unavailable_system_data=args.allow_unavailable_system_data,
                description_family=args.description_family,
                weather_family=args.weather_family,
                resource_level=args.resource_level,
                common_substance=args.common_substance,
                uncommon_substance=args.uncommon_substance,
                rare_substance=args.rare_substance,
                fauna_level=args.fauna_level,
                flora_level=args.flora_level,
                in_empty_system=args.empty_system,
                in_abandoned_system=args.abandoned_system,
                in_gas_giant_system=args.gas_giant_system,
                in_pirate_system=args.pirate_system,
                infested=args.infested,
                dissonant=args.dissonant,
                grass_assets=args.grass_assets,
                glowing_grass=args.glowing_grass,
                mushroom_flora=args.mushroom_flora,
                glowing_mushroom=args.glowing_mushroom,
                salvageable_scrap=args.salvageable_scrap,
                grass_colour=args.grass_colour,
                grass_alt_colour=args.grass_alt_colour,
                either_grass_colour=args.either_grass_colour,
                day_atmosphere=args.day_atmosphere,
                sky_palette_colour=args.sky_palette_colour,
                sunset_palette_colour=args.sunset_palette_colour,
                night_palette_colour=args.night_palette_colour,
                cloud_palette_colour=args.cloud_palette_colour,
                generated_water_colour=args.generated_water_colour,
                deep_water_biolum_colour=args.deep_water_biolum_colour,
                native_sentinel_difficulty=args.sentinel_difficulty,
                native_sentinel_enum=normalize_native_sentinel_enum_filter(
                    category=args.sentinel_category,
                    enum_value=args.sentinel_enum,
                ),
            )
            paths = write_search_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"TESTED_SYSTEMS={result['tested_systems']}")
            print(f"MATCHES={result['match_count']}")
            print(
                "SYSTEM_WORKERS_EFFECTIVE="
                f"{result.get('system_workers_effective', result.get('system_workers_peak_effective', 1))}"
            )
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0

        if args.command == "doctor":
            result = run_doctor()
            paths = write_doctor_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"READY={result['ready']}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result["ready"] else 1

        if args.command == "self-test":
            result = run_self_test()
            paths = write_self_test_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"READY={result.get('ready', False)}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result.get("ready") else 1

        if args.command == "filter-proof":
            result = run_filter_proof()
            paths = write_filter_proof_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"READY={result.get('ready', False)}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result.get("ready") else 1

        if args.command == "grass-proof":
            result = run_grass_glow_regression()
            paths = write_grass_glow_proof_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"EXACT={result.get('exact', False)}")
            print(f"PLANETS={result.get('planet_count', 0)}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result.get("exact") else 1

        if args.command == "visual-proof":
            result = run_visual_flora_regression()
            paths = write_visual_flora_proof_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"EXACT={result.get('exact', False)}")
            print(f"CONTROLS={result.get('control_count', 0)}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result.get("exact") else 1

        if args.command == "atmosphere-proof":
            result = run_atmosphere_regression()
            paths = write_atmosphere_proof_outputs(result)
            print(f"STATUS={result['status']}")
            print(f"EXACT={result.get('exact', False)}")
            print(f"PLANETS={result.get('planet_count', 0)}")
            print(f"REPORT={paths['report']}")
            if args.open_report:
                open_path(Path(paths["report"]))
            return 0 if result.get("exact") else 1

        if args.command == "mock-model-test":
            result = run_mock_model_test()
            print(json.dumps(result, indent=2))
            return 0 if result["exact"] else 1

        if args.command == "gui":
            gui_path = HERE / "any_planet_finder_gui.py"
            spec = importlib.util.spec_from_file_location(
                "fibonacci_apf_gui",
                gui_path,
            )
            if spec is None or spec.loader is None:
                raise ImportError(gui_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.main()
            return 0

        raise RuntimeError(f"Unhandled command: {args.command}")

    except Exception as exc:
        error_folder = OUTPUT_ROOT / f"error_{stamp()}"
        error_folder.mkdir(parents=True, exist_ok=True)
        report = error_folder / "ATLAS_APF_RESULT_CORE_V1_ERROR.txt"
        report.write_text(
            "\n".join([
                "ATLAS APF — CORE V1 ERROR",
                f"Timestamp={now_iso()}",
                f"STATUS=ERROR_{type(exc).__name__}",
                f"ERROR={exc}",
                "",
                "TRACEBACK",
                "---------",
                traceback.format_exc(),
            ]) + "\n",
            encoding="utf-8",
        )
        print(f"STATUS=ERROR_{type(exc).__name__}")
        print(f"ERROR={exc}")
        print(f"REPORT={report}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
