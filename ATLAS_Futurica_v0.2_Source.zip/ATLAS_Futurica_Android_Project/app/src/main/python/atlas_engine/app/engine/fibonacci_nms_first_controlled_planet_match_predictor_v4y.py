#!/usr/bin/env python3
r"""
FIBONACCI NMS FIRST CONTROLLED PLANET MATCH PREDICTOR V4Y

Purpose
-------
V4Y is the first consolidated address-only predictor intended for a direct
in-game comparison against an unvisited system.

It combines the validated current-build layers:

- corrected V4X planet count and root arrays;
- system StarType / colour;
- biome, biome subtype and planet class;
- PlanetSize;
- generated water and sea level;
- complete base weather replay;
- SentinelLevel and GroundCombat fields;
- BuildingLevel and HasScrap.

This is ready for a controlled in-game match test. It is not yet the final
perfect planet clone. Exact localized planet-description names, resource
levels/substance IDs, terrain visuals, colours, flora and fauna remain later
phases.

Safety
------
Completely offline.
NMS does not need to be open.
No process access or writes.
No game/save/MODS/settings/EXE/DLL writes.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import sys
from argparse import Namespace
from datetime import datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
VENDOR = HERE / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

VERSION = "4Y.0.0"
TAG = "first_controlled_planet_match_predictor_v4y"

PROJECT_ROOT = HERE.parent
RUNTIME_ROOT = HERE.parent.parent / "outputs"

V4S_PATH = (
    HERE
    / "fibonacci_nms_address_only_planet_count_colour_water_replay_v4s.py"
)
V4L_PATH = (
    HERE / "fibonacci_nms_complete_address_only_weather_replay_v4l.py"
)
V4N2_PATH = (
    HERE
    / "fibonacci_nms_address_only_sentinel_ground_combat_replay_v4n2.py"
)
V4P_PATH = (
    HERE
    / "fibonacci_nms_address_only_building_level_has_scrap_replay_v4p.py"
)

DEFAULT_TEST_PORTAL = "0123456789AB"

BIOME_NAMES = {
    0: "Lush",
    1: "Toxic",
    2: "Scorched",
    3: "Radioactive",
    4: "Frozen",
    5: "Barren",
    6: "Dead",
    7: "Weird / Exotic",
    8: "Red",
    9: "Green",
    10: "Blue",
    11: "Test (non-generating enum)",
    12: "Swamp / Marsh",
    13: "Lava / Volcanic",
    14: "Waterworld",
    15: "Gas Giant",
    16: "All (wildcard enum)",
}

STAR_COLOURS = {
    0: "Yellow",
    1: "Green",
    2: "Blue",
    3: "Red",
    4: "Purple",
}

TESTABLE_FIELDS = [
    "system planet count",
    "raw StarType and system colour",
    "planet root seed",
    "biome family",
    "biome subtype ID",
    "planet class",
    "PlanetSize",
    "generated water activation",
    "generated sea level",
    "base weather index/state/mode/intensity",
    "SentinelLevel and MaxActiveDrones",
    "BuildingLevel",
    "HasScrap",
]

NOT_YET_FINAL = [
    "localized planet-description label",
    "final exact paradise classification",
    "final exact extreme-hazard classification",
    "ResourceLevel and exact substance IDs",
    "terrain shape and visual asset selection",
    "sky/terrain/water colour palettes",
    "flora",
    "fauna",
]


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def normalize_portal(value: str) -> str:
    text = value.strip().upper().replace("0X", "")
    if len(text) != 12:
        raise ValueError(
            "Portal address must contain exactly 12 hexadecimal glyph digits."
        )
    int(text, 16)
    # System predictions are canonicalized to planet index zero.
    return "0" + text[1:]


def planet_portal(system_portal: str, slot: int) -> str:
    return f"{slot:X}{system_portal[1:]}"


def base_args(portal: str, galaxy: int) -> dict[str, Any]:
    return {
        "portal": portal,
        "packed": None,
        "galaxy": galaxy,
        "dump": None,
        "v4i2_folder": None,
    }


def run_layers(portal: str, galaxy: int) -> dict[str, Any]:
    v4s = load_module("v4y_v4s", V4S_PATH)
    v4l = load_module("v4y_v4l", V4L_PATH)
    v4n2 = load_module("v4y_v4n2", V4N2_PATH)
    v4p = load_module("v4y_v4p", V4P_PATH)

    common = base_args(portal, galaxy)

    count_water = v4s.run(Namespace(
        **common,
        v4r_folder=None,
    ))
    weather = v4l.run(Namespace(
        **common,
        v4a_json=None,
        v4c_json=None,
    ))
    sentinel = v4n2.run(Namespace(
        **common,
        v4m3_folder=None,
    ))
    scrap = v4p.run(Namespace(
        **common,
        v4o_folder=None,
    ))

    layers = {
        "count_colour_biome_size_water": count_water,
        "weather": weather,
        "sentinel_ground_combat": sentinel,
        "building_scrap": scrap,
    }

    failures = {
        name: result.get("status")
        for name, result in layers.items()
        if not str(result.get("status", "")).startswith("PASS_")
    }
    if failures:
        raise RuntimeError(f"One or more predictor layers failed: {failures}")

    return layers


def merge_rows(layers: dict[str, Any]) -> list[dict[str, Any]]:
    base_rows = {
        int(row["slot"]): row
        for row in layers[
            "count_colour_biome_size_water"
        ]["planet_rows"]
    }
    weather_rows = {
        int(row["slot"]): row
        for row in layers["weather"]["planet_rows"]
    }
    sentinel_rows = {
        int(row["slot"]): row
        for row in layers[
            "sentinel_ground_combat"
        ]["planet_rows"]
    }
    scrap_rows = {
        int(row["slot"]): row
        for row in layers["building_scrap"]["planet_rows"]
    }

    slots = sorted(base_rows)
    for source_name, source in (
        ("weather", weather_rows),
        ("sentinel", sentinel_rows),
        ("scrap", scrap_rows),
    ):
        if set(source) != set(slots):
            raise RuntimeError(
                f"{source_name} slots do not match the corrected base layer."
            )

    system_portal = layers[
        "count_colour_biome_size_water"
    ]["input"]["planet_zero_portal"]

    merged: list[dict[str, Any]] = []
    for slot in slots:
        base = base_rows[slot]
        weather = weather_rows[slot]
        sentinel = sentinel_rows[slot]
        scrap = scrap_rows[slot]

        biome = int(base["biome"])
        star_type = int(base["star_type"])

        merged.append({
            "slot": slot,
            "planet_portal": planet_portal(system_portal, slot),
            "planet_seed_hex": base["planet_seed_hex"],
            "biome": biome,
            "biome_name": BIOME_NAMES.get(
                biome,
                f"Unknown biome {biome}",
            ),
            "biome_subtype": int(base["biome_subtype"]),
            "planet_class": int(base["planet_class"]),
            "planet_size": int(base["planet_size"]),
            "has_rings": base.get("has_rings"),
            "rings_prediction_exact": bool(
                base.get("rings_prediction_exact", False)
            ),
            "rings_prediction_status": base.get(
                "rings_prediction_status",
                "standard_route_ring_selector_not_mapped",
            ),
            "star_type": star_type,
            "system_colour": STAR_COLOURS.get(
                star_type,
                base.get("system_colour", f"Unknown {star_type}"),
            ),
            "terrain_record_index": int(
                base["terrain_record_index"]
            ),
            "water_active_frequency": float(
                base["water_active_frequency"]
            ),
            "high_water_active_frequency": float(
                base["high_water_active_frequency"]
            ),
            "water_active": bool(base["water_active"]),
            "high_water": bool(base["high_water"]),
            "sea_level": float(base["sea_level"]),
            "sea_level_source": base["sea_level_source"],
            "weather_index": int(weather["final_weather_index"]),
            "weather_initial_index": int(
                weather["initial_weather_index"]
            ),
            "weather_active": int(weather["weather_active"]),
            "weather_mode": int(weather["weather_mode"]),
            "weather_flag": int(weather["weather_flag"]),
            "weather_intensity": int(
                weather["weather_intensity"]
            ),
            "special_weather_state": int(
                weather["selected_special_weather_state"]
            ),
            "weather_override_reasons": weather[
                "override_reasons"
            ],
            "sentinel_level": int(sentinel["sentinel_level"]),
            "max_active_drones": int(
                sentinel["max_active_drones"]
            ),
            "ground_combat_field_3440": sentinel["field_3440"],
            "ground_combat_field_3444": sentinel["field_3444"],
            "building_level": int(scrap["building_level"]),
            "building_level_reason": scrap[
                "building_level_reason"
            ],
            "has_scrap": bool(scrap["has_scrap"]),
            "has_scrap_reason": scrap["has_scrap_reason"],
        })

    return merged


def run(portal: str, galaxy: int) -> dict[str, Any]:
    canonical = normalize_portal(portal)
    layers = run_layers(canonical, galaxy)
    rows = merge_rows(layers)

    base = layers["count_colour_biome_size_water"]
    system = base["system"]

    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": (
            "PASS_FIRST_CONTROLLED_PLANET_MATCH_PREDICTION_READY"
        ),
        "mode": "OFFLINE_CONSOLIDATED_ADDRESS_ONLY_PREDICTION",
        "ready_for_controlled_ingame_test": True,
        "perfect_complete_planet_predictor_ready": False,
        "input": {
            "requested_portal": portal,
            "canonical_system_portal": canonical,
            "galaxy_index": galaxy,
        },
        "system": {
            "planet_count": int(system["planet_count"]),
            "star_type": int(system["star_type_raw"]),
            "colour": system["colour"],
        },
        "layer_statuses": {
            name: result["status"]
            for name, result in layers.items()
        },
        "testable_fields": TESTABLE_FIELDS,
        "not_yet_final": NOT_YET_FINAL,
        "planet_rows": rows,
        "claim_boundary": {
            "address_to_count_colour_biome_subtype_class_exact": True,
            "address_to_planet_size_exact": True,
            "address_to_water_and_sea_level_exact": True,
            "address_to_complete_base_weather_exact": True,
            "address_to_sentinel_ground_combat_exact_current_tables": True,
            "address_to_building_level_has_scrap_exact_current_tables": True,
            "broad_count_colour_size_water_validation_systems": 35,
            "direct_unvisited_ingame_match_test_completed": False,
            "final_paradise_extreme_resource_visual_clone_complete": False,
            "fauna_work_started": False,
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields: list[str] = []
    for row in rows:
        for key, value in row.items():
            if isinstance(value, (dict, list)):
                continue
            if key not in fields:
                fields.append(key)

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: row.get(key)
                for key in fields
            })


def write_outputs(result: dict[str, Any], output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)

    json_path = output / "controlled_planet_prediction_v4y.json"
    json_path.write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    csv_path = output / "controlled_planet_prediction_v4y.csv"
    write_csv(csv_path, result.get("planet_rows", []))

    system = result.get("system", {})
    input_data = result.get("input", {})

    report = f"""FIBONACCI NMS FIRST CONTROLLED PLANET MATCH PREDICTOR V4Y
Timestamp={result['timestamp']}
Version={VERSION}

RESULT
------
STATUS={result['status']}
ERROR={result.get('error', 'NONE')}
READY_FOR_CONTROLLED_INGAME_TEST={result.get('ready_for_controlled_ingame_test', False)}
PERFECT_COMPLETE_PLANET_PREDICTOR_READY={result.get('perfect_complete_planet_predictor_ready', False)}
NMS_PROCESS_REQUIRED=False
PROCESS_ACCESS=False
PROCESS_MEMORY_WRITES=False
GAME_FILE_WRITES=False
SAVE_WRITES=False
MOD_WRITES=False

TEST ADDRESS
------------
REQUESTED_PORTAL={input_data.get('requested_portal', 'UNKNOWN')}
CANONICAL_SYSTEM_PORTAL={input_data.get('canonical_system_portal', 'UNKNOWN')}
GALAXY_INDEX={input_data.get('galaxy_index', 'UNKNOWN')}

SYSTEM PREDICTION
-----------------
PLANET_COUNT={system.get('planet_count', 'UNKNOWN')}
STAR_TYPE={system.get('star_type', 'UNKNOWN')}
SYSTEM_COLOUR={system.get('colour', 'UNKNOWN')}

LAYER STATUSES
--------------
"""
    for name, status in result.get("layer_statuses", {}).items():
        report += f"{name.upper()}={status}\n"

    report += "\nPLANET PREDICTIONS\n------------------\n"
    for row in result.get("planet_rows", []):
        report += (
            f"SLOT={row['slot']} "
            f"PLANET_PORTAL={row['planet_portal']} "
            f"BIOME={row['biome']} "
            f"BIOME_NAME={row['biome_name']} "
            f"SUBTYPE={row['biome_subtype']} "
            f"CLASS={row['planet_class']} "
            f"SIZE={row['planet_size']} "
            f"WATER={row['water_active']} "
            f"HIGH_WATER={row['high_water']} "
            f"SEA_LEVEL={row['sea_level']} "
            f"WEATHER_INDEX={row['weather_index']} "
            f"WEATHER_ACTIVE={row['weather_active']} "
            f"WEATHER_MODE={row['weather_mode']} "
            f"WEATHER_INTENSITY={row['weather_intensity']} "
            f"SPECIAL_WEATHER={row['special_weather_state']} "
            f"SENTINEL_LEVEL={row['sentinel_level']} "
            f"MAX_DRONES={row['max_active_drones']} "
            f"BUILDING_LEVEL={row['building_level']} "
            f"HAS_SCRAP={row['has_scrap']}\n"
        )

    report += """
WHAT TO CHECK IN GAME
---------------------
1. Confirm the destination system's star colour.
2. Count the planets and moons shown by the discovery/system view.
3. For each slot, compare the broad biome family shown by scanning or landing.
4. Compare whether the planet has generated water.
5. Record weather wording or storm behaviour.
6. Record Sentinel wording/behaviour.
7. Record whether the planet is a scrap world when applicable.

The numeric subtype, class, PlanetSize, weather and Sentinel fields are
included even when the game presents them through localized descriptive text.
The next comparison phase will map those raw values to the exact displayed
labels.

NOT YET A FINAL CLAIM
---------------------
V4Y does not yet claim exact localized planet-description names, complete
paradise/extreme labels, resource/substance IDs, visual terrain, colour
palettes, flora or fauna.

A successful unvisited-system comparison will establish that the consolidated
address-only core is ready for the remaining user-visible label/resource
mapping phases.

OUTPUT FILES
------------
{output / 'ATLAS_APF_RESULT_CONTROLLED_PLANET_MATCH_V4Y.txt'}
{json_path}
{csv_path}
"""
    report_path = (
        output / "ATLAS_APF_RESULT_CONTROLLED_PLANET_MATCH_V4Y.txt"
    )
    report_path.write_text(report, encoding="utf-8")
    return report_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--portal",
        default=DEFAULT_TEST_PORTAL,
    )
    parser.add_argument("--galaxy", type=int, default=0)
    args = parser.parse_args()

    output = RUNTIME_ROOT / f"{TAG}_{stamp()}"

    try:
        result = run(args.portal, args.galaxy)
    except Exception as exc:
        result = {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": f"ERROR_{type(exc).__name__}",
            "error": str(exc),
            "ready_for_controlled_ingame_test": False,
            "perfect_complete_planet_predictor_ready": False,
            "input": {
                "requested_portal": args.portal,
                "galaxy_index": args.galaxy,
            },
            "system": {},
            "layer_statuses": {},
            "planet_rows": [],
        }

    report = write_outputs(result, output)
    print(f"STATUS={result['status']}")
    print(
        "READY_FOR_CONTROLLED_INGAME_TEST="
        f"{result.get('ready_for_controlled_ingame_test', False)}"
    )
    print(f"OUTPUT_DIR={output}")
    print(f"REPORT={report}")
    if result.get("error"):
        print(f"ERROR={result['error']}")

    return 0 if str(result["status"]).startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
