#!/usr/bin/env python3
"""Adaptive multi-process system prediction engine for APF V20F3."""
from __future__ import annotations

import ctypes
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Iterator

VERSION = "20F3.0.0"
MAX_SUPPORTED_WORKERS = 64
EARLY_STOP_POOL_STRATEGY = "graceful_close_join_v20f3"
_WORKER_CORE: Any = None


class _MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _total_memory_bytes() -> int:
    if os.name == "nt":
        try:
            status = _MemoryStatusEx()
            status.dwLength = ctypes.sizeof(_MemoryStatusEx)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.ullTotalPhys)
        except Exception:
            pass
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return int(pages) * int(page_size)
    except Exception:
        return 0


def hardware_profile() -> dict[str, Any]:
    logical = max(1, int(os.cpu_count() or 1))
    memory_bytes = _total_memory_bytes()
    memory_gib = float(memory_bytes) / float(1024 ** 3) if memory_bytes else 0.0

    # The predictor workers do not load the 120 MB native occupancy dump. A
    # conservative 450 MiB allowance per worker plus a 4 GiB system reserve
    # prevents auto mode from exhausting RAM on smaller machines.
    if memory_bytes:
        usable = max(0, memory_bytes - 4 * 1024 ** 3)
        memory_worker_limit = max(1, int(usable // (450 * 1024 ** 2)))
    else:
        memory_worker_limit = logical

    maximum = max(
        1,
        min(logical, memory_worker_limit, MAX_SUPPORTED_WORKERS),
    )
    estimated_physical = (
        max(1, logical // 2) if logical >= 8 else max(1, logical - 1)
    )
    balanced = max(1, min(estimated_physical, maximum))
    if logical <= 4:
        balanced = max(1, min(logical, maximum))

    return {
        "logical_processors": logical,
        "estimated_physical_cores": estimated_physical,
        "total_memory_bytes": memory_bytes,
        "total_memory_gib": round(memory_gib, 2),
        "memory_worker_limit": memory_worker_limit,
        "recommended_balanced_workers": balanced,
        "maximum_cpu_workers": maximum,
        "maximum_supported_workers": MAX_SUPPORTED_WORKERS,
        "auto_reserves_ui_headroom": True,
        "worker_process_memory_allowance_mib": 450,
        "native_occupancy_workers": 1,
    }


def resolve_worker_request(
    requested: int | str | None,
    task_count: int,
) -> dict[str, Any]:
    profile = hardware_profile()
    if requested is None:
        requested_value = 0
    elif isinstance(requested, str):
        text = requested.strip().casefold()
        if not text or text.startswith("auto"):
            requested_value = 0
        elif text.startswith("max"):
            requested_value = -1
        else:
            match = __import__("re").search(r"-?\d+", text)
            if not match:
                raise ValueError(
                    "System workers must be Auto, Maximum CPU, or an integer."
                )
            requested_value = int(match.group(0))
    else:
        requested_value = int(requested)

    if requested_value == 0:
        configured = int(profile["recommended_balanced_workers"])
        mode = "auto_balanced"
    elif requested_value == -1:
        configured = int(profile["maximum_cpu_workers"])
        mode = "maximum_cpu"
    else:
        if requested_value < 1:
            raise ValueError(
                "System workers must be 0 (Auto), -1 (Maximum CPU), or a positive integer."
            )
        maximum = int(profile["maximum_cpu_workers"])
        if requested_value > maximum:
            raise ValueError(
                f"This computer supports at most {maximum} system workers."
            )
        configured = requested_value
        mode = "custom"

    tasks = max(0, int(task_count))
    effective = min(configured, tasks) if tasks else 0
    return {
        "requested": requested_value,
        "mode": mode,
        "configured_workers": configured,
        "effective_workers": effective,
        "task_count": tasks,
        "parallel": effective > 1,
        "hardware": profile,
    }


def worker_option_values() -> tuple[str, ...]:
    profile = hardware_profile()
    maximum = int(profile["maximum_cpu_workers"])
    values = [
        "Auto (recommended)",
        "Maximum speed",
        "1 worker (sequential)",
    ]
    for count in range(2, maximum + 1):
        values.append(f"{count} workers")
    return tuple(values)


def worker_note(requested: int | str | None = 0) -> str:
    resolution = resolve_worker_request(requested, 10_000)
    configured = int(resolution["configured_workers"])
    mode = str(resolution["mode"])
    if mode == "auto_balanced":
        choice = "Auto mode selects a balanced worker count for this computer."
    elif mode == "maximum_cpu":
        choice = "Maximum speed uses all worker capacity available to the app."
    elif configured == 1:
        choice = "Sequential mode processes one system at a time."
    else:
        choice = f"Custom mode uses up to {configured} workers."
    return (
        choice
        + " Searches run in parallel when useful, while results remain in exact address order."
    )


def _worker_initializer(app_dir: str) -> None:
    global _WORKER_CORE
    app = Path(app_dir)
    engine = app / "engine"
    vendor = engine / "vendor"
    for item in (str(vendor), str(engine), str(app)):
        if item not in sys.path:
            sys.path.insert(0, item)
    import any_planet_finder_core as core
    _WORKER_CORE = core


def _predict_task(task: tuple[int, int, str, int]) -> dict[str, Any]:
    ordinal, system_index, portal, galaxy = task
    started = time.perf_counter()
    prediction = _WORKER_CORE.predict_system(portal, int(galaxy))
    return {
        "ordinal": int(ordinal),
        "system_index": int(system_index),
        "portal": str(portal),
        "prediction": prediction,
        "worker_pid": os.getpid(),
        "elapsed_seconds": time.perf_counter() - started,
    }


class OrderedPredictionStream:
    def __init__(
        self,
        tasks: list[tuple[int, int, str, int]],
        *,
        app_dir: Path,
        requested_workers: int | str | None,
    ) -> None:
        self.tasks = tasks
        self.resolution = resolve_worker_request(requested_workers, len(tasks))
        self.resolution["early_stop_pool_strategy"] = EARLY_STOP_POOL_STRATEGY
        self._pool: Any = None
        self._iterator: Iterator[dict[str, Any]] | None = None
        self._closed = False
        self._completed = False
        if int(self.resolution["effective_workers"]) > 1:
            context = mp.get_context("spawn")
            self._pool = context.Pool(
                processes=int(self.resolution["effective_workers"]),
                initializer=_worker_initializer,
                initargs=(str(app_dir),),
                maxtasksperchild=256,
            )
            self._iterator = self._pool.imap(
                _predict_task,
                tasks,
                chunksize=1,
            )

    def __iter__(self) -> Iterator[dict[str, Any]]:
        if int(self.resolution["effective_workers"]) <= 1:
            app_dir = Path(__file__).resolve().parent.parent
            _worker_initializer(str(app_dir))
            for task in self.tasks:
                yield _predict_task(task)
            self._completed = True
            return

        assert self._iterator is not None
        try:
            for row in self._iterator:
                yield row
            self._completed = True
        finally:
            if self._completed:
                self.close(terminate=False)

    def close(self, *, terminate: bool = True) -> None:
        if self._closed:
            return
        self._closed = True
        if self._pool is None:
            return
        # Python 3.14 on Windows can raise ``ValueError: concurrent
        # send_bytes() calls are not supported`` when Pool.terminate() races
        # the pool result-handler thread on the same queue. APF submits one
        # bounded region at a time, so early completion now closes the pool
        # gracefully and waits for already-submitted tasks.
        self._pool.close()
        self._pool.join()


def open_ordered_prediction_stream(
    tasks: Iterable[tuple[int, int, str, int]],
    *,
    app_dir: Path,
    requested_workers: int | str | None,
) -> OrderedPredictionStream:
    return OrderedPredictionStream(
        list(tasks),
        app_dir=app_dir,
        requested_workers=requested_workers,
    )


def run_self_test() -> dict[str, Any]:
    profile = hardware_profile()
    auto = resolve_worker_request(0, 100)
    maximum = resolve_worker_request(-1, 100)
    one = resolve_worker_request(1, 100)
    checks = {
        "logical_processors_positive": profile["logical_processors"] >= 1,
        "balanced_positive": profile["recommended_balanced_workers"] >= 1,
        "maximum_not_above_logical": (
            profile["maximum_cpu_workers"] <= profile["logical_processors"]
        ),
        "balanced_not_above_maximum": (
            profile["recommended_balanced_workers"] <= profile["maximum_cpu_workers"]
        ),
        "auto_mode": auto["mode"] == "auto_balanced",
        "maximum_mode": maximum["mode"] == "maximum_cpu",
        "one_sequential": one["effective_workers"] == 1 and not one["parallel"],
        "task_clipping": resolve_worker_request(-1, 1)["effective_workers"] == 1,
        "python314_safe_early_stop": (
            EARLY_STOP_POOL_STRATEGY == "graceful_close_join_v20f3"
        ),
    }
    return {
        "version": VERSION,
        "exact": all(checks.values()),
        "checks": checks,
        "hardware": profile,
        "auto": auto,
        "maximum": maximum,
    }
